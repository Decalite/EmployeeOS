#!/usr/bin/env node
/* Generates assets/js/config.js from environment variables (for Netlify / Vercel / Cloudflare / CI builds).
 *   SUPABASE_URL=https://xxxx.supabase.co SUPABASE_ANON_KEY=eyJ... node scripts/write-config.js
 * Only the PUBLIC anon key belongs here. Never use the service_role key. */
const fs = require('fs'), path = require('path');
const url = process.env.SUPABASE_URL || '', key = process.env.SUPABASE_ANON_KEY || '';
const domain = process.env.EMPLOYEE_EMAIL_DOMAIN || 'employees.employeeos.app';
if (/service_role/i.test(key) || (key.split('.')[1] && /"role"\s*:\s*"service_role"/.test(Buffer.from(key.split('.')[1], 'base64').toString('utf8') || ''))) {
  console.error('Refusing: that looks like a service_role key. Use the anon (public) key.'); process.exit(1);
}
if ((url && !key) || (!url && key)) { console.error('Set BOTH SUPABASE_URL and SUPABASE_ANON_KEY (or neither for preview mode).'); process.exit(1); }
const out = `window.EOS_CONFIG = ${JSON.stringify({ supabaseUrl: url, supabaseAnonKey: key, employeeEmailDomain: domain, currency: process.env.CURRENCY || '₹', locale: process.env.LOCALE || 'en-IN' }, null, 2)};\n`;
fs.writeFileSync(path.join(__dirname, '..', 'assets', 'js', 'config.js'), out);
console.log(url ? 'config.js written for ' + url : 'config.js written in PREVIEW mode (no backend)');

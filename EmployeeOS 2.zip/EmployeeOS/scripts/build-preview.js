#!/usr/bin/env node
/* Builds self-contained single-file pages (CSS + JS inlined) into dist-preview/ for hosts that only allow
 * inline assets (e.g. artifact/preview sandboxes). Normal deployments do not need this. */
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'dist-preview'); fs.mkdirSync(out, { recursive: true });
const css = fs.readFileSync(path.join(root, 'assets/styles.css'), 'utf8').replace(':root{', ':root{color-scheme:dark;');
function build(name, wrapped) {
  let h = fs.readFileSync(path.join(root, name), 'utf8');
  h = h.replace(/<link rel="stylesheet" href="assets\/styles.css">/, () => '<style>' + css + '</style>');
  h = h.replace(/<script src="(assets\/js\/[^"]+)"><\/script>/g, (_, p) => {
    const js = fs.readFileSync(path.join(root, p), 'utf8'); if (/<\/script/i.test(js)) throw new Error('script end tag in ' + p);
    return '<script>\n' + js + '\n</script>';
  });
  if (wrapped) { // host adds doctype/html/head/body itself
    const title = (h.match(/<title>.*?<\/title>/) || [''])[0];
    const headInner = h.match(/<head>([\s\S]*?)<\/head>/)[1].replace(/<meta name="viewport"[^>]*>/, '').replace(/<meta charset[^>]*>/, '');
    const bodyInner = h.match(/<body>([\s\S]*?)<\/body>/)[1];
    h = title + '\n' + headInner.replace(title, '') + '\n' + bodyInner;
  }
  fs.writeFileSync(path.join(out, name), h); console.log(name, Math.round(h.length / 1024) + ' KB');
}
build('index.html', true); build('admin.html', false);

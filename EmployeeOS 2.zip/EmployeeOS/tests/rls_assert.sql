\set ON_ERROR_STOP on
-- fixtures (as superuser)
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.io'),('00000000-0000-0000-0000-0000000000e1','e1@x.io'),
 ('00000000-0000-0000-0000-0000000000e2','e2@x.io'),('00000000-0000-0000-0000-0000000000e3','e3@x.io');
insert into profiles(id,employee_code,full_name,role,monthly_base_salary,status) values
 ('00000000-0000-0000-0000-0000000000a1',null,'Admin One','admin',0,'active'),
 ('00000000-0000-0000-0000-0000000000e1','EMP001','Emp One','employee',26000,'active'),
 ('00000000-0000-0000-0000-0000000000e2','EMP002','Emp Two','employee',20000,'active'),
 ('00000000-0000-0000-0000-0000000000e3','EMP003','Emp Three','employee',20000,'suspended');
insert into earning_entries(employee_id,entry_type,amount) values ('00000000-0000-0000-0000-0000000000e2','bonus',500);
insert into points_ledger(employee_id,points,reason,source) values ('00000000-0000-0000-0000-0000000000e1',100,'x','work'),('00000000-0000-0000-0000-0000000000e2',250,'y','work');

create or replace function t_as(uid text) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claim.sub', uid, false); execute 'set role authenticated'; end $$;
create or replace function t_reset() returns void language plpgsql as $$ begin execute 'reset role'; end $$;
create or replace function t_expect_fail(sql text, label text) returns void language plpgsql as $$
declare n int; begin
  begin execute sql; get diagnostics n = row_count;
    if n = 0 then return; end if;     -- RLS silently filtered the write: also a pass
    raise exception 'SECURITY HOLE: % succeeded (% rows)', label, n;
  exception when insufficient_privilege or check_violation or raise_exception or unique_violation then
    if sqlerrm like 'SECURITY HOLE%' then raise; end if; end; end $$;
grant execute on all functions in schema public to authenticated;

-- ===== employee E1 =====
select t_as('00000000-0000-0000-0000-0000000000e1');
do $$ begin
  assert (select count(*) from profiles)=1, 'E1 must see only own profile';
  assert (select count(*) from earning_entries)=0, 'E1 must not see E2 earnings';
  assert (select count(*) from points_ledger)=1, 'E1 sees only own ledger';
  assert (select count(*) from leaderboard(null))=2, 'leaderboard lists active employees';
  assert (select max(points) from leaderboard(null))=250, 'leaderboard points correct';
end $$;
select t_expect_fail($$update profiles set monthly_base_salary=999999 where id='00000000-0000-0000-0000-0000000000e1'$$,'E1 raising own salary');
select t_expect_fail($$update profiles set role='admin' where id='00000000-0000-0000-0000-0000000000e1'$$,'E1 self-promoting to admin');
select t_expect_fail($$update profiles set tier='Diamond' where id='00000000-0000-0000-0000-0000000000e1'$$,'E1 editing own tier');
select t_expect_fail($$insert into earning_entries(employee_id,entry_type,amount) values('00000000-0000-0000-0000-0000000000e1','bonus',9999)$$,'E1 adding bonus');
select t_expect_fail($$insert into points_ledger(employee_id,points,reason,source) values('00000000-0000-0000-0000-0000000000e1',9999,'cheat','manual')$$,'E1 adding points');
select t_expect_fail($$insert into work_sessions(employee_id,started_at,work_date) values('00000000-0000-0000-0000-0000000000e1',now(),current_date)$$,'E1 starting session without approval');
select t_expect_fail($$insert into work_requests(employee_id,request_type) values('00000000-0000-0000-0000-0000000000e2','start')$$,'E1 requesting on behalf of E2');
select t_expect_fail($$insert into work_requests(employee_id,request_type,status) values('00000000-0000-0000-0000-0000000000e1','start','approved')$$,'E1 self-approving');
select t_expect_fail($$insert into resources(title,resource_type) values('x','note')$$,'E1 publishing resource');
select t_expect_fail($$insert into messages(employee_id,sender_id,sender_role,body) values('00000000-0000-0000-0000-0000000000e2','00000000-0000-0000-0000-0000000000e1','employee','hi')$$,'E1 writing into E2 chat');
select t_expect_fail($$insert into messages(employee_id,sender_id,sender_role,body) values('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-0000000000e1','admin','fake admin')$$,'E1 impersonating admin');
select t_expect_fail($$insert into notifications(user_id,title) values('00000000-0000-0000-0000-0000000000e2','spam')$$,'E1 notifying others');
select t_expect_fail($$insert into settings(key,value) values('rules','{}')$$,'E1 editing settings');
select t_expect_fail($$select * from activity_log where false; insert into activity_log(actor_id,action) values('00000000-0000-0000-0000-0000000000e2','forged')$$,'E1 forging log as E2');
-- allowed actions
insert into work_requests(employee_id,request_type) values('00000000-0000-0000-0000-0000000000e1','start');
insert into messages(employee_id,sender_id,sender_role,body) values('00000000-0000-0000-0000-0000000000e1','00000000-0000-0000-0000-0000000000e1','employee','hello admin');
select update_my_profile('99999');
do $$ begin assert (select phone from profiles)='99999','update_my_profile works'; end $$;
select t_expect_fail($$select mark_read('00000000-0000-0000-0000-0000000000e2')$$,'E1 marking E2 chat read');
select t_reset();

-- ===== admin =====
select t_as('00000000-0000-0000-0000-0000000000a1');
do $$ begin
  assert (select count(*) from profiles)=4,'admin sees all profiles';
  assert (select count(*) from work_requests where status='pending')=1,'admin sees pending request';
  update work_requests set status='approved', reviewed_by=auth.uid(), reviewed_at=now() where status='pending';
  insert into work_sessions(employee_id,started_at,work_date) values('00000000-0000-0000-0000-0000000000e1',now(),current_date);
  insert into notifications(user_id,title) values('00000000-0000-0000-0000-0000000000e1','Hello') ;
  insert into messages(employee_id,sender_id,sender_role,body) values('00000000-0000-0000-0000-0000000000e1',auth.uid(),'admin','welcome');
  perform mark_read('00000000-0000-0000-0000-0000000000e1');
  assert (select read_at is not null from messages where sender_role='employee'),'admin mark_read';
  insert into earning_entries(employee_id,entry_type,amount) values('00000000-0000-0000-0000-0000000000e1','bonus',100);
  update profiles set monthly_base_salary=30000 where id='00000000-0000-0000-0000-0000000000e1';
end $$;
-- second open session is blocked by DB constraint
select t_expect_fail($$insert into work_sessions(employee_id,started_at,work_date) values('00000000-0000-0000-0000-0000000000e1',now(),current_date)$$,'two open sessions');
-- duplicate reward ref blocked
insert into earning_entries(employee_id,entry_type,amount,ref) values('00000000-0000-0000-0000-0000000000e1','bonus',10,'reward:2026-10:1');
select t_expect_fail($$insert into earning_entries(employee_id,entry_type,amount,ref) values('00000000-0000-0000-0000-0000000000e2','bonus',10,'reward:2026-10:1')$$,'double monthly reward');
select t_reset();

-- ===== E1 sees admin actions, can only mark notification read =====
select t_as('00000000-0000-0000-0000-0000000000e1');
do $$ begin
  assert (select count(*) from notifications)=1,'E1 sees own notification';
  assert (select count(*) from work_sessions where ended_at is null)=1,'E1 sees own open session';
  assert (select count(*) from messages)=2,'E1 sees both messages';
  update notifications set read_at=now();
  perform mark_read('00000000-0000-0000-0000-0000000000e1');
  assert (select count(*) from messages where sender_role='admin' and read_at is not null)=1,'E1 mark_read';
end $$;
select t_expect_fail($$update notifications set title='tampered'$$,'E1 editing notification text');
select t_expect_fail($$update messages set body='edited' where sender_role='employee'$$,'E1 editing messages');
select t_expect_fail($$delete from messages$$,'E1 deleting messages');
select t_reset();

-- ===== suspended E3 =====
select t_as('00000000-0000-0000-0000-0000000000e3');
do $$ begin
  assert (select count(*) from resources)=0,'suspended sees no resources (even if rows exist)';
  assert (select count(*) from leaderboard(null))=0,'suspended gets empty leaderboard';
end $$;
select t_expect_fail($$insert into work_requests(employee_id,request_type) values('00000000-0000-0000-0000-0000000000e3','start')$$,'suspended user requesting work');
select t_expect_fail($$select update_my_profile('1')$$,'suspended editing profile');
select t_reset();

-- ===== anonymous =====
set role anon;
do $$ begin begin perform count(*) from profiles; raise exception 'SECURITY HOLE: anon read profiles'; exception when insufficient_privilege then null; end; end $$;
reset role;

-- ===== storage policies =====
insert into storage.objects(bucket_id,name) values ('chat','00000000-0000-0000-0000-0000000000e1/a.png'),('chat','00000000-0000-0000-0000-0000000000e2/b.png'),('resources','library/x.pdf');
select t_as('00000000-0000-0000-0000-0000000000e1');
do $$ begin
  assert (select count(*) from storage.objects where bucket_id='chat')=1,'E1 sees only own chat files';
  assert (select count(*) from storage.objects where bucket_id='resources')=1,'E1 can read resources';
end $$;
select t_expect_fail($$insert into storage.objects(bucket_id,name) values('resources','library/evil.pdf')$$,'E1 uploading resource');
select t_expect_fail($$insert into storage.objects(bucket_id,name) values('chat','00000000-0000-0000-0000-0000000000e2/evil.png')$$,'E1 uploading into E2 chat folder');
insert into storage.objects(bucket_id,name) values('chat','00000000-0000-0000-0000-0000000000e1/ok.png');
select t_reset();
select t_as('00000000-0000-0000-0000-0000000000a1');
do $$ begin assert (select count(*) from storage.objects where bucket_id='chat')=3,'admin sees all chat files'; end $$;
select t_reset();
\echo ALL RLS ASSERTIONS PASSED

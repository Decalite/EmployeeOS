set -e
PGBIN=/usr/lib/postgresql/16/bin
export PGDATA=/home/claude/work/pg/data PGPORT=54329 PGHOST=/tmp
id postgres >/dev/null 2>&1 || true
rm -rf $PGDATA; mkdir -p $PGDATA; chown -R postgres $PGDATA /home/claude/work/pg 2>/dev/null || true
su postgres -c "$PGBIN/initdb -D $PGDATA -A trust >/dev/null && $PGBIN/pg_ctl -D $PGDATA -o '-p $PGPORT -k /tmp' -l /home/claude/work/pg/log -w start >/dev/null"
P="psql -h /tmp -p $PGPORT -U postgres -v ON_ERROR_STOP=1 -q -X"
$P -d postgres -c "create database t" 
$P -d t <<'SQL'
create role anon nologin; create role authenticated nologin;
create schema auth; create table auth.users(id uuid primary key default gen_random_uuid(), email text);
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
grant usage on schema auth to authenticated; grant usage on schema public to anon, authenticated;
create schema storage; create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint);
create table storage.objects(id uuid default gen_random_uuid(), bucket_id text, name text, owner uuid);
alter table storage.objects enable row level security;
create function storage.foldername(name text) returns text[] language sql as $$ select string_to_array(name,'/') $$;
grant usage on schema storage to authenticated; grant all on storage.objects to authenticated;
SQL
$P -d t -f "$(cd "$(dirname "$0")/.." && pwd)/supabase/schema.sql
$P -d t -f "$(cd "$(dirname "$0")/.." && pwd)/supabase/storage.sql
echo "SCHEMA + STORAGE APPLIED OK"

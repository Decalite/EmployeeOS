/*
 * End-to-end tests (preview/local backend) for every flow in the brief.
 *   node tests/e2e.js            (starts its own static server on :8099)
 * Uses one browser context with two tabs (admin + employee) so approvals travel between them
 * exactly as they would between two devices on a shared backend.
 */
const { chromium, devices } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path'), assert = require('assert');

const ROOT = path.resolve(__dirname, '..'), PORT = 8099, BASE = 'http://localhost:' + PORT;
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png' };
const server = http.createServer((q, r) => {
  let p = decodeURIComponent(q.url.split('?')[0]); if (p === '/') p = '/index.html';
  const f = path.join(ROOT, p); if (!f.startsWith(ROOT) || !fs.existsSync(f)) { r.writeHead(404); return r.end('nf'); }
  r.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(r);
});
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const ADMIN = { name: 'Test Admin', email: 'boss@test.io', pw: 'AdminPass#2026' };
let passed = 0, failed = 0; const errors = [];
const ok = (m) => { passed++; console.log('  ✓ ' + m); };

async function mk(ctx, name, url) {
  const p = await ctx.newPage();
  p.on('pageerror', e => errors.push(`[${name}] pageerror: ${e.message}`));
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.g|ERR_FAILED|ERR_INTERNET|net::/.test(m.text() + (m.location().url || ''))) errors.push(`[${name}] console: ${m.text()}`); });
  await p.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await p.goto(BASE + url); return p;
}
const hash = (p, h) => p.evaluate(x => { location.hash = x; }, h);
const text = (p, sel) => p.locator(sel).first().innerText();
async function waitText(p, re, timeout = 8000) { await p.waitForFunction(r => new RegExp(r, 'i').test(document.body.innerText), re.source || re, { timeout }); }
async function noOverflow(p, label) {
  const o = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  assert(o.sw <= o.cw + 1, `${label}: horizontal overflow ${o.sw} > ${o.cw}`);
}

(async () => {
  await new Promise(r => server.listen(PORT, r));
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ timezoneId: 'Asia/Kolkata', viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  try {
    console.log('\n[0] JavaScript-disabled (iOS Files Quick Look) shows a helpful message, not a blank page');
    {
      const c = await browser.newContext({ javaScriptEnabled: false }); const p = await c.newPage(); await p.goto(BASE + '/index.html');
      const t = await p.evaluate(() => document.body.innerText); assert(/JavaScript is required/.test(t) && /Safari/.test(t)); ok('noscript message explains Quick Look + Safari'); await c.close();
    }

    console.log('\n[1] Admin first-run + secure login');
    const admin = await mk(ctx, 'admin', '/admin.html');
    await admin.waitForSelector('form[data-form=setup]');
    assert(!(await fs.promises.readFile(path.join(ROOT, 'assets/js/admin.js'), 'utf8')).includes(ADMIN.pw)); ok('no admin credentials exist in source; setup screen shown on first run');
    await admin.fill('[name=name]', ADMIN.name); await admin.fill('[name=email]', ADMIN.email); await admin.fill('[name=pw]', '123');
    assert.strictEqual(await admin.$eval('form[data-form=setup]', f => f.checkValidity()), false); ok('weak admin password blocked (min 8 chars)');
    await admin.fill('[name=pw]', ADMIN.pw); await admin.click('button[type=submit]'); await waitText(admin, /Overview/); ok('admin created and dashboard rendered');
    await admin.reload(); await waitText(admin, /Active employees/); ok('admin session persists after refresh');
    await admin.click('#sidebar [data-act=logout]'); await admin.waitForSelector('form[data-form=login]'); ok('admin logout');
    await admin.fill('[name=id]', ADMIN.email); await admin.fill('[name=pw]', 'wrongpass99'); await admin.click('button[type=submit]'); await waitText(admin, /Incorrect/); ok('wrong admin password rejected');
    await admin.fill('[name=pw]', ADMIN.pw); await admin.click('button[type=submit]'); await waitText(admin, /Active employees/); ok('admin login');

    console.log('\n[2] Admin adds employee (assigns ID + password)');
    await hash(admin, '#/employees'); await admin.waitForSelector('[data-act=add-emp]');
    await admin.click('[data-act=add-emp] >> nth=0'); await admin.waitForSelector('form[data-form=add-emp]');
    await admin.fill('[name=full_name]', 'Aarav Sharma'); await admin.fill('[name=employee_code]', 'EMP001'); await admin.fill('[name=password]', 'Welcome#1234'); await admin.fill('[name=monthly_base_salary]', '26000');
    await admin.click('form[data-form=add-emp] button[type=submit]'); await admin.waitForSelector('#cPw'); assert.strictEqual(await text(admin, '#cPw'), 'Welcome#1234'); ok('employee created; credentials shown once');
    await admin.keyboard.press('Escape'); await waitText(admin, /Aarav Sharma/);
    await admin.click('[data-act=add-emp] >> nth=0'); await admin.fill('[name=full_name]', 'Dup'); await admin.fill('[name=employee_code]', 'emp001'); await admin.click('form[data-form=add-emp] button[type=submit]'); await waitText(admin, /already exists/); ok('duplicate employee ID rejected (case-insensitive)'); await admin.keyboard.press('Escape');

    console.log('\n[3] Employee login / role separation');
    const emp = await mk(ctx, 'employee', '/index.html'); await emp.waitForSelector('form[data-form=login]');
    await emp.fill('[name=id]', 'EMP001'); await emp.fill('[name=pw]', 'nope-nope'); await emp.click('button[type=submit]'); await waitText(emp, /Incorrect/); ok('wrong employee password rejected');
    await emp.fill('[name=id]', ADMIN.email); await emp.fill('[name=pw]', ADMIN.pw); await emp.click('button[type=submit]'); await waitText(emp, /Administrators sign in/); ok('admin account cannot use the employee app');
    await emp.fill('[name=id]', 'emp001'); await emp.fill('[name=pw]', 'Welcome#1234'); await emp.click('button[type=submit]'); await waitText(emp, /START WORK/); ok('employee login (ID is case-insensitive) → dashboard renders');
    const adm2 = await mk(ctx, 'admin-as-emp', '/admin.html'); await adm2.close();

    console.log('\n[4] START WORK → admin approval');
    await emp.click('[data-act=start]'); await waitText(emp, /WAITING FOR APPROVAL/); ok('employee sends start request; button locks');
    await waitText(admin, /New request|Pending requests/); await hash(admin, '#/requests'); await waitText(admin, /Start work/); await waitText(admin, /Aarav Sharma/); ok('admin receives the request (live)');
    assert.strictEqual((await emp.locator('.timer').count()), 0); ok('work has NOT started before approval');
    await admin.fill('[id^=note-]', 'Have a good shift'); await admin.click('[data-act=decide][data-d=approved]'); await waitText(admin, /All caught up/);
    await emp.waitForSelector('.timer', { timeout: 8000 }); await waitText(emp, /ON THE CLOCK/); ok('after approval the employee is on the clock with a live timer');
    const t1 = await text(emp, '#timer'); await emp.waitForTimeout(1300); const t2 = await text(emp, '#timer'); assert.notStrictEqual(t1, t2); ok('timer ticks');

    console.log('\n[5] Reject path');
    await emp.evaluate(() => { const k = 'eos_preview_v1', s = JSON.parse(localStorage.getItem(k)); s.t.work_sessions.forEach(x => { x.started_at = new Date(Date.now() - 5 * 3600000).toISOString(); }); localStorage.setItem(k, JSON.stringify(s)); });
    await emp.click('[data-act=leave]'); await emp.click('[data-act=confirm-yes]'); await waitText(emp, /LEAVE REQUESTED/); ok('LEAVE sends leave request');
    await waitText(admin, /Leave \(end work\)/); await admin.click('[data-act=decide][data-d=rejected]'); await waitText(admin, /All caught up/);
    await waitText(emp, /ON THE CLOCK/); await emp.waitForSelector('[data-act=leave]'); ok('rejected leave keeps the session running and re-enables LEAVE');

    console.log('\n[6] LEAVE approval → hours, pay, points');
    await emp.click('[data-act=leave]'); await emp.click('[data-act=confirm-yes]'); await waitText(emp, /LEAVE REQUESTED/);
    await waitText(admin, /Leave \(end work\)/); await admin.click('[data-act=decide][data-d=approved]'); await waitText(admin, /All caught up/);
    await waitText(emp, /READY TO WORK/, 10000); ok('approved leave ends the session');
    await emp.click('#sidebar a[href="#/history"]'); await waitText(emp, /5h 0\dm|4h 5\dm/); ok('work history records start/end times and ≈5h duration');
    await emp.click('#sidebar a[href="#/home"]'); await waitText(emp, /₹625/); ok('daily earning = 26000/26 × 5h/8h = ₹625 (calculated, not hardcoded)');
    const pts = await emp.evaluate(() => JSON.parse(localStorage.getItem('eos_preview_v1')).t.points_ledger.map(l => l.points).sort((a, b) => a - b));
    assert.deepStrictEqual(pts, [20, 50]); ok('points = 5h × 10 + 20 attendance = 70');

    console.log('\n[7] Salary update, bonus, extra, deduction');
    await hash(admin, '#/employees'); await admin.click('a.item.click >> nth=0'); await admin.click('.seg a:text-is("Pay")');
    await admin.fill('form[data-form=set-salary] [name=salary]', '52000'); await admin.click('form[data-form=set-salary] button'); await waitText(admin, /Salary updated/); ok('salary updated by admin');
    await admin.selectOption('form[data-form=add-entry] [name=type]', 'bonus'); await admin.fill('form[data-form=add-entry] [name=amount]', '500'); await admin.fill('form[data-form=add-entry] [name=description]', 'Quality bonus'); await admin.click('form[data-form=add-entry] button[type=submit]'); await waitText(admin, /Quality bonus/);
    await admin.selectOption('form[data-form=add-entry] [name=type]', 'deduction'); await admin.fill('form[data-form=add-entry] [name=amount]', '200'); await admin.fill('form[data-form=add-entry] [name=description]', 'Late arrival'); await admin.click('form[data-form=add-entry] button[type=submit]'); await waitText(admin, /Late arrival/);
    await admin.selectOption('form[data-form=add-entry] [name=type]', 'extra'); await admin.fill('form[data-form=add-entry] [name=amount]', '300'); await admin.fill('form[data-form=add-entry] [name=description]', 'Weekend shift'); await admin.click('form[data-form=add-entry] button[type=submit]'); await waitText(admin, /Weekend shift/); ok('bonus, deduction and extra earning added');
    await emp.click('#sidebar a[href="#/home"]'); await emp.waitForFunction(() => /₹52,000/.test(document.body.innerText)); ok('employee sees updated monthly salary ₹52,000 live');
    await waitText(emp, /₹1,225/); ok('month net = 625 + 500 + 300 − 200 = ₹1,225 (shown on dashboard)');
    await emp.click('#sidebar a[href="#/earnings"]'); await waitText(emp, /Quality bonus/); await waitText(emp, /Late arrival/); await waitText(emp, /Weekend shift/); ok('earnings page lists every entry');
    await emp.click(`.cal .d.today`); await waitText(emp, /Day total/); ok('earning calendar: selecting today shows sessions + entries');
    await emp.click('[data-act=cal-nav][data-n="-1"]'); await waitText(emp, /No activity|Select a day|No earnings recorded this month/); await emp.click('[data-act=cal-nav][data-n="1"]'); ok('calendar month navigation (previous/next) works in IST');
    await hash(admin, '#/payroll'); await waitText(admin, /Net payroll/); await waitText(admin, /₹1,225/); ok('admin payroll totals match');
    const dl = admin.waitForEvent('download'); await admin.click('[data-act=export-pay]'); const d = await dl; const csv = fs.readFileSync(await d.path(), 'utf8'); assert(/EMP001,Aarav Sharma,52000,625,300,500,200,1225/.test(csv)); ok('payroll CSV export is correct');
    await admin.click('a.item.click, tr.click >> nth=0').catch(() => {});

    console.log('\n[8] Leaderboard, tiers, ranking history');
    await hash(admin, '#/settings'); await admin.click('[data-act=seed]'); await admin.click('[data-act=confirm-yes]'); await waitText(admin, /Sample employees created/, 20000); await admin.keyboard.press('Escape'); ok('sample data seeded through the real engine');
    await hash(admin, '#/ranks'); await admin.click('[data-act=lb-period][data-p=all]'); await waitText(admin, /Priya Singh/); ok('admin leaderboard (all-time) ranks employees');
    await emp.click('#sidebar a[href="#/ranks"]'); await waitText(emp, /Leaderboard/);
    for (const [p, label] of [['daily', 'Daily'], ['weekly', 'Weekly'], ['monthly', 'Monthly'], ['all', 'All-time']]) { await emp.click(`[data-act=lb-period][data-p=${p}]`); await emp.waitForSelector('.lb'); }
    const rowsAll = await emp.locator('.lb').count(); assert(rowsAll >= 5); ok('daily/weekly/monthly/all-time leaderboards render for employee');
    await emp.click('[data-act=lb-period][data-p=daily]'); const daily = await emp.locator('.lb').allInnerTexts(); assert(/Aarav/.test(daily[0]) || /Aarav/.test(daily.join())); ok('today leaderboard includes today\'s work (Aarav)');
    // tier: automatic promotion by points, then manual override and back
    await hash(admin, '#/employees'); await admin.click('a.item.click >> nth=0'); await admin.click('.seg a:text-is("Rank")');
    await admin.fill('form[data-form=adj-points] [name=delta]', '400'); await admin.fill('form[data-form=adj-points] [name=reason]', 'Great quality week'); await admin.click('form[data-form=adj-points] button[type=submit]'); await waitText(admin, /Points updated/);
    await waitText(admin, /Bronze → Silver/); ok('automatic promotion Bronze → Silver at 470 pts (threshold 300)');
    await emp.click('#sidebar a[href="#/notifications"]'); await waitText(emp, /Promoted to Silver/); await waitText(emp, /\+400 points/); ok('employee notified of promotion and points');
    await emp.click('#sidebar a[href="#/earnings"]'); await waitText(emp, /Promotion bonus: Silver/); ok('promotion bonus ₹200 credited as earning');
    await admin.selectOption('form[data-form=set-tier] [name=tier]', 'Platinum'); await admin.fill('form[data-form=set-tier] [name=reason]', 'Promoted by manager'); await admin.click('form[data-form=set-tier] button[type=submit]'); await waitText(admin, /Tier updated/); await waitText(admin, /Silver → Platinum/); ok('admin manually changes tier');
    await emp.click('#sidebar a[href="#/ranks"]'); await waitText(emp, /Silver → Platinum/); await waitText(emp, /Set by admin/); ok('employee sees manual tier in ranking history');
    await admin.selectOption('form[data-form=set-tier] [name=tier]', 'auto'); await admin.click('form[data-form=set-tier] button[type=submit]'); await waitText(admin, /Platinum → Silver/); ok('switching back to Automatic demotes to the points-based tier');
    await admin.click('[data-act=adj-points]').catch(() => {}); await admin.fill('form[data-form=adj-points] [name=delta]', '-300'); await admin.fill('form[data-form=adj-points] [name=reason]', 'Policy breach'); await admin.click('form[data-form=adj-points] button[type=submit]'); await waitText(admin, /Silver → Bronze/); ok('automatic demotion when points fall below threshold');
    await hash(admin, '#/ranks'); await admin.click('[data-act=award-month]'); await admin.click('[data-act=confirm-yes]'); await waitText(admin, /Awarded|Nothing to award/); ok('monthly reward action runs (idempotent, guarded)');

    console.log('\n[9] Resources: admin uploads, employee opens');
    await hash(admin, '#/resources'); await admin.waitForSelector('form[data-form=add-res]');
    await admin.fill('form[data-form=add-res] [name=title]', 'Quality guide'); await admin.setInputFiles('form[data-form=add-res] [name=file]', { name: 'guide.png', mimeType: 'image/png', buffer: PNG }); await admin.click('form[data-form=add-res] button[type=submit]'); await waitText(admin, /Quality guide/);
    await admin.fill('form[data-form=add-res] [name=title]', 'Daily checklist'); await admin.selectOption('form[data-form=add-res] [name=type]', 'instruction'); await admin.fill('form[data-form=add-res] [name=body]', '1. Check inbox\n2. Review tasks'); await admin.click('form[data-form=add-res] button[type=submit]'); await waitText(admin, /Daily checklist/); ok('image upload + text instruction published');
    await admin.fill('form[data-form=add-res] [name=title]', 'No content'); await admin.selectOption('form[data-form=add-res] [name=type]', 'note'); await admin.click('form[data-form=add-res] button[type=submit]'); await waitText(admin, /Write the text for this note/); ok('note without text is rejected with a clear message');
    await emp.click('#sidebar a[href="#/resources"]'); await waitText(emp, /Quality guide/); await waitText(emp, /Daily checklist/);
    await emp.click('[data-act=open-res]:has-text("Quality guide")'); await emp.waitForSelector('.viewer img'); const nw = await emp.$eval('.viewer img', i => i.naturalWidth); assert(nw >= 1); ok('employee opens the uploaded image'); await emp.keyboard.press('Escape');
    await emp.click('[data-act=open-res]:has-text("Daily checklist")'); await waitText(emp, /Review tasks/); ok('employee reads text instruction'); await emp.keyboard.press('Escape');

    console.log('\n[10] Chat with attachment, unread + seen');
    await emp.click('#sidebar a[href="#/chat"]'); await emp.waitForSelector('#chatInput');
    await emp.fill('#chatInput', 'Hello admin, question about today'); await emp.setInputFiles('#chatFile', { name: 'proof.png', mimeType: 'image/png', buffer: PNG }); await waitText(emp, /proof\.png/); await emp.click('form[data-form=chat-send] button[type=submit]');
    await emp.waitForSelector('.bub.me img'); ok('employee message + image attachment sent');
    await waitText(admin, /Unread|Messages/); await hash(admin, '#/messages'); await admin.waitForSelector('.convo .unread'); ok('admin sees unread indicator');
    await admin.click('.convo:has-text("Aarav Sharma")'); await admin.waitForSelector('.bub.them img'); await waitText(admin, /Hello admin, question about today/); ok('admin opens thread and sees text + image');
    await admin.fill('#chatInput', 'Replying now'); await admin.click('form[data-form=chat-send] button[type=submit]'); await waitText(admin, /Replying now/);
    await waitText(emp, /Replying now/); await waitText(emp, /Seen/); ok('admin → employee message delivered live; employee message shows Seen');
    await hash(admin, '#/messages/announcements'); await admin.fill('form[data-form=post-ann] [name=title]', 'Holiday notice'); await admin.fill('form[data-form=post-ann] [name=body]', 'Office closed Friday'); await admin.click('form[data-form=post-ann] button[type=submit]'); await waitText(admin, /Announcement sent/);
    await emp.click('[data-act=chat-tab][data-t=ann]'); await waitText(emp, /Office closed Friday/); ok('team announcement reaches employee');

    console.log('\n[11] Day-off request + approval');
    await emp.click('#sidebar a[href="#/history"]'); await emp.click('[data-act=dayoff]'); const tmr = await emp.inputValue('form[data-form=dayoff] [name=date]'); await emp.fill('form[data-form=dayoff] [name=reason]', 'Family function'); await emp.click('form[data-form=dayoff] button[type=submit]'); await waitText(emp, /Day-off request sent/);
    await hash(admin, '#/requests'); await waitText(admin, /Family function/); await admin.click('[data-act=decide][data-d=approved]'); await waitText(admin, /All caught up/);
    await emp.click('#sidebar a[href="#/history"]'); await waitText(emp, /approved/); ok('day-off request approved by admin and visible to employee');

    console.log('\n[12] Profile, password change, persistence after refresh');
    await emp.click('#sidebar a[href="#/profile"]'); await emp.fill('form[data-form=profile] [name=phone]', '+91 99999 00000'); await emp.click('form[data-form=profile] button[type=submit]'); await waitText(emp, /Profile saved/);
    await emp.fill('form[data-form=password] [name=pw1]', 'NewSecret#555'); await emp.fill('form[data-form=password] [name=pw2]', 'Mismatch#555'); await emp.click('form[data-form=password] button[type=submit]'); await waitText(emp, /do not match/);
    await emp.fill('form[data-form=password] [name=pw1]', 'NewSecret#555'); await emp.fill('form[data-form=password] [name=pw2]', 'NewSecret#555'); await emp.click('form[data-form=password] button[type=submit]'); await waitText(emp, /Password updated/); ok('profile + password change (with validation)');
    await emp.goto(BASE + '/index.html#/earnings'); await waitText(emp, /Quality guide|Promotion bonus|Work pay/); await waitText(emp, /Late arrival/); ok('data and login persist after full page refresh');
    await emp.click('#sidebar [data-act=logout]'); await emp.waitForSelector('form[data-form=login]'); await emp.fill('[name=id]', 'EMP001'); await emp.fill('[name=pw]', 'Welcome#1234'); await emp.click('button[type=submit]'); await waitText(emp, /Incorrect/); await emp.fill('[name=pw]', 'NewSecret#555'); await emp.click('button[type=submit]'); await waitText(emp, /START WORK/); ok('logout; old password rejected; new password works');

    await emp.click('#sidebar a[href="#/home"]'); await emp.waitForTimeout(500); await emp.screenshot({ path: path.join(__dirname, 'shots', 'desktop-employee-home.png') });
    await hash(admin, '#/employees'); await admin.waitForTimeout(500); await admin.screenshot({ path: path.join(__dirname, 'shots', 'desktop-admin-employees.png') });
    console.log('\n[13] Permissions: employee cannot reach admin data');
    const sec = await emp.evaluate(async () => {
      const out = {}; const db = EOS.db;
      for (const [k, fn] of Object.entries({
        raiseSalary: () => db.update('profiles', { eq: { id: EOS.me.id } }, { monthly_base_salary: 1e7 }),
        addBonus: () => db.insert('earning_entries', { employee_id: EOS.me.id, entry_type: 'bonus', amount: 9999, entry_date: '2026-11-21' }),
        selfApprove: () => db.insert('work_requests', { employee_id: EOS.me.id, request_type: 'start', status: 'approved' }),
        addPoints: () => db.insert('points_ledger', { employee_id: EOS.me.id, points: 9999, reason: 'x', source: 'manual' }),
        createUser: () => db.admin.createEmployee({ employee_code: 'HACK1', full_name: 'Hacker', password: 'password123' }),
        publish: () => db.insert('resources', { title: 'x', resource_type: 'note' })
      })) { try { const r = await fn(); out[k] = (Array.isArray(r) && r.length === 0) ? 'blocked' : 'ALLOWED'; } catch (e) { out[k] = 'blocked'; } }
      out.sees = (await db.list('profiles')).length; out.ledger = (await db.list('points_ledger')).every(l => l.employee_id === EOS.me.id);
      return out;
    });
    assert(Object.entries(sec).filter(([k]) => !['sees', 'ledger'].includes(k)).every(([, v]) => v === 'blocked'), JSON.stringify(sec)); assert.strictEqual(sec.sees, 1); assert(sec.ledger); ok('employee API calls to salary/bonus/approve/points/create-user/publish are all blocked; sees only own profile & ledger');
    {
      const st = await emp.evaluate(() => [localStorage.getItem('eos_preview_v1'), localStorage.getItem('eos_session_employee')]);
      const c2 = await browser.newContext(); const p2 = await c2.newPage(); await p2.route(/fonts\./, r => r.abort()); await p2.goto(BASE + '/index.html');
      await p2.evaluate(a => { localStorage.setItem('eos_preview_v1', a[0]); localStorage.setItem('eos_session_employee', a[1]); }, st);
      await p2.goto(BASE + '/admin.html'); await p2.waitForSelector('form[data-form=login]'); ok('an employee session does not unlock the admin portal');
      await p2.fill('[name=id]', 'EMP001'); await p2.fill('[name=pw]', 'NewSecret#555'); await p2.click('button[type=submit]'); await waitText(p2, /Incorrect|administrators only/i); ok('employee credentials are refused by the admin portal');
      await c2.close();
    }

    console.log('\n[14] Suspend → employee is signed out; reactivate');
    await hash(admin, '#/employees'); await admin.click('a.item.click:has-text("Aarav")'); await admin.click('[data-act=suspend]'); await admin.click('[data-act=confirm-yes]'); await waitText(admin, /Suspended/);
    await waitText(emp, /no longer active/, 12000); ok('suspended employee is signed out live');
    await emp.fill('[name=id]', 'EMP001'); await emp.fill('[name=pw]', 'NewSecret#555'); await emp.click('button[type=submit]'); await waitText(emp, /suspended/i); ok('suspended employee cannot log in');
    await admin.click('[data-act=reactivate]'); await waitText(admin, /Reactivated/); await emp.click('button[type=submit]'); await waitText(emp, /START WORK/); ok('reactivated employee can log in again');

    console.log('\n[15] Settings: rule validation and edit');
    await hash(admin, '#/settings'); await admin.fill('form[data-form=rules] [name=t_Gold]', '100'); await admin.click('form[data-form=rules] button[type=submit]'); await waitText(admin, /must increase/); ok('invalid tier thresholds rejected');
    await admin.fill('form[data-form=rules] [name=t_Gold]', '700'); await admin.fill('form[data-form=rules] [name=per_hour]', '12'); await admin.click('form[data-form=rules] button[type=submit]'); await waitText(admin, /Rules saved/); ok('rules saved');

    console.log('\n[16] Remove employee deletes records');
    await hash(admin, '#/employees'); await admin.click('a.item.click:has-text("Kabir")'); await admin.click('[data-act=remove-emp]'); await admin.click('[data-act=confirm-yes]'); await waitText(admin, /Employee removed/);
    const gone = await admin.evaluate(() => { const s = JSON.parse(localStorage.getItem('eos_preview_v1')); return s.t.profiles.some(p => p.full_name === 'Kabir Verma') || s.users.length !== s.t.profiles.length; }); assert(!gone); ok('employee + login removed');

    console.log('\n[17] iPhone viewport: layout, safe areas, no overflow');
    const m = await browser.newContext({ ...devices['iPhone 14'], timezoneId: 'Asia/Kolkata' });
    // share state: copy localStorage from main ctx
    const ls = await emp.evaluate(() => localStorage.getItem('eos_preview_v1')); const mp = await m.newPage(); mp.on('pageerror', e => errors.push('[mobile] ' + e.message));
    await mp.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await mp.goto(BASE + '/index.html'); await mp.evaluate(s => localStorage.setItem('eos_preview_v1', s), ls); await mp.reload(); await mp.waitForSelector('form[data-form=login]'); await noOverflow(mp, 'login');
    await mp.fill('[name=id]', 'EMP001'); await mp.fill('[name=pw]', 'NewSecret#555'); await mp.click('button[type=submit]'); await mp.waitForSelector('.startbtn');
    const css = await mp.evaluate(() => ({ tabbar: getComputedStyle(document.getElementById('tabbar')).display, sidebar: getComputedStyle(document.getElementById('sidebar')).display, vp: document.querySelector('meta[name=viewport]').content, fs: getComputedStyle(document.querySelector('.startbtn')).minHeight }));
    assert.strictEqual(css.tabbar, 'flex'); assert.strictEqual(css.sidebar, 'none'); assert(/viewport-fit=cover/.test(css.vp)); ok('mobile: bottom tab bar shown, sidebar hidden, viewport-fit=cover');
    const cssText = fs.readFileSync(path.join(ROOT, 'assets/styles.css'), 'utf8'); assert(/env\(safe-area-inset-bottom/.test(cssText) && /env\(safe-area-inset-top/.test(cssText)); ok('safe-area insets applied to top bar, tab bar, sheets');
    for (const pg of ['home', 'earnings', 'ranks', 'chat', 'more', 'history', 'resources', 'notifications', 'profile']) {
      await mp.evaluate(h => { location.hash = h; }, '#/' + pg); await mp.waitForTimeout(450); await noOverflow(mp, 'employee/' + pg);
      const blank = await mp.evaluate(() => document.getElementById('view').innerText.trim().length); assert(blank > 20, pg + ' rendered blank');
    }
    ok('all 9 employee pages render and fit 390px width with no horizontal scroll');
    await mp.evaluate(() => { location.hash = '#/home'; }); await mp.waitForTimeout(400); await mp.screenshot({ path: path.join(__dirname, 'shots', 'mobile-home.png') });
    await mp.evaluate(() => { location.hash = '#/ranks'; }); await mp.waitForTimeout(600); await mp.screenshot({ path: path.join(__dirname, 'shots', 'mobile-ranks.png') });
    await mp.evaluate(() => { location.hash = '#/chat'; }); await mp.waitForTimeout(500); await mp.screenshot({ path: path.join(__dirname, 'shots', 'mobile-chat.png') });
    const ap = await m.newPage(); ap.on('pageerror', e => errors.push('[mobile-admin] ' + e.message)); await ap.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await ap.goto(BASE + '/admin.html'); await ap.evaluate(s => localStorage.setItem('eos_preview_v1', s), ls); await ap.reload(); await ap.waitForSelector('form[data-form=login]');
    await ap.fill('[name=id]', ADMIN.email); await ap.fill('[name=pw]', ADMIN.pw); await ap.click('button[type=submit]'); await waitText(ap, /Active employees/);
    for (const pg of ['overview', 'requests', 'employees', 'payroll', 'attendance', 'ranks', 'resources', 'messages', 'settings', 'more']) {
      await ap.evaluate(h => { location.hash = h; }, '#/' + pg); await ap.waitForTimeout(450); await noOverflow(ap, 'admin/' + pg);
      assert((await ap.evaluate(() => document.getElementById('view').innerText.trim().length)) > 15, 'admin ' + pg + ' blank');
    }
    ok('all admin pages render and fit 390px width');
    await ap.evaluate(() => { location.hash = '#/overview'; }); await ap.waitForTimeout(400); await ap.screenshot({ path: path.join(__dirname, 'shots', 'mobile-admin.png') });
    await m.close();

    console.log('\n[18] No JavaScript errors in any tab');
    assert.strictEqual(errors.length, 0, errors.join('\n')); ok('zero page errors / console errors across the whole run');
  } catch (e) {
    failed++; console.error('\n✗ FAILED:', e.message);
    for (const [n, pg] of Object.entries({})) { /* noop */ }
    try { const pages = ctx.pages(); for (let i = 0; i < pages.length; i++) await pages[i].screenshot({ path: path.join(__dirname, 'shots', `fail-${i}.png`) }); } catch (x) {}
    if (errors.length) console.error('Collected errors:\n' + errors.join('\n'));
  } finally { await browser.close(); server.close(); }
  console.log(`\n${passed} checks passed${failed ? ', FAILED' : ', 0 failed'}`); process.exit(failed ? 1 : 0);
})();

/* Run: node tests/engine.test.js  - unit tests for pure business rules (no browser, no backend). */
const assert = require('assert');
globalThis.EOS_APP = 'admin';
require('../assets/js/util.js'); require('../assets/js/data.js'); require('../assets/js/engine.js');
const E = EOS.engine, U = EOS.util, R = E.mergeRules();
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };

t('daily rate and prorated pay', () => {
  assert.strictEqual(E.dailyRate(26000, R), 1000);
  assert.strictEqual(E.dayPay(26000, R, 8), 1000);
  assert.strictEqual(E.dayPay(26000, R, 4), 500);
  assert.strictEqual(E.dayPay(26000, R, 12), 1000, 'capped at one daily rate');
  assert.strictEqual(E.dayPay(26000, R, 0), 0);
  assert.strictEqual(E.dayPay(0, R, 8), 0);
});
t('tier thresholds', () => {
  assert.strictEqual(E.tierForPoints(0, R), 'Bronze');
  assert.strictEqual(E.tierForPoints(299, R), 'Bronze');
  assert.strictEqual(E.tierForPoints(300, R), 'Silver');
  assert.strictEqual(E.tierForPoints(1600, R), 'Platinum');
  assert.strictEqual(E.tierForPoints(99999, R), 'Diamond');
  assert.strictEqual(E.tierForPoints(-50, R), 'Bronze');
});
t('tier progress', () => {
  const p = E.tierProgress(550, 'Silver', R); // 300 -> 800
  assert.strictEqual(p.next, 'Gold'); assert.strictEqual(p.pct, 50); assert.strictEqual(p.remaining, 250);
  assert.strictEqual(E.tierProgress(5000, 'Diamond', R).next, null);
});
t('ranking with ties', () => {
  const r = E.rankRows([{ full_name: 'B', points: 10 }, { full_name: 'A', points: 10 }, { full_name: 'C', points: 30 }, { full_name: 'D', points: 5 }]);
  assert.deepStrictEqual(r.map(x => [x.full_name, x.rank]), [['C', 1], ['A', 2], ['B', 2], ['D', 4]]);
});
t('summaries', () => {
  const entries = [
    { entry_date: '2026-11-03', entry_type: 'daily', amount: 1000 }, { entry_date: '2026-11-04', entry_type: 'daily', amount: 500 },
    { entry_date: '2026-11-04', entry_type: 'extra', amount: 200 }, { entry_date: '2026-11-05', entry_type: 'bonus', amount: 300 },
    { entry_date: '2026-11-05', entry_type: 'deduction', amount: 150 }, { entry_date: '2026-10-30', entry_type: 'daily', amount: 999 }];
  const sessions = [{ work_date: '2026-11-03', hours: 8, ended_at: 'x' }, { work_date: '2026-11-04', hours: 4, ended_at: 'x' }, { work_date: '2026-11-04', hours: 1, ended_at: 'x' }, { work_date: '2026-11-06', hours: 3, ended_at: null }];
  const s = E.summarize(entries, sessions, '2026-11', '2026-11-04');
  assert.strictEqual(s.month.daily, 1500); assert.strictEqual(s.month.extra, 200); assert.strictEqual(s.month.bonus, 300);
  assert.strictEqual(s.month.deduction, 150); assert.strictEqual(s.month.net, 1850);
  assert.strictEqual(s.month.days, 2); assert.strictEqual(s.month.hours, 13);
  assert.strictEqual(s.today.net, 700); assert.strictEqual(s.today.hours, 5);
  assert.strictEqual(s.total.net, 2849);
});
t('dates are local, not UTC-shifted', () => {
  assert.strictEqual(U.addMonths('2026-11', -1), '2026-10'); assert.strictEqual(U.addMonths('2026-01', -1), '2025-12');
  assert.strictEqual(U.addDays('2026-03-01', -1), '2026-02-28'); assert.strictEqual(U.dateKey(new Date(2026, 9, 1)), '2026-10-01');
});
t('rules validation', () => {
  assert.ok(E.validateRules(E.mergeRules()));
  const bad = E.mergeRules(); bad.tiers.thresholds.Gold = 100; assert.throws(() => E.validateRules(bad), /increase/);
  const bad2 = E.mergeRules(); bad2.pay.working_days = 0; assert.throws(() => E.validateRules(bad2));
});
t('money keeps cents only when needed', () => { assert.strictEqual(U.money(13193.3), '₹13,193.30'); assert.strictEqual(U.money(1250), '₹1,250'); assert.strictEqual(U.money(-200), '-₹200'); });
t('html templating escapes user input', () => {
  const evil = '<img src=x onerror=alert(1)>';
  assert.ok(!String(U.html`<b>${evil}</b>`).includes('<img'));
  assert.strictEqual(String(U.html`<i>${U.raw('<u>ok</u>')}</i>`), '<i><u>ok</u></i>');
});
t('period boundaries', () => {
  const now = new Date(2026, 10, 18, 15, 0); // Wed 18 Nov 2026
  assert.strictEqual(new Date(E.periodSince('weekly', now)).getDate(), 16); // Monday
  assert.strictEqual(new Date(E.periodSince('monthly', now)).getDate(), 1);
  assert.strictEqual(E.periodSince('all', now), null);
});
console.log(n + ' tests passed');

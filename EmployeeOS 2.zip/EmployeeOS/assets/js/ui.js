/* EmployeeOS ui.js - DOM helpers: icons, 3D tier badges, toast, modal, event delegation, boot/error screens. */
(function (root) {
  'use strict';
  var EOS = root.EOS = root.EOS || {};
  var U = EOS.util, html = U.html, raw = U.raw;
  var ui = EOS.ui = {};

  /* ---------- icons (24px stroke icons) ---------- */
  var ICONS = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    wallet: '<path d="M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7l12-3v3"/><circle cx="17" cy="13.5" r="1"/>',
    trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
    chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
    grid: '<rect x="4" y="4" width="6" height="6" rx="1.5"/><rect x="14" y="4" width="6" height="6" rx="1.5"/><rect x="4" y="14" width="6" height="6" rx="1.5"/><rect x="14" y="14" width="6" height="6" rx="1.5"/>',
    bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    clip: '<path d="M21 11.5l-8.5 8.5a5.5 5.5 0 0 1-8-8L13 3.5a3.7 3.7 0 0 1 5.3 5.3L9.8 17.3a1.8 1.8 0 0 1-2.6-2.6L15 7"/>',
    file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
    play: '<path d="M8 5l11 7-11 7z"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 9"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    left: '<path d="M15 5l-7 7 7 7"/>', right: '<path d="M9 5l7 7-7 7"/>',
    dash: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    inbox: '<path d="M4 13l3-8h10l3 8v6H4z"/><path d="M4 13h5l1 2h4l1-2h5"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    mega: '<path d="M3 11v3a1 1 0 0 0 1 1h3l8 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M19 9a4 4 0 0 1 0 6"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14-4M4 13a8 8 0 0 0 14 4"/><path d="M20 4v5h-5M4 20v-5h5"/>',
    coffee: '<path d="M4 9h12v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M16 11h2a2 2 0 0 1 0 4h-2M8 3v3M12 3v3"/>',
    star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>'
  };
  ui.icon = function (name, cls) {
    return raw('<svg class="ico ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (ICONS[name] || ICONS.info) + '</svg>');
  };

  /* ---------- premium 3D-style tier badges (inline SVG: bevelled rim, glossy face, embossed emblem) ---------- */
  var TS = {
    Bronze: { hi: '#f8cfa4', mid: '#cd7b3a', lo: '#6a3512', glow: '#e0905066' },
    Silver: { hi: '#ffffff', mid: '#b6bfce', lo: '#596273', glow: '#c9d3e566' },
    Gold: { hi: '#fff5b8', mid: '#eaa92b', lo: '#855006', glow: '#f6c96b88' },
    Platinum: { hi: '#f6feff', mid: '#8fd6ea', lo: '#336579', glow: '#7fe0f788' },
    Diamond: { hi: '#ffffff', mid: '#a4deff', lo: '#5557ee', glow: '#8aa4ffaa' }
  };
  var seq = 0;
  function star(cx, cy, ro, ri, n) {
    var pts = [];
    for (var i = 0; i < n * 2; i++) { var r = i % 2 ? ri : ro, a = -Math.PI / 2 + i * Math.PI / n; pts.push((cx + r * Math.cos(a)).toFixed(2) + ',' + (cy + r * Math.sin(a)).toFixed(2)); }
    return pts.join(' ');
  }
  ui.badge = function (tier, size) {
    size = size || 64; var s = TS[tier] || TS.Bronze, id = 'tb' + (++seq);
    var emblem = tier === 'Diamond'
      ? '<polygon points="50,30 66,43 50,72 34,43" fill="url(#' + id + 'e)"/><polygon points="34,43 66,43 50,30" fill="#fff" opacity=".55"/><polygon points="34,43 50,72 50,43" fill="#000" opacity=".12"/><path d="M34 43h32M50 30v13" stroke="#fff" stroke-opacity=".6" stroke-width=".8" fill="none"/>'
      : '<polygon points="' + star(51, 52.5, 21, 9, 5) + '" fill="#000" opacity=".38"/><polygon points="' + star(50, 50, 21, 9, 5) + '" fill="url(#' + id + 'e)" stroke="' + s.lo + '" stroke-opacity=".5" stroke-width=".8"/>';
    var pips = { Bronze: 1, Silver: 2, Gold: 3, Platinum: 4, Diamond: 5 }[tier] || 1, dots = '';
    for (var i = 0; i < pips; i++) dots += '<circle cx="' + (50 + (i - (pips - 1) / 2) * 7) + '" cy="80" r="2.2" fill="' + s.hi + '" stroke="' + s.lo + '" stroke-width=".6"/>';
    var svg = '<svg class="badge3d" style="--glow:' + s.glow + '" width="' + size + '" height="' + Math.round(size * 1.04) + '" viewBox="0 0 100 104" role="img" aria-label="' + tier + ' tier">' +
      '<defs>' +
      '<linearGradient id="' + id + 'r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + s.hi + '"/><stop offset=".45" stop-color="' + s.mid + '"/><stop offset="1" stop-color="' + s.lo + '"/></linearGradient>' +
      '<linearGradient id="' + id + 'f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + s.mid + '"/><stop offset=".55" stop-color="' + s.lo + '"/><stop offset="1" stop-color="' + s.mid + '"/></linearGradient>' +
      '<linearGradient id="' + id + 'e" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff"/><stop offset=".5" stop-color="' + s.hi + '"/><stop offset="1" stop-color="' + s.mid + '"/></linearGradient>' +
      '<linearGradient id="' + id + 'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>' +
      '</defs>' +
      '<polygon points="50,3 92,26 92,76 50,100 8,76 8,26" fill="url(#' + id + 'r)"/>' +
      '<polygon points="50,3 92,26 92,76 50,100 8,76 8,26" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="1"/>' +
      '<polygon points="50,11 84,30 84,72 50,92 16,72 16,30" fill="url(#' + id + 'f)"/>' +
      '<path d="M16 30L50 11L84 30" fill="none" stroke="#fff" stroke-opacity=".6" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M16 72L50 92L84 72" fill="none" stroke="#000" stroke-opacity=".35" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M16 30L50 11L84 30L84 46Q50 62 16 46Z" fill="url(#' + id + 'g)"/>' +
      emblem + dots + '</svg>';
    return raw(svg);
  };
  ui.tierPill = function (tier) {
    var c = { Bronze: 'gold', Silver: 'gray', Gold: 'gold', Platinum: 'blue', Diamond: 'blue' }[tier] || 'gray';
    return html`<span class="pill ${c}">${tier}</span>`;
  };
  ui.avatar = function (name, sm) { return html`<div class="avatar ${sm ? 'sm' : ''}">${U.initials(name)}</div>`; };
  ui.empty = function (icon, text) { return html`<div class="empty">${ui.icon(icon || 'info')}<div>${text}</div></div>`; };
  ui.skeleton = function (n) { var o = ''; for (var i = 0; i < (n || 3); i++) o += '<div class="skeleton" style="height:' + (i ? 84 : 150) + 'px;margin-bottom:12px"></div>'; return raw(o); };

  /* ---------- toast ---------- */
  ui.toast = function (msg, kind) {
    var host = document.getElementById('toasts');
    if (!host) { host = document.createElement('div'); host.id = 'toasts'; host.className = 'toasts'; host.setAttribute('aria-live', 'polite'); document.body.appendChild(host); }
    var t = document.createElement('div'); t.className = 'toast ' + (kind || ''); t.textContent = msg; host.appendChild(t);
    setTimeout(function () { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(function () { t.remove(); }, 320); }, kind === 'err' ? 4600 : 2600);
  };
  ui.ok = function (m) { ui.toast(m, 'ok'); };
  function logErr(e) { var bug = e instanceof TypeError || e instanceof ReferenceError || e instanceof SyntaxError || e instanceof RangeError; (bug ? console.error : console.info)(e); }
  var lastFail = 0;
  ui.fail = function (e) {
    logErr(e);
    var now = Date.now(); if (now - lastFail < 800) return; lastFail = now;
    ui.toast((EOS.friendly ? EOS.friendly(e) : (e && e.message) || 'Something went wrong'), 'err');
  };

  /* ---------- modal ---------- */
  var stack = [];
  ui.modal = function (o) {
    var ov = document.createElement('div'); ov.className = 'overlay'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true');
    ov.innerHTML = '<div class="sheet ' + (o.wide ? 'wide' : '') + '"><div class="grab"></div><div class="sheet-head"><h2>' + U.esc(o.title || '') + '</h2><button type="button" class="iconbtn" data-act="modal-close" aria-label="Close">' + ui.icon('x') + '</button></div><div class="sheet-body"></div></div>';
    var body = ov.querySelector('.sheet-body');
    var m = {
      el: ov, body: body,
      set: function (h) { body.innerHTML = String(h); },
      close: function (val) { if (m.closed) return; m.closed = true; ov.remove(); stack = stack.filter(function (x) { return x !== m; }); if (!stack.length) document.body.style.overflow = ''; if (o.onClose) o.onClose(val); if (m.resolve) m.resolve(val); }
    };
    m.set(o.body || '');
    ov.addEventListener('click', function (e) { if (e.target === ov) m.close(); });
    document.body.appendChild(ov); stack.push(m); document.body.style.overflow = 'hidden';
    if (o.onOpen) o.onOpen(m);
    var f = ov.querySelector('input:not([type=hidden]),textarea,select'); if (f && !/iPhone|iPad/.test(navigator.userAgent)) f.focus();
    return m;
  };
  ui.topModal = function () { return stack[stack.length - 1] || null; };
  ui.closeAllModals = function () { stack.slice().forEach(function (m) { m.close(); }); };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && stack.length) stack[stack.length - 1].close(); });
  ui.confirm = function (o) {
    return new Promise(function (resolve) {
      var m = ui.modal({
        title: o.title || 'Are you sure?',
        body: html`<p class="muted">${o.body || ''}</p><div class="row" style="margin-top:18px;justify-content:flex-end"><button type="button" class="btn ghost" data-act="modal-close">${o.cancel || 'Cancel'}</button><button type="button" class="btn ${o.danger ? 'danger' : ''}" data-act="confirm-yes">${o.ok || 'Confirm'}</button></div>`,
        onClose: function (v) { resolve(v === true); }
      });
      m.el.querySelector('[data-act=confirm-yes]').addEventListener('click', function () { m.close(true); });
    });
  };

  /* ---------- event delegation ---------- */
  var actions = {}, forms = {}, changes = {};
  ui.register = function (a, f, c) { Object.assign(actions, a || {}); Object.assign(forms, f || {}); Object.assign(changes, c || {}); };
  function busyRun(btn, fn) {
    if (btn && (btn.disabled || btn.classList.contains('is-busy'))) return Promise.resolve();
    if (btn) { btn.classList.add('is-busy'); btn.disabled = true; }
    return Promise.resolve().then(fn).catch(ui.fail).then(function () { if (btn && btn.isConnected) { btn.classList.remove('is-busy'); btn.disabled = false; } });
  }
  ui.busy = busyRun;
  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-act]') : null; if (!t) return;
    var name = t.getAttribute('data-act');
    if (name === 'modal-close') { var tm = ui.topModal(); if (tm) tm.close(); return; }
    var fn = actions[name]; if (!fn) return;
    if (t.tagName === 'A' && !t.getAttribute('href')) e.preventDefault();
    var isBtn = t.tagName === 'BUTTON';
    busyRun(isBtn ? t : null, function () { return fn(t, e); });
  });
  document.addEventListener('submit', function (e) {
    var f = e.target.closest ? e.target.closest('form[data-form]') : null; if (!f) return;
    e.preventDefault();
    var fn = forms[f.getAttribute('data-form')]; if (!fn) return;
    var btn = f.querySelector('button[type=submit]'); var errBox = f.querySelector('[data-err]'); if (errBox) errBox.classList.add('hidden');
    var values = {}; new FormData(f).forEach(function (v, k) { values[k] = v; });
    if (btn && (btn.disabled || btn.classList.contains('is-busy'))) return;
    if (btn) { btn.classList.add('is-busy'); btn.disabled = true; }
    Promise.resolve().then(function () { return fn(f, values, e); }).catch(function (err) {
      logErr(err); var msg = EOS.friendly ? EOS.friendly(err) : err.message;
      if (errBox) { errBox.textContent = msg; errBox.classList.remove('hidden'); } else ui.toast(msg, 'err');
    }).then(function () { if (btn && btn.isConnected) { btn.classList.remove('is-busy'); btn.disabled = false; } });
  });
  document.addEventListener('change', function (e) {
    var t = e.target.closest ? e.target.closest('[data-change]') : null; if (!t) return;
    var fn = changes[t.getAttribute('data-change')]; if (fn) Promise.resolve().then(function () { return fn(t, e); }).catch(ui.fail);
  });

  /* ---------- boot / fatal ---------- */
  ui.hideBoot = function () { var b = document.getElementById('boot'); if (b) b.remove(); if (root.__bootTimer) clearTimeout(root.__bootTimer); };
  ui.fatal = function (err, retry) {
    var root_ = document.getElementById('root'); if (!root_) return; ui.hideBoot();
    root_.innerHTML = String(html`<div class="center-screen"><div class="card fatal stack"><h2>Couldn't start EmployeeOS</h2><div class="err">${EOS.friendly ? EOS.friendly(err) : (err && err.message)}</div><p class="muted small">Check your internet connection. If this keeps happening, tell your administrator the message above.</p><button class="btn block" data-act="reload">Try again</button></div></div>`);
    ui.register({ reload: function () { if (retry) retry(); else location.reload(); } });
  };
  var shown = false;
  root.addEventListener('error', function (e) { if (shown) return; shown = true; setTimeout(function () { shown = false; }, 4000); if (e && e.message) ui.toast('Unexpected error: ' + e.message, 'err'); });
  root.addEventListener('unhandledrejection', function (e) { ui.fail(e.reason || new Error('Unexpected error')); });

  /* ---------- hash router ---------- */
  ui.parseHash = function () { var h = (location.hash || '').replace(/^#\/?/, ''); return h ? h.split('/').map(decodeURIComponent) : []; };
  ui.go = function (path) { var n = '#/' + path; if (location.hash === n) root.dispatchEvent(new Event('hashchange')); else location.hash = n; };

  /* ---------- misc ---------- */
  ui.fileIcon = function (kind) { return { image: 'image', video: 'play', pdf: 'file', document: 'file', note: 'book', instruction: 'book' }[kind] || 'file'; };
  ui.form = {
    lbl: function (text, input, cls) { return html`<label class="lbl ${cls || ''}">${text}${input}</label>`; }
  };
  /* Opens a file (resource / chat attachment) in a viewer modal */
  ui.viewFile = async function (bucket, path, name, mime, title) {
    var kind = U.fileKind(mime, name);
    var url = await EOS.db.files.url(bucket, path);
    var body;
    if (kind === 'image') body = html`<div class="viewer"><img src="${url}" alt="${name}"></div>`;
    else if (kind === 'video') body = html`<div class="viewer"><video src="${url}" controls playsinline preload="metadata"></video></div>`;
    else if (kind === 'pdf') body = html`<div class="viewer"><iframe src="${url}" title="${name}"></iframe></div><p class="muted small" style="margin-top:8px">If the PDF does not show on your phone, use Open in new tab.</p>`;
    else body = html`<div class="notice">This file type can't be previewed here. Use Download to open it.</div>`;
    ui.modal({ title: title || name, wide: true, body: html`${body}<div class="row" style="margin-top:14px"><a class="btn ghost sm" href="${url}" target="_blank" rel="noopener">Open in new tab</a><a class="btn sm" href="${url}" download="${name}">${ui.icon('download', 'sm')} Download</a></div>` });
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = EOS;
})(typeof window !== 'undefined' ? window : globalThis);

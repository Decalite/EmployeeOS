/* EmployeeOS util.js - pure helpers (no DOM needed except download()). Safari 14+ compatible. */
(function (root) {
  'use strict';
  var EOS = root.EOS = root.EOS || {};
  var cfgIn = root.EOS_CONFIG || {};
  var U = EOS.util = {};

  /* ---------- safe HTML templating ---------- */
  function SafeStr(s) { this.s = s; }
  SafeStr.prototype.toString = function () { return this.s; };
  U.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.raw = function (s) { return new SafeStr(String(s == null ? '' : s)); };
  function val(v) {
    if (v instanceof SafeStr) return v.s;
    if (Array.isArray(v)) return v.map(val).join('');
    if (v == null || v === false) return '';
    return U.esc(v);
  }
  /* html`...${userValue}...` escapes every interpolation unless it is already SafeStr / array of SafeStr */
  U.html = function (strings) {
    var out = strings[0];
    for (var i = 1; i < arguments.length; i++) out += val(arguments[i]) + strings[i];
    return new SafeStr(out);
  };

  /* ---------- ids / numbers ---------- */
  U.uid = function () {
    try { if (root.crypto && root.crypto.randomUUID) return root.crypto.randomUUID(); } catch (e) {}
    var d = Date.now();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (d + Math.random() * 16) % 16 | 0; d = Math.floor(d / 16);
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  };
  U.round2 = function (n) { return Math.round((Number(n) || 0) * 100) / 100; };
  U.sum = function (arr, fn) { var t = 0; for (var i = 0; i < arr.length; i++) t += Number(fn ? fn(arr[i]) : arr[i]) || 0; return t; };
  U.groupBy = function (arr, fn) { var o = {}; arr.forEach(function (x) { var k = fn(x); (o[k] = o[k] || []).push(x); }); return o; };
  U.byId = function (arr, key) { var o = {}; arr.forEach(function (x) { o[x[key || 'id']] = x; }); return o; };
  U.debounce = function (fn, ms) { var t; return function () { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { fn.apply(s, a); }, ms); }; };
  U.pick = function (o, keys) { var r = {}; keys.forEach(function (k) { if (o[k] !== undefined) r[k] = o[k]; }); return r; };
  U.clone = function (o) { return o === undefined ? undefined : JSON.parse(JSON.stringify(o)); };

  /* ---------- dates (ALL local-time; never use toISOString().slice for dates) ---------- */
  function p2(n) { return n < 10 ? '0' + n : '' + n; }
  U.dateKey = function (d) { d = d || new Date(); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); };
  U.todayKey = function () { return U.dateKey(new Date()); };
  U.parseKey = function (k) { var a = String(k).slice(0, 10).split('-'); return new Date(+a[0], +a[1] - 1, +a[2]); };
  U.addDays = function (k, n) { var d = U.parseKey(k); d.setDate(d.getDate() + n); return U.dateKey(d); };
  U.monthKey = function (d) { d = d || new Date(); return d.getFullYear() + '-' + p2(d.getMonth() + 1); };
  U.addMonths = function (mk, n) { var a = mk.split('-'); var d = new Date(+a[0], +a[1] - 1 + n, 1); return U.monthKey(d); };
  U.monthDays = function (mk) { var a = mk.split('-'); return new Date(+a[0], +a[1], 0).getDate(); };
  U.monthStart = function (mk) { var a = mk.split('-'); return new Date(+a[0], +a[1] - 1, 1); };
  U.monthLabel = function (mk) { return U.monthStart(mk).toLocaleString('en', { month: 'long', year: 'numeric' }); };
  U.startOfDay = function (d) { d = new Date(d || Date.now()); d.setHours(0, 0, 0, 0); return d; };
  U.startOfWeek = function (d) { d = U.startOfDay(d); var wd = (d.getDay() + 6) % 7; d.setDate(d.getDate() - wd); return d; }; // Monday
  U.startOfMonth = function (d) { d = U.startOfDay(d); d.setDate(1); return d; };
  U.ms = function (iso) { return new Date(iso).getTime(); };

  /* ---------- formatting ---------- */
  U.money = function (n, opts) {
    var v = Number(n) || 0, neg = v < 0; v = Math.abs(v);
    var s;
    try { var frac = Math.round(v * 100) % 100 !== 0 ? 2 : 0; s = v.toLocaleString(cfgIn.locale || 'en-IN', { minimumFractionDigits: frac, maximumFractionDigits: 2 }); } catch (e) { s = String(v); }
    return (neg ? '-' : (opts && opts.sign ? '+' : '')) + (cfgIn.currency || '₹') + s;
  };
  U.num = function (n) { try { return Number(n || 0).toLocaleString(cfgIn.locale || 'en-IN'); } catch (e) { return String(n); } };
  U.fmtDate = function (x, long) {
    var d = typeof x === 'string' && x.length === 10 ? U.parseKey(x) : new Date(x);
    if (isNaN(d)) return '—';
    return d.toLocaleDateString('en', long ? { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' } : { day: 'numeric', month: 'short' });
  };
  U.fmtTime = function (iso) {
    if (!iso) return '—'; var d = new Date(iso); if (isNaN(d)) return '—';
    return d.toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' });
  };
  U.fmtDateTime = function (iso) { return iso ? U.fmtDate(iso) + ', ' + U.fmtTime(iso) : '—'; };
  U.fmtHours = function (h) {
    h = Number(h) || 0; var m = Math.round(h * 60); var hh = Math.floor(m / 60), mm = m % 60;
    return hh + 'h ' + (mm < 10 ? '0' + mm : mm) + 'm';
  };
  U.clock = function (ms) { // hh:mm:ss
    ms = Math.max(0, Math.floor(ms / 1000)); var h = Math.floor(ms / 3600), m = Math.floor(ms % 3600 / 60), s = ms % 60;
    return p2(h) + ':' + p2(m) + ':' + p2(s);
  };
  U.ago = function (iso) {
    var s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago'; if (s < 604800) return Math.floor(s / 86400) + 'd ago';
    return U.fmtDate(iso);
  };
  U.initials = function (name) { return String(name || '?').trim().split(/\s+/).slice(0, 2).map(function (x) { return x.charAt(0).toUpperCase(); }).join(''); };

  U.fileKind = function (mime, name) {
    mime = String(mime || '').toLowerCase(); name = String(name || '').toLowerCase();
    if (mime.indexOf('image/') === 0) return 'image';
    if (mime.indexOf('video/') === 0) return 'video';
    if (mime === 'application/pdf' || /\.pdf$/.test(name)) return 'pdf';
    if (/\.(docx?|xlsx?|pptx?|txt|csv|rtf|odt)$/.test(name) || /officedocument|msword|text\//.test(mime)) return 'document';
    return 'file';
  };
  U.fmtSize = function (b) { b = Number(b) || 0; if (b < 1024) return b + ' B'; if (b < 1048576) return Math.round(b / 1024) + ' KB'; return (b / 1048576).toFixed(1) + ' MB'; };

  U.download = function (filename, text, mime) {
    var blob = new Blob([text], { type: mime || 'text/csv;charset=utf-8' });
    var url = URL.createObjectURL(blob); var a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1000);
  };
  U.csv = function (rows) {
    return rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[",\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(','); }).join('\n');
  };
  U.randomPassword = function (len) {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789', out = '';
    var arr = new Uint32Array(len || 10);
    try { root.crypto.getRandomValues(arr); } catch (e) { for (var i = 0; i < arr.length; i++) arr[i] = Math.floor(Math.random() * 4294967296); }
    for (var j = 0; j < arr.length; j++) out += chars.charAt(arr[j] % chars.length);
    return out;
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = EOS;
})(typeof window !== 'undefined' ? window : globalThis);

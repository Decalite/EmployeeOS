/* EmployeeOS employee.js - the employee application (index.html). */
(function () {
  'use strict';
  var EOS = window.EOS, U = EOS.util, ui = EOS.ui, E = EOS.engine, db = EOS.db;
  var html = U.html, raw = U.raw, icon = ui.icon;
  var resolveUrls = EOS.shared.resolveUrls, msgList = function (m, r) { return EOS.shared.msgList(m, r); };

  var S = {
    me: null, rules: null, b: null, work: null, notifs: [], anns: [], unreadMsgs: 0,
    route: [], cal: { month: U.monthKey(), sel: U.todayKey() }, lbPeriod: 'weekly', lb: {}, lbMy: null,
    res: [], resFilter: 'all', chat: { tab: 'admin', msgs: [], file: null }, unsub: null, timers: [], lastSig: ''
  };
  var $ = function (id) { return document.getElementById(id); };
  var DOC_TITLES = { home: 'Home', earnings: 'Earnings', ranks: 'Leaderboard', chat: 'Chat', more: 'More', history: 'Work history', resources: 'Resources', notifications: 'Notifications', profile: 'Profile' };

  /* ======================= boot / auth ======================= */
  async function boot() {
    try {
      var me = await db.auth.init();
      if (me && me.role !== 'employee') { await db.auth.signOut(); me = null; ui.hideBoot(); return showLogin('Administrators sign in on the Admin portal.'); }
      if (me) await start(me); else { ui.hideBoot(); await showLogin(); }
    } catch (e) { ui.fatal(e, boot); }
  }

  async function showLogin(notice) {
    var needsSetup = false;
    try { needsSetup = db.mode === 'local' && await db.auth.needsSetup(); } catch (e) { /* ignore */ }
    $('root').innerHTML = String(html`
      ${db.mode === 'local' ? html`<div class="previewbar">PREVIEW MODE · data is stored only in this browser</div>` : ''}
      <div class="center-screen"><div class="login stack-l">
        <div class="center"><div class="logo">✦</div><h1>Employee<span style="color:var(--lav)">OS</span></h1><p class="muted" style="margin-top:6px">Sign in to your workspace</p></div>
        <form class="card stack" data-form="login" autocomplete="on">
          ${notice ? html`<div class="notice">${notice}</div>` : ''}
          <div class="err hidden" data-err></div>
          <label class="lbl">Employee ID or email<input class="field" name="id" id="loginId" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" inputmode="email" required placeholder="e.g. EMP001"></label>
          <label class="lbl">Password<span class="row nowrap"><input class="field grow" id="loginPw" name="pw" type="password" autocomplete="current-password" required placeholder="Your password"><button class="iconbtn" type="button" data-act="togglepw" aria-label="Show password">${icon('eye')}</button></span></label>
          <button class="btn block" type="submit">Sign in</button>
          <p class="muted small center">Forgot your password? Ask your admin to reset it.</p>
        </form>
        ${db.mode === 'local' ? html`<div class="notice small">${needsSetup ? html`Preview isn't set up yet. Open the <a href="admin.html">Admin portal</a> to create the preview admin, then add employees there.` : html`Preview mode: employee accounts are created by an admin in the <a href="admin.html">Admin portal</a>.`}</div>` : ''}
      </div></div>`);
    ui.hideBoot();
  }

  async function start(me) {
    S.me = EOS.me = me;
    S.rules = await E.getRules(true);
    await refreshData(true);
    ui.hideBoot();
    renderShell();
    S.unsub = db.subscribe(['work_requests', 'work_sessions', 'earning_entries', 'points_ledger', 'tier_history', 'notifications', 'messages', 'announcements', 'resources', 'profiles'], schedule);
    S.timers.push(setInterval(tick, 1000));
    S.timers.push(setInterval(function () { schedule(); }, 30000));
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('hashchange', route);
    route(true);
  }
  function onVisible() { if (!document.hidden && S.me) schedule(); }
  function stop() {
    S.timers.forEach(clearInterval); S.timers = []; if (S.unsub) S.unsub(); S.unsub = null;
    document.removeEventListener('visibilitychange', onVisible); window.removeEventListener('hashchange', route);
    S.me = EOS.me = null; S.b = null; S.lb = {}; S.chat = { tab: 'admin', msgs: [], file: null }; S.lastSig = '';
  }
  async function logout(msg) {
    ui.closeAllModals(); stop(); await db.auth.signOut(); location.hash = '';
    await showLogin(msg);
  }

  /* ======================= data ======================= */
  async function refreshData(first) {
    var id = S.me.id;
    var r;
    try {
      r = await Promise.all([
        db.list('profiles', { eq: { id: id } }), E.loadBundle(id), E.workState(id),
        db.list('notifications', { eq: { user_id: id }, order: 'created_at.desc', limit: 80 }),
        db.list('announcements', { order: 'created_at.desc', limit: 20 }),
        db.list('messages', { eq: { employee_id: id, sender_role: 'admin', read_at: null } })
      ]);
    } catch (e) {
      if (!first && /suspended|not signed in|jwt|refresh token/i.test((e && e.message) || '')) { await logout('Your account is no longer active or your session ended. Contact your admin.'); throw new Error('inactive'); }
      throw e;
    }
    if (!r[0][0] || r[0][0].status !== 'active') { await logout('Your account is no longer active. Contact your admin.'); throw new Error('inactive'); }
    var prev = S.work, prevUnread = S.notifs.filter(function (n) { return !n.read_at; }).length;
    S.me = EOS.me = r[0][0]; S.b = r[1]; S.work = r[2]; S.notifs = r[3]; S.anns = r[4]; S.unreadMsgs = r[5].length;
    if (!first && prev) {
      if (prev.pendingStart && S.work.open) ui.ok('Your work session has started ✓');
      else if (prev.pendingStart && !S.work.pendingStart && !S.work.open) ui.toast('Your start request was not approved.');
      if (prev.open && !S.work.open) ui.ok('Work session ended. Great job!');
      var nu = S.notifs.filter(function (n) { return !n.read_at; }).length;
      if (nu > prevUnread && S.route[0] !== 'notifications') ui.toast(S.notifs[0].title);
    }
  }
  var schedTimer = null;
  function schedule() {
    clearTimeout(schedTimer);
    schedTimer = setTimeout(async function () {
      if (!S.me) return;
      try {
        await refreshData(false);
        if (S.route[0] === 'chat') { if (S.chat.tab === 'ann') renderPage(false); else await refreshChatList(); updateChrome(); return; }
        var a = document.activeElement;
        if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && $('view') && $('view').contains(a)) { S.dirty = true; updateChrome(); return; }
        if (S.route[0] === 'ranks') { S.lb = {}; await loadRanks(); }
        if (S.route[0] === 'resources') await loadRes();
        renderPage(false); updateChrome();
      } catch (e) { if (e && e.message !== 'inactive') console.warn('refresh failed', e); }
    }, 350);
  }
  document.addEventListener('focusout', function () { if (S.dirty && S.me) { S.dirty = false; setTimeout(function () { if (S.me && !(document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName))) renderPage(false); }, 150); } });

  /* ======================= derived ======================= */
  function monthSummary() { return E.summarize(S.b.entries, S.b.sessions, U.monthKey(), U.todayKey()); }
  function points() {
    var since = Date.now() - S.rules.tiers.window_days * 86400000;
    return { win: U.sum(S.b.ledger.filter(function (l) { return U.ms(l.created_at) >= since; }), function (l) { return l.points; }), all: U.sum(S.b.ledger, function (l) { return l.points; }) };
  }
  function dayoffs() { return S.b.requests.filter(function (r) { return r.request_type === 'dayoff' && r.status === 'approved'; }); }
  function compact(n) { var a = Math.abs(n), s = a >= 100000 ? (a / 100000).toFixed(1).replace(/\.0$/, '') + 'L' : a >= 1000 ? (a / 1000).toFixed(1).replace(/\.0$/, '') + 'k' : String(Math.round(a)); return (n < 0 ? '-' : '') + s; }
  function statusPill(s) { return html`<span class="pill ${{ pending: 'gold', approved: 'green', rejected: 'red' }[s] || 'gray'}">${s}</span>`; }
  function reqLabel(r) { return { start: 'Start work', leave: 'Leave (end work)', dayoff: 'Day off' }[r.request_type] || r.request_type; }

  /* ======================= shell ======================= */
  var TABS = [['home', 'Home', 'home'], ['earnings', 'Earnings', 'wallet'], ['ranks', 'Ranks', 'trophy'], ['chat', 'Chat', 'chat'], ['more', 'More', 'grid']];
  var SIDE = [['home', 'Home', 'home'], ['earnings', 'Earnings', 'wallet'], ['ranks', 'Leaderboard', 'trophy'], ['chat', 'Chat', 'chat'], ['history', 'Work history', 'clock'], ['resources', 'Resources', 'book'], ['notifications', 'Notifications', 'bell'], ['profile', 'Profile', 'user']];
  function renderShell() {
    $('root').innerHTML = String(html`
      ${db.mode === 'local' ? html`<div class="previewbar">PREVIEW MODE · data is stored only in this browser</div>` : ''}
      <div class="app">
        <aside class="sidebar" id="sidebar"></aside>
        <div>
          <header class="topbar"><div class="brand"><span class="mark">✦</span><span class="wm">Employee<em>OS</em></span></div><div class="row nowrap"><a class="iconbtn" href="#/notifications" aria-label="Notifications" id="bellBtn">${icon('bell')}<span class="dot hidden" id="bellDot"></span></a><a href="#/profile" aria-label="Profile" id="avatarBtn" style="text-decoration:none"></a></div></header>
          <main class="main"><div id="view"></div></main>
        </div>
      </div>
      <nav class="tabbar" id="tabbar" aria-label="Main"></nav>`);
    updateChrome();
  }
  function activeTab() { var r = S.route[0] || 'home'; return ['history', 'resources', 'notifications', 'profile'].indexOf(r) >= 0 ? 'more' : r; }
  function updateChrome() {
    if (!$('tabbar')) return;
    var tab = activeTab(), r = S.route[0] || 'home';
    $('tabbar').innerHTML = String(html`${TABS.map(function (t) { return html`<a href="#/${t[0]}" class="${t[0] === tab ? 'on' : ''}" ${t[0] === tab ? raw('aria-current="page"') : ''}>${icon(t[2])}<span>${t[1]}</span>${t[0] === 'chat' && S.unreadMsgs ? html`<span class="dot">${S.unreadMsgs}</span>` : ''}${t[0] === 'more' && unreadNotifs() ? html`<span class="dot">${unreadNotifs()}</span>` : ''}</a>`; })}`);
    $('sidebar').innerHTML = String(html`<div class="brand"><span class="mark">✦</span><span class="wm">Employee<em>OS</em></span></div>
      ${SIDE.map(function (t) { var n = t[0] === 'chat' ? S.unreadMsgs : t[0] === 'notifications' ? unreadNotifs() : 0; return html`<a href="#/${t[0]}" class="${t[0] === r ? 'on' : ''}">${icon(t[2])}<span>${t[1]}</span>${n ? html`<span class="dot">${n}</span>` : ''}</a>`; })}
      <div class="sp"></div>
      <div class="row nowrap" style="padding:10px">${ui.avatar(S.me.full_name, true)}<div class="grow"><div class="bold small" style="overflow:hidden;text-overflow:ellipsis">${S.me.full_name}</div><div class="muted tiny">${S.me.employee_code || ''}</div></div></div>
      <a href="#/home" data-act="logout">${icon('logout')}<span>Sign out</span></a>`);
    var d = $('bellDot'); if (d) { var n = unreadNotifs(); d.textContent = n; d.classList.toggle('hidden', !n); }
    $('avatarBtn').innerHTML = String(ui.avatar(S.me.full_name, true));
  }
  function unreadNotifs() { return S.notifs.filter(function (n) { return !n.read_at; }).length; }

  /* ======================= router ======================= */
  var PAGES = {
    home: { render: pageHome }, earnings: { render: pageEarnings }, ranks: { load: loadRanks, render: pageRanks },
    chat: { load: loadChat, render: pageChat, after: afterChat }, more: { render: pageMore }, history: { render: pageHistory },
    resources: { load: loadRes, render: pageResources }, notifications: { render: pageNotifs }, profile: { render: pageProfile }
  };
  var routeSeq = 0;
  async function route(first) {
    if (!S.me) return;
    S.route = ui.parseHash(); if (!S.route.length || !PAGES[S.route[0]]) S.route = ['home'];
    var seq = ++routeSeq, p = PAGES[S.route[0]];
    document.title = (DOC_TITLES[S.route[0]] || 'Home') + ' · EmployeeOS';
    updateChrome();
    if (p.load) { $('view').innerHTML = String(ui.skeleton(3)); try { await p.load(); } catch (e) { ui.fail(e); } }
    if (seq !== routeSeq) return;
    renderPage(true); window.scrollTo(0, 0);
  }
  function renderPage(animate) {
    var v = $('view'); if (!v || !S.me) return;
    var p = PAGES[S.route[0]] || PAGES.home;
    var h;
    try { h = p.render(); } catch (e) { console.error(e); h = html`<div class="card err">This page failed to load: ${e.message}</div>`; }
    v.innerHTML = '<div class="' + (animate ? 'page' : '') + '">' + h + '</div>';
    if (p.after) p.after();
    tick();
  }
  function head(title, sub, right) { return html`<div class="page-head"><div><h1>${title}</h1>${sub ? html`<div class="sub">${sub}</div>` : ''}</div>${right || ''}</div>`; }
  function backLink() { return html`<a class="back" href="#/more">${icon('left', 'sm')} More</a>`; }

  /* ======================= HOME ======================= */
  function greeting() { var h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; }
  function heroBlock() {
    var w = S.work, offToday = dayoffs().some(function (r) { return r.request_date === U.todayKey(); });
    if (w.open) {
      return html`<span class="pill green"><span class="live"></span>ON THE CLOCK</span>
        <div class="timer" id="timer" data-since="${w.open.started_at}">00:00:00</div>
        <div class="muted small">Started at ${U.fmtTime(w.open.started_at)}${w.pendingLeave ? ' · leave requested ' + U.fmtTime(w.pendingLeave.requested_at) : ''}</div>
        ${w.pendingLeave
          ? html`<button class="startbtn leave" disabled>${icon('clock')} LEAVE REQUESTED · WAITING</button>`
          : html`<button class="startbtn leave" data-act="leave">${icon('coffee')} LEAVE</button>`}`;
    }
    if (w.pendingStart) {
      return html`<span class="pill gold">REQUEST SENT</span><h2>Waiting for admin approval</h2>
        <div class="muted small">Sent at ${U.fmtTime(w.pendingStart.requested_at)}. Work starts only after your admin approves it.</div>
        <button class="startbtn" disabled>${icon('clock')} WAITING FOR APPROVAL</button>`;
    }
    return html`<span class="pill">${offToday ? 'DAY OFF APPROVED' : 'READY TO WORK'}</span><h2>${offToday ? 'Enjoy your day off' : 'Ready when you are'}</h2>
      <div class="muted small">${offToday ? 'You can still start work if your admin needs you today.' : 'Tap START WORK to send a start request to your admin.'}</div>
      <button class="startbtn" data-act="start">${icon('play')} START WORK</button>`;
  }
  function pageHome() {
    var sm = monthSummary(), pt = points(), tier = S.me.tier, tp = E.tierProgress(pt.win, tier, S.rules), lv = E.level(pt.all);
    var ann = S.anns[0], days = S.rules.pay.working_days;
    var todayH = sm.today.hours + (S.work.open ? Math.max(0, (Date.now() - U.ms(S.work.open.started_at)) / 3600000) : 0);
    return html`
      ${head(greeting() + ', ' + S.me.full_name.split(' ')[0] + ' 👋', U.fmtDate(new Date(), true))}
      <div class="hero">${heroBlock()}</div>
      <div class="tiles four" style="margin-top:14px">
        <div class="tile accent"><div class="k">Today's earning</div><div class="v">${U.money(sm.today.net)}</div><div class="muted tiny">${S.work.open ? 'Posts when your session ends' : 'Recorded today'}</div></div>
        <div class="tile"><div class="k">This month</div><div class="v">${U.money(sm.month.net)}</div><div class="muted tiny">Net earnings</div></div>
        <div class="tile"><div class="k">Total earnings</div><div class="v">${U.money(sm.total.net)}</div><div class="muted tiny">All time, net</div></div>
        <div class="tile"><div class="k">Monthly salary</div><div class="v">${U.money(S.me.monthly_base_salary)}</div><div class="muted tiny">Base · ${U.money(E.dailyRate(S.me.monthly_base_salary, S.rules))}/day</div></div>
      </div>
      <div class="tiles three" style="margin-top:12px">
        <div class="tile"><div class="k">Extra</div><div class="v good">${U.money(sm.month.extra)}</div></div>
        <div class="tile"><div class="k">Bonus</div><div class="v good">${U.money(sm.month.bonus)}</div></div>
        <div class="tile"><div class="k">Deductions</div><div class="v bad">${U.money(sm.month.deduction)}</div></div>
      </div>
      <div class="cols2" style="margin-top:14px">
        <div class="card"><div class="tierrow">${ui.badge(tier, 76)}<div class="grow"><div class="muted tiny bold">YOUR TIER</div><h2>${tier}${S.me.tier_override ? html` <span class="pill gray">set by admin</span>` : ''}</h2><div class="muted small">Level ${lv.level} · ${U.num(pt.all)} XP</div></div></div>
          <div class="bar" style="margin-top:14px"><i style="width:${tp.pct}%"></i></div>
          <div class="muted small" style="margin-top:8px">${tp.next ? U.num(tp.remaining) + ' pts to ' + tp.next + ' · ' + U.num(pt.win) + ' pts in last ' + S.rules.tiers.window_days + ' days' : 'Top tier reached 🎉 · ' + U.num(pt.win) + ' pts in last ' + S.rules.tiers.window_days + ' days'}</div></div>
        <div class="card"><h3>Attendance · ${U.monthLabel(U.monthKey())}</h3>
          <div class="row between"><div><div class="tile-v" style="font-size:24px;font-weight:850">${sm.month.days}<span class="muted" style="font-size:14px"> / ${days} days</span></div><div class="muted small">Days worked</div></div><div class="right"><div style="font-size:24px;font-weight:850">${U.fmtHours(sm.month.hours)}</div><div class="muted small">Hours this month</div></div></div>
          <div class="bar" style="margin-top:12px"><i style="width:${Math.min(100, Math.round(sm.month.days / days * 100))}%"></i></div>
          <div class="muted small" style="margin-top:8px">Today: ${U.fmtHours(todayH)}${S.work.open ? ' (live)' : ''}</div></div>
      </div>
      ${ann ? html`<div class="card" style="margin-top:14px"><div class="row between"><h3>${icon('mega', 'sm')} ${ann.title}</h3><span class="muted tiny">${U.ago(ann.created_at)}</span></div><p class="muted" style="white-space:pre-wrap">${ann.body}</p><a class="btn ghost sm" style="margin-top:10px" href="#/chat" data-act="open-ann">All announcements</a></div>` : ''}`;
  }
  function tick() {
    var t = $('timer'); if (!t) return;
    t.textContent = U.clock(Date.now() - U.ms(t.getAttribute('data-since')));
  }

  /* ======================= EARNINGS ======================= */
  function pageEarnings() {
    var mk = S.cal.month, sum = E.summarize(S.b.entries, S.b.sessions, mk, U.todayKey()).month;
    var map = E.dayMap(S.b.entries.filter(function (e) { return String(e.entry_date).slice(0, 7) === mk; }), S.b.sessions.filter(function (s) { return String(s.work_date).slice(0, 7) === mk; }), dayoffs().filter(function (r) { return r.request_date.slice(0, 7) === mk; }));
    var first = U.monthStart(mk).getDay(), n = U.monthDays(mk), cells = '';
    for (var i = 0; i < first; i++) cells += '<div class="d blank"></div>';
    for (var d = 1; d <= n; d++) {
      var key = mk + '-' + (d < 10 ? '0' + d : d), x = map[key];
      var cls = (key === U.todayKey() ? 'today ' : '') + (key === S.cal.sel ? 'sel ' : '') + (x && x.entries.length ? 'has ' : '') + (x && x.leave ? 'leave ' : '');
      cells += '<button class="d ' + cls + '" data-act="cal-sel" data-d="' + key + '"><b>' + d + '</b><small>' + (x && x.leave ? 'Leave' : x && x.entries.length ? compact(x.net) : '·') + '</small></button>';
    }
    var sel = map[S.cal.sel], inMonth = S.cal.sel.slice(0, 7) === mk;
    var monthEntries = S.b.entries.filter(function (e) { return String(e.entry_date).slice(0, 7) === mk; });
    return html`
      ${head('Earnings', 'Your pay, bonuses and deductions')}
      <div class="row between" style="margin-bottom:12px"><button class="iconbtn" data-act="cal-nav" data-n="-1" aria-label="Previous month">${icon('left')}</button><b>${U.monthLabel(mk)}</b><button class="iconbtn" data-act="cal-nav" data-n="1" aria-label="Next month" ${mk >= U.monthKey() ? 'disabled' : ''}>${icon('right')}</button></div>
      <div class="tiles four">
        <div class="tile accent"><div class="k">Net this month</div><div class="v">${U.money(sum.net)}</div></div>
        <div class="tile"><div class="k">Work pay</div><div class="v">${U.money(sum.daily)}</div><div class="muted tiny">${sum.days} days · ${U.fmtHours(sum.hours)}</div></div>
        <div class="tile"><div class="k">Extra + bonus</div><div class="v good">${U.money(sum.extra + sum.bonus)}</div></div>
        <div class="tile"><div class="k">Deductions</div><div class="v bad">${U.money(sum.deduction)}</div></div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Daily earning calendar</h3>
        <div class="cal">${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(function (x) { return html`<div class="dow">${x}</div>`; })}${raw(cells)}</div>
        <p class="muted tiny" style="margin-top:10px">Each day shows net earnings (work pay + extra + bonus − deductions). Gold = approved leave.</p></div>
      <div class="card" style="margin-top:14px"><h3>${U.fmtDate(S.cal.sel, true)}</h3>${inMonth ? dayDetail(sel) : ui.empty('calendar', 'Select a day in this month.')}</div>
      <div class="card" style="margin-top:14px"><h3>All entries · ${U.monthLabel(mk)}</h3>
        ${monthEntries.length ? html`<div class="list">${monthEntries.map(entryRow)}</div>` : ui.empty('wallet', 'No earnings recorded this month yet.')}</div>`;
  }
  function entryRow(e) {
    var lab = { daily: 'Work pay', extra: 'Extra earning', bonus: 'Bonus', deduction: 'Deduction' }[e.entry_type], neg = e.entry_type === 'deduction';
    return html`<div class="item"><div class="grow"><div class="title">${lab}</div><div class="muted small">${U.fmtDate(e.entry_date)} · ${e.description || ''}</div></div><div class="bold ${neg ? 'bad' : 'good'}">${neg ? '-' : '+'}${U.money(e.amount)}</div></div>`;
  }
  function dayDetail(x) {
    if (!x) return ui.empty('calendar', 'No activity on this day.');
    return html`${x.leave ? html`<div class="notice" style="margin-bottom:10px">Approved day off — ${x.leave.reason || ''}</div>` : ''}
      ${x.sessions.length ? html`<div class="list">${x.sessions.map(function (s) { return html`<div class="item"><div class="grow"><div class="title">Work session</div><div class="muted small">${U.fmtTime(s.started_at)} → ${s.ended_at ? U.fmtTime(s.ended_at) : 'in progress'}</div></div><div class="bold">${s.ended_at ? U.fmtHours(s.hours) : '…'}</div></div>`; })}</div>` : ''}
      ${x.entries.length ? html`<div class="list">${x.entries.map(entryRow)}</div><div class="row between" style="margin-top:8px"><span class="muted">Day total</span><b>${U.money(x.net)}</b></div>` : (x.sessions.length ? '' : ui.empty('calendar', 'No activity on this day.'))}`;
  }

  /* ======================= RANKS ======================= */
  async function loadRanks() {
    var p = S.lbPeriod;
    if (!S.lb[p]) S.lb[p] = await E.leaderboard(p);
  }
  function pageRanks() {
    var p = S.lbPeriod, rows = S.lb[p] || [], me = rows.filter(function (r) { return r.employee_id === S.me.id; })[0], pt = points(), lv = E.level(pt.all), tp = E.tierProgress(pt.win, S.me.tier, S.rules);
    var names = { daily: 'Today', weekly: 'This week', monthly: 'This month', all: 'All time' };
    var top = rows.slice(0, 3), order = [1, 0, 2].filter(function (i) { return top[i]; }), hs = [96, 70, 54];
    return html`
      ${head('Leaderboard', 'Ranked by points earned from work and attendance')}
      <div class="seg" role="tablist">${['daily', 'weekly', 'monthly', 'all'].map(function (k) { return html`<button class="${k === p ? 'on' : ''}" data-act="lb-period" data-p="${k}">${{ daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', all: 'All-time' }[k]}</button>`; })}</div>
      <div class="card" style="margin-top:14px"><div class="tierrow">${ui.badge(S.me.tier, 72)}<div class="grow"><div class="muted tiny bold">${names[p].toUpperCase()}</div><h2>${me ? '#' + me.rank : '—'} <span class="muted" style="font-size:14px;font-weight:600">${me ? U.num(me.points) + ' pts' : ''}</span></h2><div class="muted small">${S.me.tier} · Level ${lv.level} · ${U.num(pt.all)} XP</div>
        <div class="bar" style="margin-top:8px"><i style="width:${tp.pct}%"></i></div><div class="muted tiny" style="margin-top:4px">${tp.next ? U.num(tp.remaining) + ' pts to ' + tp.next : 'Top tier'}</div></div></div></div>
      ${top.length >= 3 ? html`<div class="podium" style="margin-top:16px">${order.map(function (i) { var r = top[i]; return html`<div>${ui.badge(r.tier, i === 0 ? 56 : 46)}<div class="name">${r.full_name}</div><div class="muted tiny">${U.num(r.points)} pts</div><div class="step" style="--h:${hs[i]}px">${r.rank}</div></div>`; })}</div>` : ''}
      <div class="card" style="margin-top:14px"><h3>${names[p]}</h3>
        ${rows.length ? rows.map(function (r) { return html`<div class="lb r${r.rank} ${r.employee_id === S.me.id ? 'me' : ''}"><div class="rk">${r.rank}</div>${ui.badge(r.tier, 34)}<div class="grow"><div class="bold" style="overflow:hidden;text-overflow:ellipsis">${r.full_name}${r.employee_id === S.me.id ? ' (you)' : ''}</div><div class="muted tiny">${r.tier}</div></div><div class="pts">${U.num(r.points)}</div></div>`; }) : ui.empty('trophy', 'No points yet for this period.')}
        <p class="muted tiny" style="margin-top:12px">Leaderboards show names, tiers and points only — never salary or deductions.</p></div>
      <div class="card" style="margin-top:14px"><h3>Tier ladder</h3>
        <div class="ladder">${E.TIERS.map(function (t) { return html`<div class="${t === S.me.tier ? 'on' : ''}">${ui.badge(t, 42)}<div>${t}</div><div class="tiny">${S.rules.tiers.thresholds[t]}+</div></div>`; })}</div>
        <p class="muted small" style="margin-top:12px">Your tier follows the points you earned in the last ${S.rules.tiers.window_days} days. Earn more to be promoted; fall below a threshold and you can be demoted. ${S.rules.points.per_hour} pts per hour worked, +${S.rules.points.attendance_day} pts for each day with ${S.rules.points.min_hours_for_attendance}h+.</p></div>
      <div class="card" style="margin-top:14px"><h3>My ranking history</h3>${rankHistory()}</div>`;
  }
  function rankHistory() {
    var items = S.b.tiers.map(function (t) { return { at: t.created_at, html: html`<div class="item"><div class="grow"><div class="title">${t.old_tier || '—'} → ${t.new_tier}</div><div class="muted small">${t.manual ? 'Set by admin' : t.reason}${Number(t.bonus) > 0 ? ' · bonus ' + U.money(t.bonus) : ''}</div></div><div class="muted small">${U.fmtDate(t.created_at)}</div></div>` }; })
      .concat(S.b.ledger.slice(0, 15).map(function (l) { return { at: l.created_at, html: html`<div class="item"><div class="grow"><div class="title ${l.points < 0 ? 'bad' : ''}">${l.points > 0 ? '+' : ''}${l.points} pts</div><div class="muted small">${l.reason}</div></div><div class="muted small">${U.fmtDate(l.created_at)}</div></div>` }; }))
      .sort(function (a, b) { return U.ms(b.at) - U.ms(a.at); }).slice(0, 20);
    return items.length ? html`<div class="list">${items.map(function (i) { return i.html; })}</div>` : ui.empty('activity', 'No ranking activity yet. Complete a work session to earn points.');
  }

  /* ======================= CHAT ======================= */
  async function loadChat() {
    var r = await Promise.all([db.list('messages', { eq: { employee_id: S.me.id }, order: 'created_at.asc', limit: 300 })]);
    S.chat.msgs = r[0]; await resolveUrls(S.chat.msgs);
    if (S.chat.tab === 'admin' && S.chat.msgs.some(function (m) { return m.sender_role === 'admin' && !m.read_at; })) { await E.markRead(S.me.id); S.unreadMsgs = 0; S.chat.msgs.forEach(function (m) { if (m.sender_role === 'admin' && !m.read_at) m.read_at = new Date().toISOString(); }); }
  }
  function pageChat() {
    var t = S.chat.tab;
    return html`${head('Messages', 'Chat with your admin and read team announcements')}
      <div class="seg"><button class="${t === 'admin' ? 'on' : ''}" data-act="chat-tab" data-t="admin">Admin</button><button class="${t === 'ann' ? 'on' : ''}" data-act="chat-tab" data-t="ann">Announcements${S.anns.length ? ' (' + S.anns.length + ')' : ''}</button></div>
      <div style="margin-top:12px">${t === 'admin' ? html`<div class="chat card flat tight"><div class="msgs" id="msgs">${msgList(S.chat.msgs, 'employee')}</div>
        <div id="pendingFile">${pendingFileHtml()}</div>
        <form class="composer" data-form="chat-send" autocomplete="off"><label class="iconbtn" style="cursor:pointer" aria-label="Attach file">${icon('clip')}<input type="file" id="chatFile" data-change="chat-file" accept="image/*,video/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv" class="hidden"></label>
        <textarea class="field grow" id="chatInput" name="body" rows="1" placeholder="Message your admin…" maxlength="2000" enterkeyhint="send"></textarea><button class="btn round" type="submit" aria-label="Send">${icon('send')}</button></form></div>`
        : html`<div class="stack">${S.anns.length ? S.anns.map(function (a) { return html`<div class="card"><div class="row between"><h3>${a.title}</h3><span class="muted tiny">${U.fmtDateTime(a.created_at)}</span></div><p class="muted" style="white-space:pre-wrap">${a.body}</p>${a.attachment_path ? html`<button class="btn ghost sm" style="margin-top:10px" data-act="view-ann" data-path="${a.attachment_path}" data-name="${a.attachment_name}" data-type="${a.attachment_type || ''}">${icon('clip', 'sm')} ${a.attachment_name}</button>` : ''}</div>`; }) : ui.empty('mega', 'No announcements yet.')}</div>`}</div>`;
  }
  function pendingFileHtml() { var f = S.chat.file; return f ? html`<div class="pending-file">${icon('clip', 'sm')}<span class="grow" style="overflow:hidden;text-overflow:ellipsis">${f.name} · ${U.fmtSize(f.size)}</span><button type="button" class="iconbtn" style="width:32px;height:32px" data-act="chat-clear-file" aria-label="Remove file">${icon('x', 'sm')}</button></div>` : ''; }
  function afterChat() { var m = $('msgs'); if (m) m.scrollTop = m.scrollHeight; }
  async function refreshChatList() {
    if (S.chat.tab !== 'admin') return;
    var msgs = await db.list('messages', { eq: { employee_id: S.me.id }, order: 'created_at.asc', limit: 300 });
    var old = S.chat.msgs, urls = {}; old.forEach(function (m) { if (m._url) urls[m.id] = m._url; });
    msgs.forEach(function (m) { if (urls[m.id]) m._url = urls[m.id]; });
    S.chat.msgs = msgs; await resolveUrls(msgs);
    if (msgs.some(function (m) { return m.sender_role === 'admin' && !m.read_at; })) { await E.markRead(S.me.id); msgs.forEach(function (m) { if (m.sender_role === 'admin') m.read_at = m.read_at || new Date().toISOString(); }); S.unreadMsgs = 0; }
    var box = $('msgs'); if (!box) return;
    var sig = msgs.length + ':' + msgs.map(function (m) { return m.read_at ? 1 : 0; }).join('');
    if (sig === S.lastSig) return; S.lastSig = sig;
    var near = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
    box.innerHTML = String(msgList(msgs, 'employee')); if (near) box.scrollTop = box.scrollHeight;
  }
  document.addEventListener('keydown', function (e) {
    if (e.target && e.target.id === 'chatInput' && e.key === 'Enter' && !e.shiftKey && !/iPhone|iPad|Android/i.test(navigator.userAgent)) { e.preventDefault(); var f = e.target.form; if (f.requestSubmit) f.requestSubmit(); else f.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true })); }
  });
  document.addEventListener('input', function (e) { if (e.target && e.target.id === 'chatInput') { e.target.style.height = 'auto'; e.target.style.height = Math.min(120, e.target.scrollHeight) + 'px'; } });

  /* ======================= MORE / HISTORY / RESOURCES / NOTIFS / PROFILE ======================= */
  function pageMore() {
    var rows = [['history', 'Work history', 'Sessions, attendance and leave requests', 'clock'], ['resources', 'Resources', 'Videos, documents and work instructions', 'book'], ['notifications', 'Notifications', unreadNotifs() ? unreadNotifs() + ' unread' : 'You are all caught up', 'bell'], ['profile', 'Profile & settings', 'Account details and password', 'user']];
    return html`${head('More')}
      <div class="card"><div class="list">${rows.map(function (r) { return html`<a class="item click" href="#/${r[0]}" style="text-decoration:none;color:inherit"><div class="res" style="width:46px;height:46px;padding:0;border:0;background:transparent"><div class="rico">${icon(r[3])}</div></div><div class="grow"><div class="title">${r[1]}</div><div class="muted small">${r[2]}</div></div>${r[0] === 'notifications' && unreadNotifs() ? html`<span class="pill red">${unreadNotifs()}</span>` : ''}${icon('right', 'sm')}</a>`; })}
        <div class="item click" data-act="logout"><div class="rico res" style="width:46px;height:46px;padding:0;border:0;background:transparent"><div class="rico" style="color:var(--red)">${icon('logout')}</div></div><div class="grow"><div class="title">Sign out</div></div></div></div></div>`;
  }
  function pageHistory() {
    var sm = monthSummary().month, ss = S.b.sessions.slice(0, 60), reqs = S.b.requests.slice(0, 40);
    return html`${backLink()}${head('Work history', 'Start and end times for every session', html`<button class="btn sm" data-act="dayoff">${icon('calendar', 'sm')} Request day off</button>`)}
      <div class="tiles three"><div class="tile"><div class="k">Days worked</div><div class="v">${sm.days}</div><div class="muted tiny">this month</div></div><div class="tile"><div class="k">Hours</div><div class="v">${U.fmtHours(sm.hours)}</div><div class="muted tiny">this month</div></div><div class="tile"><div class="k">All-time</div><div class="v">${U.fmtHours(monthSummary().total.hours)}</div></div></div>
      <div class="card" style="margin-top:14px"><h3>Sessions</h3>${ss.length ? html`<div class="list">${ss.map(function (s) { return html`<div class="item"><div class="grow"><div class="title">${U.fmtDate(s.work_date, true)}</div><div class="muted small">${U.fmtTime(s.started_at)} → ${s.ended_at ? U.fmtTime(s.ended_at) : 'in progress'}</div></div>${s.ended_at ? html`<div class="bold">${U.fmtHours(s.hours)}</div>` : html`<span class="pill green"><span class="live"></span>Live</span>`}</div>`; })}</div>` : ui.empty('clock', 'No work sessions yet. Tap START WORK on Home.')}</div>
      <div class="card" style="margin-top:14px"><h3>Requests</h3>${reqs.length ? html`<div class="list">${reqs.map(function (r) { return html`<div class="item"><div class="grow"><div class="title">${reqLabel(r)}${r.request_type === 'dayoff' ? ' · ' + U.fmtDate(r.request_date) : ''}</div><div class="muted small">${U.fmtDateTime(r.requested_at)}${r.reason ? ' · ' + r.reason : ''}${r.review_note ? ' · Admin: ' + r.review_note : ''}</div></div>${statusPill(r.status)}</div>`; })}</div>` : ui.empty('inbox', 'No requests yet.')}</div>`;
  }
  async function loadRes() { S.res = await db.list('resources', { order: 'created_at.desc' }); }
  function pageResources() {
    var f = S.resFilter, list = S.res.filter(function (r) { return f === 'all' || (f === 'docs' ? ['pdf', 'document'].indexOf(r.resource_type) >= 0 : f === 'notes' ? ['note', 'instruction'].indexOf(r.resource_type) >= 0 : r.resource_type === f); });
    var tabs = [['all', 'All'], ['video', 'Videos'], ['image', 'Images'], ['docs', 'Documents'], ['notes', 'Notes']];
    return html`${backLink()}${head('Resources', 'Work instructions and material shared by your admin')}
      <div class="seg">${tabs.map(function (t) { return html`<button class="${t[0] === f ? 'on' : ''}" data-act="res-filter" data-f="${t[0]}">${t[1]}</button>`; })}</div>
      <div style="margin-top:14px">${list.length ? list.map(function (r) { return html`<button class="res" data-act="open-res" data-id="${r.id}"><div class="rico">${icon(ui.fileIcon(r.resource_type))}</div><div class="grow"><div class="bold">${r.title}</div><div class="muted small">${r.description || r.resource_type}</div><div class="muted tiny" style="margin-top:3px">${r.resource_type.toUpperCase()} · ${U.fmtDate(r.created_at)}</div></div>${icon('right', 'sm')}</button>`; }) : ui.empty('book', 'Nothing here yet.')}</div>`;
  }
  function pageNotifs() {
    var kinds = { success: 'check', warning: 'info', announcement: 'mega', info: 'bell' };
    return html`${backLink()}${head('Notifications', '', unreadNotifs() ? html`<button class="btn ghost sm" data-act="read-all">Mark all read</button>` : '')}
      <div class="card">${S.notifs.length ? html`<div class="list">${S.notifs.map(function (n) { return html`<div class="item click" data-act="read-one" data-id="${n.id}" style="${n.read_at ? 'opacity:.7' : ''}"><div class="rico res" style="width:42px;height:42px;padding:0;border:0;background:transparent"><div class="rico" style="width:42px;height:42px">${icon(kinds[n.kind] || 'bell')}</div></div><div class="grow"><div class="title">${n.title}</div><div class="muted small">${n.body || ''}</div><div class="muted tiny">${U.ago(n.created_at)}</div></div>${n.read_at ? '' : html`<span class="unread"></span>`}</div>`; })}</div>` : ui.empty('bell', 'No notifications yet.')}</div>`;
  }
  function pageProfile() {
    var p = S.me, pt = points();
    return html`${backLink()}${head('Profile & settings')}
      <div class="card"><div class="tierrow">${ui.badge(p.tier, 80)}<div class="grow"><h2>${p.full_name}</h2><div class="muted small">${p.employee_code || ''} · ${p.tier} tier</div><div class="muted small">Joined ${U.fmtDate(p.created_at, true)}</div></div></div>
        <div class="list" style="margin-top:12px"><div class="item"><span class="muted grow">Monthly base salary</span><b>${U.money(p.monthly_base_salary)}</b></div><div class="item"><span class="muted grow">XP</span><b>${U.num(pt.all)}</b></div><div class="item"><span class="muted grow">Email</span><b>${p.email || '—'}</b></div></div></div>
      <form class="card stack" style="margin-top:14px" data-form="profile"><h3>Contact details</h3><div class="err hidden" data-err></div>
        <label class="lbl">Phone<input class="field" name="phone" type="tel" value="${p.phone || ''}" maxlength="30" autocomplete="tel"></label>
        <p class="muted small">To change your name, ID or salary, ask your admin.</p><button class="btn" type="submit">Save</button></form>
      <form class="card stack" style="margin-top:14px" data-form="password"><h3>Change password</h3><div class="err hidden" data-err></div>
        <label class="lbl">New password<input class="field" name="pw1" type="password" autocomplete="new-password" minlength="8" required></label>
        <label class="lbl">Confirm new password<input class="field" name="pw2" type="password" autocomplete="new-password" minlength="8" required></label>
        <button class="btn" type="submit">Update password</button></form>
      <button class="btn danger block" style="margin-top:14px" data-act="logout">${icon('logout')} Sign out</button>`;
  }

  /* ======================= actions ======================= */
  ui.register({
    togglepw: function () { var i = $('loginPw'); i.type = i.type === 'password' ? 'text' : 'password'; },
    logout: async function () { await logout(); },
    start: async function () {
      await E.requestStart(); ui.ok('Start request sent to your admin ✓'); await refreshData(false); renderPage(false); updateChrome();
    },
    leave: async function () {
      var ok = await ui.confirm({ title: 'Request to leave?', body: 'Your admin will approve ending today\'s session. Your end time is recorded as right now.', ok: 'Send leave request' });
      if (!ok) return; await E.requestLeave(); ui.ok('Leave request sent ✓'); await refreshData(false); renderPage(false);
    },
    'cal-sel': function (el) { S.cal.sel = el.getAttribute('data-d'); renderPage(false); },
    'cal-nav': function (el) { S.cal.month = U.addMonths(S.cal.month, Number(el.getAttribute('data-n'))); S.cal.sel = S.cal.month === U.monthKey() ? U.todayKey() : S.cal.month + '-01'; renderPage(false); },
    'lb-period': async function (el) { S.lbPeriod = el.getAttribute('data-p'); if (!S.lb[S.lbPeriod]) S.lb[S.lbPeriod] = await E.leaderboard(S.lbPeriod); renderPage(false); },
    'chat-tab': async function (el) { S.chat.tab = el.getAttribute('data-t'); S.lastSig = ''; if (S.chat.tab === 'admin') await loadChat(); renderPage(false); },
    'chat-clear-file': function () { S.chat.file = null; $('pendingFile').innerHTML = ''; $('chatFile').value = ''; },
    'view-att': async function (el) { await ui.viewFile('chat', el.getAttribute('data-path'), el.getAttribute('data-name'), el.getAttribute('data-type')); },
    'view-ann': async function (el) { await ui.viewFile('resources', el.getAttribute('data-path'), el.getAttribute('data-name'), el.getAttribute('data-type')); },
    'open-ann': function () { S.chat.tab = 'ann'; },
    'res-filter': function (el) { S.resFilter = el.getAttribute('data-f'); renderPage(false); },
    'open-res': async function (el) {
      var r = S.res.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; if (!r) return;
      if (r.storage_path) return ui.viewFile('resources', r.storage_path, r.file_name, r.mime_type, r.title);
      ui.modal({ title: r.title, wide: true, body: html`${r.description ? html`<p class="muted" style="margin-bottom:10px">${r.description}</p>` : ''}<div class="viewer"><pre>${r.body || ''}</pre></div>` });
    },
    'read-all': async function () { await db.update('notifications', { eq: { user_id: S.me.id, read_at: null } }, { read_at: new Date().toISOString() }); await refreshData(false); renderPage(false); updateChrome(); },
    'read-one': async function (el) { var id = el.getAttribute('data-id'), n = S.notifs.filter(function (x) { return x.id === id; })[0]; if (n && !n.read_at) { await db.update('notifications', { eq: { id: id } }, { read_at: new Date().toISOString() }); await refreshData(false); renderPage(false); updateChrome(); } },
    dayoff: function () {
      ui.modal({ title: 'Request a day off', body: html`<form class="stack" data-form="dayoff"><div class="err hidden" data-err></div>
        <label class="lbl">Date<input class="field" type="date" name="date" min="${U.todayKey()}" value="${U.addDays(U.todayKey(), 1)}" required></label>
        <label class="lbl">Reason<textarea class="field" name="reason" maxlength="300" required placeholder="Why do you need this day off?"></textarea></label>
        <button class="btn block" type="submit">Send request</button></form>` });
    }
  }, {
    login: async function (f, v) {
      var me = await db.auth.signIn(v.id, v.pw);
      if (me.role !== 'employee') { await db.auth.signOut(); throw new Error('Administrators sign in on the Admin portal.'); }
      $('root').innerHTML = String(html`<div class="center-screen"><div class="spinner"></div></div>`);
      try { await start(me); } catch (e) { if (e && e.message === 'inactive') return; await db.auth.signOut(); stop(); await showLogin(); throw e; }
    },
    'chat-send': async function (f, v) {
      var body = (v.body || '').trim(), file = S.chat.file;
      if (!body && !file) return;
      await E.sendMessage(S.me.id, body, file);
      S.chat.file = null; f.reset(); $('pendingFile').innerHTML = ''; $('chatInput').style.height = 'auto'; S.lastSig = '';
      await refreshChatList(); afterChat();
    },
    profile: async function (f, v) { await db.rpc('update_my_profile', { p_phone: v.phone || '' }); await refreshData(false); ui.ok('Profile saved ✓'); },
    password: async function (f, v) {
      if (v.pw1 !== v.pw2) throw new Error('Passwords do not match.');
      await db.auth.changePassword(v.pw1); f.reset(); ui.ok('Password updated ✓');
    },
    dayoff: async function (f, v) { await E.requestDayOff(v.date, v.reason); ui.closeAllModals(); ui.ok('Day-off request sent ✓'); await refreshData(false); renderPage(false); }
  }, {
    'chat-file': function (el) {
      var f = el.files && el.files[0]; if (!f) return;
      if (f.size > db.files.max) { el.value = ''; throw new Error('File is too large (max ' + U.fmtSize(db.files.max) + ').'); }
      S.chat.file = f; $('pendingFile').innerHTML = String(pendingFileHtml());
    }
  });

  boot();
})();

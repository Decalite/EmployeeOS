/*
 * EmployeeOS engine.js - business rules.
 * Pure functions (pay, tiers, ranking, summaries) are unit-tested in tests/engine.test.js.
 * Async functions talk to EOS.db only; they never know which backend is active.
 *
 * RULES THAT MATTER
 *  - Daily pay      = (monthly base salary / working_days) * min(hours worked that day / standard_hours, 1)
 *  - Session start  = moment the admin APPROVES the start request.
 *  - Session end    = moment the employee REQUESTED leave (so a late approval never inflates hours).
 *  - Points         = hours * per_hour  (+ attendance_day points once per day with >= min hours) + manual adjustments.
 *  - Tier           = highest tier whose threshold <= points earned in the last `window_days` (so tiers can fall).
 *                     A manual admin override pins the tier until the admin switches back to Automatic.
 *  - Promotion bonus is paid once per tier per employee.
 */
(function (root) {
  'use strict';
  var EOS = root.EOS = root.EOS || {};
  var U = EOS.util;
  var E = EOS.engine = {};
  function db() { return EOS.db; }
  function fail(m) { var e = new Error(m); e.friendly = true; return e; }

  E.TIERS = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'];
  E.DEFAULT_RULES = {
    pay: { working_days: 26, standard_hours: 8 },
    points: { per_hour: 10, attendance_day: 20, min_hours_for_attendance: 4 },
    tiers: { window_days: 30, thresholds: { Bronze: 0, Silver: 300, Gold: 800, Platinum: 1600, Diamond: 2400 } },
    rewards: { promotion_bonus: { Silver: 200, Gold: 500, Platinum: 1000, Diamond: 2000 }, monthly_top: [1000, 600, 300] }
  };
  E.mergeRules = function (saved) {
    var d = U.clone(E.DEFAULT_RULES); saved = saved || {};
    ['pay', 'points'].forEach(function (k) { Object.assign(d[k], saved[k] || {}); });
    if (saved.tiers) { d.tiers.window_days = saved.tiers.window_days != null ? saved.tiers.window_days : d.tiers.window_days; Object.assign(d.tiers.thresholds, saved.tiers.thresholds || {}); }
    if (saved.rewards) { Object.assign(d.rewards.promotion_bonus, saved.rewards.promotion_bonus || {}); if (Array.isArray(saved.rewards.monthly_top)) d.rewards.monthly_top = saved.rewards.monthly_top.slice(0, 10); }
    d.tiers.thresholds.Bronze = 0;
    return d;
  };
  E.validateRules = function (r) {
    function n(v, name, min, max) { v = Number(v); if (!isFinite(v) || v < min || (max != null && v > max)) throw fail(name + ' must be between ' + min + ' and ' + (max == null ? 'any' : max) + '.'); }
    n(r.pay.working_days, 'Working days per month', 1, 31); n(r.pay.standard_hours, 'Standard hours per day', 1, 24);
    n(r.points.per_hour, 'Points per hour', 0, 10000); n(r.points.attendance_day, 'Attendance points', 0, 10000); n(r.points.min_hours_for_attendance, 'Minimum hours for attendance', 0, 24);
    n(r.tiers.window_days, 'Tier window (days)', 1, 365);
    var prev = 0;
    E.TIERS.slice(1).forEach(function (t) { var v = Number(r.tiers.thresholds[t]); n(v, t + ' threshold', 1, 10000000); if (v <= prev) throw fail('Tier thresholds must increase: ' + t + ' must be above the previous tier.'); prev = v; });
    E.TIERS.slice(1).forEach(function (t) { n(r.rewards.promotion_bonus[t], t + ' promotion bonus', 0, 10000000); });
    r.rewards.monthly_top.forEach(function (v, i) { n(v, 'Monthly reward #' + (i + 1), 0, 10000000); });
    return true;
  };

  /* ---------- pure helpers ---------- */
  E.dailyRate = function (salary, rules) { return U.round2((Number(salary) || 0) / rules.pay.working_days); };
  E.dayPay = function (salary, rules, hours) {
    var f = Math.min(Math.max(Number(hours) || 0, 0) / rules.pay.standard_hours, 1);
    return U.round2(E.dailyRate(salary, rules) * f);
  };
  E.tierIndex = function (t) { return Math.max(0, E.TIERS.indexOf(t)); };
  E.tierForPoints = function (pts, rules) {
    var t = 'Bronze';
    E.TIERS.forEach(function (n) { if (pts >= rules.tiers.thresholds[n]) t = n; });
    return t;
  };
  E.tierProgress = function (pts, tier, rules) {
    var i = E.tierIndex(tier), next = E.TIERS[i + 1] || null;
    if (!next) return { next: null, pct: 100, remaining: 0, nextAt: null };
    var lo = rules.tiers.thresholds[tier], hi = rules.tiers.thresholds[next];
    var pct = Math.max(0, Math.min(100, Math.round((pts - lo) / Math.max(1, hi - lo) * 100)));
    return { next: next, pct: pct, remaining: Math.max(0, hi - pts), nextAt: hi };
  };
  E.level = function (xp) { xp = Math.max(0, Number(xp) || 0); var per = 200; return { level: Math.floor(xp / per) + 1, into: xp % per, per: per, pct: Math.round((xp % per) / per * 100) }; };
  E.rankRows = function (rows) {
    var s = rows.slice().sort(function (a, b) { return (b.points - a.points) || String(a.full_name).localeCompare(String(b.full_name)); });
    var rank = 0, prev = null;
    s.forEach(function (r, i) { if (prev === null || r.points !== prev) rank = i + 1; r.rank = rank; prev = r.points; });
    return s;
  };
  E.periodSince = function (period, now) {
    now = now || new Date();
    if (period === 'daily') return U.startOfDay(now).toISOString();
    if (period === 'weekly') return U.startOfWeek(now).toISOString();
    if (period === 'monthly') return U.startOfMonth(now).toISOString();
    return null;
  };
  function bucket(list) {
    var b = { daily: 0, extra: 0, bonus: 0, deduction: 0 };
    list.forEach(function (e) { if (b[e.entry_type] !== undefined) b[e.entry_type] += Number(e.amount) || 0; });
    Object.keys(b).forEach(function (k) { b[k] = U.round2(b[k]); });
    b.net = U.round2(b.daily + b.extra + b.bonus - b.deduction);
    return b;
  }
  E.bucket = bucket;
  E.summarize = function (entries, sessions, monthKey, todayKey) {
    var m = entries.filter(function (e) { return String(e.entry_date).slice(0, 7) === monthKey; });
    var t = entries.filter(function (e) { return String(e.entry_date).slice(0, 10) === todayKey; });
    var ms = sessions.filter(function (s) { return s.ended_at && String(s.work_date).slice(0, 7) === monthKey; });
    var ts = sessions.filter(function (s) { return s.ended_at && String(s.work_date).slice(0, 10) === todayKey; });
    var month = bucket(m); month.hours = U.round2(U.sum(ms, function (s) { return s.hours; }));
    month.days = Object.keys(U.groupBy(ms.filter(function (s) { return Number(s.hours) > 0; }), function (s) { return String(s.work_date).slice(0, 10); })).length;
    var today = bucket(t); today.hours = U.round2(U.sum(ts, function (s) { return s.hours; }));
    var total = bucket(entries); total.hours = U.round2(U.sum(sessions.filter(function (s) { return s.ended_at; }), function (s) { return s.hours; }));
    return { month: month, today: today, total: total };
  };
  /* day -> {net, hours, entries[], sessions[], leave} for calendars */
  E.dayMap = function (entries, sessions, dayoffs) {
    var map = {};
    function d(k) { k = String(k).slice(0, 10); return map[k] || (map[k] = { net: 0, hours: 0, entries: [], sessions: [], leave: null }); }
    entries.forEach(function (e) { var x = d(e.entry_date); x.entries.push(e); x.net = U.round2(x.net + (e.entry_type === 'deduction' ? -1 : 1) * Number(e.amount)); });
    sessions.forEach(function (s) { var x = d(s.work_date); x.sessions.push(s); x.hours = U.round2(x.hours + (Number(s.hours) || 0)); });
    (dayoffs || []).forEach(function (r) { d(r.request_date).leave = r; });
    return map;
  };
  E.buildTimeline = function (b, names) {
    var out = [];
    (b.requests || []).forEach(function (r) {
      var label = { start: 'Start-work request', leave: 'Leave request', dayoff: 'Day-off request (' + (r.request_date || '') + ')' }[r.request_type] || r.request_type;
      out.push({ at: r.requested_at, kind: 'request', text: label + ' — ' + r.status });
    });
    (b.sessions || []).forEach(function (s) { out.push({ at: s.started_at, kind: 'session', text: 'Work started' }); if (s.ended_at) out.push({ at: s.ended_at, kind: 'session', text: 'Work ended — ' + U.fmtHours(s.hours) }); });
    (b.entries || []).forEach(function (e) { out.push({ at: e.created_at, kind: 'pay', text: ({ daily: 'Daily pay', extra: 'Extra earning', bonus: 'Bonus', deduction: 'Deduction' }[e.entry_type]) + ' ' + U.money(e.amount) + (e.description ? ' — ' + e.description : '') }); });
    (b.tiers || []).forEach(function (t) { out.push({ at: t.created_at, kind: 'tier', text: (t.manual ? 'Tier set by admin: ' : 'Tier changed: ') + (t.old_tier || '—') + ' → ' + t.new_tier + (t.reason ? ' (' + t.reason + ')' : '') }); });
    (b.logs || []).forEach(function (l) { out.push({ at: l.created_at, kind: 'admin', text: l.action + (l.details ? ' — ' + l.details : '') + (names && names[l.actor_id] ? ' (by ' + names[l.actor_id] + ')' : '') }); });
    return out.filter(function (x) { return x.at; }).sort(function (a, b) { return U.ms(b.at) - U.ms(a.at); });
  };

  /* ---------- settings ---------- */
  var cache = { rules: null };
  E.getRules = async function (force) {
    if (cache.rules && !force) return cache.rules;
    var rows = await db().list('settings', { eq: { key: 'rules' } });
    cache.rules = E.mergeRules(rows[0] && rows[0].value);
    return cache.rules;
  };
  E.saveRules = async function (rules) {
    E.validateRules(rules);
    var rows = await db().update('settings', { eq: { key: 'rules' } }, { value: rules });
    if (!rows.length) await db().insert('settings', { key: 'rules', value: rules });
    cache.rules = E.mergeRules(rules);
    await E.log(null, 'Updated pay & ranking rules', '');
  };

  /* ---------- logging / notifications ---------- */
  E.log = async function (employeeId, action, details) {
    try { await db().insert('activity_log', { actor_id: EOS.me.id, employee_id: employeeId || null, action: action, details: details || '' }, { quiet: true }); } catch (e) { console.warn('log failed', e); }
  };
  E.notifyMany = async function (userIds, title, body, kind) {
    if (!userIds.length) return;
    await db().insert('notifications', userIds.map(function (id) { return { user_id: id, title: title, body: body || '', kind: kind || 'info' }; }), { quiet: true });
  };
  E.notify = function (userId, title, body, kind) { return E.notifyMany([userId], title, body, kind).catch(function (e) { console.warn('notify failed', e); }); };

  /* ---------- work flow ---------- */
  E.workState = async function (empId) {
    var r = await Promise.all([
      db().list('work_sessions', { eq: { employee_id: empId, ended_at: null }, order: 'started_at.desc' }),
      db().list('work_requests', { eq: { employee_id: empId, status: 'pending' }, order: 'requested_at.desc' })
    ]);
    return {
      open: r[0][0] || null,
      pendingStart: r[1].filter(function (x) { return x.request_type === 'start'; })[0] || null,
      pendingLeave: r[1].filter(function (x) { return x.request_type === 'leave'; })[0] || null,
      pendingDayoffs: r[1].filter(function (x) { return x.request_type === 'dayoff'; })
    };
  };
  E.requestStart = async function () {
    var me = EOS.me, st = await E.workState(me.id);
    if (st.open) throw fail('You already have an active work session.');
    if (st.pendingStart) throw fail('Your start request is already waiting for approval.');
    var rows = await db().insert('work_requests', { employee_id: me.id, request_type: 'start', request_date: U.todayKey() });
    return rows[0];
  };
  E.requestLeave = async function () {
    var me = EOS.me, st = await E.workState(me.id);
    if (!st.open) throw fail('You are not currently working.');
    if (st.pendingLeave) throw fail('Your leave request is already waiting for approval.');
    var rows = await db().insert('work_requests', { employee_id: me.id, request_type: 'leave', request_date: U.todayKey(), session_id: st.open.id });
    return rows[0];
  };
  E.requestDayOff = async function (date, reason) {
    var me = EOS.me;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) throw fail('Choose a date.');
    if (date < U.todayKey()) throw fail('Choose today or a future date.');
    reason = String(reason || '').trim(); if (reason.length < 3) throw fail('Add a short reason.'); if (reason.length > 300) throw fail('Reason is too long (300 max).');
    var ex = await db().list('work_requests', { eq: { employee_id: me.id, request_type: 'dayoff', request_date: date } });
    if (ex.some(function (r) { return r.status !== 'rejected'; })) throw fail('You already have a day-off request for that date.');
    var rows = await db().insert('work_requests', { employee_id: me.id, request_type: 'dayoff', request_date: date, reason: reason });
    return rows[0];
  };

  E.decideRequest = async function (req, decision, note) {
    var me = EOS.me; if (!me || me.role !== 'admin') throw fail('Admins only.');
    if (['approved', 'rejected'].indexOf(decision) < 0) throw fail('Invalid decision.');
    var now = new Date().toISOString();
    var emp = (await db().list('profiles', { eq: { id: req.employee_id } }))[0]; if (!emp) throw fail('Employee no longer exists.');
    if (decision === 'approved' && req.request_type === 'start') {
      var st = await E.workState(req.employee_id); if (st.open) throw fail(emp.full_name + ' already has an active session.');
    }
    var claimed = await db().update('work_requests', { eq: { id: req.id, status: 'pending' } }, { status: decision, reviewed_by: me.id, reviewed_at: now, review_note: note || null });
    if (!claimed.length) throw fail('This request was already handled.');
    try {
      if (decision === 'approved') {
        if (req.request_type === 'start') {
          await db().insert('work_sessions', { employee_id: req.employee_id, started_at: now, work_date: U.todayKey(), start_request_id: req.id });
        } else if (req.request_type === 'leave') {
          var open = (await db().list('work_sessions', { eq: { employee_id: req.employee_id, ended_at: null } }))[0];
          if (open) await E.closeSession(open, req.requested_at, req.id);
        }
      }
    } catch (e) {
      await db().update('work_requests', { eq: { id: req.id } }, { status: 'pending', reviewed_by: null, reviewed_at: null, review_note: null });
      throw e;
    }
    var label = { start: 'Start work', leave: 'Leave', dayoff: 'Day off (' + req.request_date + ')' }[req.request_type];
    await E.notify(req.employee_id, label + ' request ' + decision, note || (decision === 'approved' ? (req.request_type === 'start' ? 'Your work session has started.' : 'Approved by admin.') : 'Not approved by admin.'), decision === 'approved' ? 'success' : 'warning');
    await E.log(req.employee_id, label + ' request ' + decision, note || '');
    return true;
  };

  E.closeSession = async function (session, endIso, endRequestId) {
    var start = U.ms(session.started_at), end = Math.max(U.ms(endIso || new Date().toISOString()), start);
    var hours = U.round2((end - start) / 3600000);
    var patch = { ended_at: new Date(end).toISOString(), hours: hours }; if (endRequestId) patch.end_request_id = endRequestId;
    var rows = await db().update('work_sessions', { eq: { id: session.id, ended_at: null } }, patch);
    if (!rows.length) return null;
    var rules = await E.getRules();
    var emp = (await db().list('profiles', { eq: { id: session.employee_id } }))[0];
    var dayHours = await E.recomputeDay(emp, session.work_date, rules);
    await E.awardSessionPoints(emp, session, hours, dayHours, rules, patch.ended_at);
    await E.recalcTier(emp.id);
    return rows[0];
  };
  E.recomputeDay = async function (emp, date, rules) {
    var ss = await db().list('work_sessions', { eq: { employee_id: emp.id, work_date: date }, notnull: ['ended_at'] });
    var hours = U.round2(U.sum(ss, function (s) { return s.hours; }));
    var amount = E.dayPay(emp.monthly_base_salary, rules, hours);
    var ex = (await db().list('earning_entries', { eq: { employee_id: emp.id, entry_date: date, entry_type: 'daily' } }))[0];
    if (amount > 0) {
      var desc = 'Work pay for ' + U.fmtHours(hours);
      if (ex) await db().update('earning_entries', { eq: { id: ex.id } }, { amount: amount, description: desc });
      else await db().insert('earning_entries', { employee_id: emp.id, entry_date: date, entry_type: 'daily', amount: amount, description: desc, created_by: EOS.me.id });
    } else if (ex) await db().remove('earning_entries', { eq: { id: ex.id } });
    return hours;
  };
  E.awardSessionPoints = async function (emp, session, hours, dayHours, rules, atIso) {
    var pts = Math.round(hours * rules.points.per_hour);
    if (pts > 0) await db().insert('points_ledger', { employee_id: emp.id, points: pts, reason: 'Worked ' + U.fmtHours(hours), source: 'work', ref: 'sess:' + session.id, created_by: EOS.me.id, created_at: atIso });
    var ref = 'att:' + session.work_date;
    if (rules.points.attendance_day > 0 && dayHours >= rules.points.min_hours_for_attendance) {
      var ex = await db().list('points_ledger', { eq: { employee_id: emp.id, ref: ref } });
      if (!ex.length) await db().insert('points_ledger', { employee_id: emp.id, points: rules.points.attendance_day, reason: 'Attendance ' + U.fmtDate(session.work_date), source: 'attendance', ref: ref, created_by: EOS.me.id, created_at: atIso });
    }
  };
  E.endSessionNow = async function (session) {
    var r = await E.closeSession(session, new Date().toISOString(), null);
    if (r) { await E.notify(session.employee_id, 'Work session ended', 'An admin ended your session.', 'info'); await E.log(session.employee_id, 'Admin ended work session', ''); }
    return r;
  };

  /* ---------- pay entries ---------- */
  E.addEntry = async function (empId, type, amount, description, date) {
    if (['extra', 'bonus', 'deduction'].indexOf(type) < 0) throw fail('Choose a valid type.');
    amount = Number(amount); if (!isFinite(amount) || amount <= 0) throw fail('Enter an amount above zero.');
    if (amount > 10000000) throw fail('Amount is too large.');
    description = String(description || '').trim().slice(0, 200); if (!description) throw fail('Add a reason / description.');
    var rows = await db().insert('earning_entries', { employee_id: empId, entry_date: date || U.todayKey(), entry_type: type, amount: U.round2(amount), description: description, created_by: EOS.me.id });
    var label = { extra: 'Extra earning', bonus: 'Bonus', deduction: 'Deduction' }[type];
    await E.notify(empId, label + ': ' + U.money(amount), description, type === 'deduction' ? 'warning' : 'success');
    await E.log(empId, label + ' added ' + U.money(amount), description);
    return rows[0];
  };
  E.deleteEntry = async function (entry) {
    await db().remove('earning_entries', { eq: { id: entry.id } });
    await E.log(entry.employee_id, 'Removed ' + entry.entry_type + ' entry ' + U.money(entry.amount), entry.description || '');
  };
  E.setSalary = async function (empId, salary) {
    salary = Number(salary); if (!(salary >= 0)) throw fail('Salary must be zero or more.');
    var p = await db().admin.updateEmployee(empId, { monthly_base_salary: salary });
    await E.notify(empId, 'Your monthly salary was updated', 'New base salary: ' + U.money(salary), 'info');
    await E.log(empId, 'Base salary set to ' + U.money(salary), '');
    return p;
  };

  /* ---------- points & tiers ---------- */
  E.recalcTier = async function (empId) {
    var emp = (await db().list('profiles', { eq: { id: empId } }))[0];
    if (!emp || emp.role !== 'employee' || emp.status !== 'active' || emp.tier_override) return null;
    var rules = await E.getRules();
    var since = new Date(Date.now() - rules.tiers.window_days * 86400000).toISOString();
    var led = await db().list('points_ledger', { eq: { employee_id: empId }, gte: { created_at: since } });
    var pts = U.sum(led, function (l) { return l.points; });
    var target = E.tierForPoints(pts, rules);
    if (target === emp.tier) return null;
    var up = E.tierIndex(target) > E.tierIndex(emp.tier), bonus = 0;
    await db().update('profiles', { eq: { id: empId } }, { tier: target });
    if (up && rules.rewards.promotion_bonus[target] > 0) {
      var prior = await db().list('tier_history', { eq: { employee_id: empId, new_tier: target } });
      if (!prior.some(function (h) { return Number(h.bonus) > 0; })) {
        bonus = Number(rules.rewards.promotion_bonus[target]);
        await db().insert('earning_entries', { employee_id: empId, entry_date: U.todayKey(), entry_type: 'bonus', amount: bonus, description: 'Promotion bonus: ' + target, ref: 'promo:' + target, created_by: EOS.me.id });
      }
    }
    await db().insert('tier_history', { employee_id: empId, old_tier: emp.tier, new_tier: target, reason: 'Automatic: ' + pts + ' pts in last ' + rules.tiers.window_days + ' days', points_snapshot: pts, manual: false, bonus: bonus, created_by: EOS.me.id });
    await E.notify(empId, up ? 'Promoted to ' + target + '!' : 'Tier changed to ' + target, up ? ('Great work.' + (bonus ? ' Promotion bonus ' + U.money(bonus) + ' added.' : '')) : 'Your recent points moved you down. Keep going to climb back up.', up ? 'success' : 'warning');
    return { from: emp.tier, to: target, bonus: bonus, points: pts };
  };
  E.recalcAll = async function () {
    var emps = await db().list('profiles', { eq: { role: 'employee', status: 'active' } }), changes = [];
    for (var i = 0; i < emps.length; i++) { var c = await E.recalcTier(emps[i].id); if (c) changes.push(Object.assign({ name: emps[i].full_name }, c)); }
    return changes;
  };
  E.setTierManual = async function (empId, tier, reason) {
    var emp = (await db().list('profiles', { eq: { id: empId } }))[0]; if (!emp) throw fail('Employee not found.');
    if (tier === null || tier === 'auto') {
      await db().update('profiles', { eq: { id: empId } }, { tier_override: null });
      var ch = await E.recalcTier(empId);
      await E.log(empId, 'Tier switched back to automatic', '');
      return ch;
    }
    if (E.TIERS.indexOf(tier) < 0) throw fail('Invalid tier.');
    await db().update('profiles', { eq: { id: empId } }, { tier: tier, tier_override: tier });
    await db().insert('tier_history', { employee_id: empId, old_tier: emp.tier, new_tier: tier, reason: String(reason || 'Set by admin').slice(0, 200), points_snapshot: null, manual: true, bonus: 0, created_by: EOS.me.id });
    await E.notify(empId, 'Your tier is now ' + tier, 'An admin updated your tier.', 'info');
    await E.log(empId, 'Tier manually set to ' + tier, reason || '');
  };
  E.adjustPoints = async function (empId, delta, reason) {
    delta = Math.round(Number(delta)); if (!delta || !isFinite(delta)) throw fail('Enter a non-zero number of points.');
    if (Math.abs(delta) > 100000) throw fail('Too many points in one adjustment.');
    reason = String(reason || '').trim(); if (reason.length < 3) throw fail('Add a reason.');
    await db().insert('points_ledger', { employee_id: empId, points: delta, reason: reason.slice(0, 200), source: 'manual', ref: null, created_by: EOS.me.id });
    await E.notify(empId, (delta > 0 ? '+' : '') + delta + ' points', reason, delta > 0 ? 'success' : 'warning');
    await E.log(empId, 'Points adjusted ' + (delta > 0 ? '+' : '') + delta, reason);
    return E.recalcTier(empId);
  };
  E.leaderboard = async function (period) {
    var rows = await db().rpc('leaderboard', { p_since: E.periodSince(period) });
    return E.rankRows((rows || []).map(function (r) { return Object.assign({}, r, { points: Number(r.points) }); }));
  };
  E.awardMonthlyRewards = async function (monthKey) {
    var rules = await E.getRules(), tops = rules.rewards.monthly_top;
    var from = U.monthStart(monthKey), to = U.monthStart(U.addMonths(monthKey, 1));
    var emps = await db().list('profiles', { eq: { role: 'employee', status: 'active' } });
    var led = await db().list('points_ledger', { gte: { created_at: from.toISOString() }, lt: { created_at: to.toISOString() } });
    var rows = E.rankRows(emps.map(function (e) { return { employee_id: e.id, full_name: e.full_name, points: U.sum(led.filter(function (l) { return l.employee_id === e.id; }), function (l) { return l.points; }) }; }));
    var awarded = [];
    for (var i = 0; i < tops.length && i < rows.length; i++) {
      var r = rows[i], amt = Number(tops[i]); if (!(amt > 0) || r.points <= 0) continue;
      var ref = 'reward:' + monthKey + ':' + (i + 1);
      var ex = await db().list('earning_entries', { eq: { ref: ref } });
      if (ex.length) continue;
      await db().insert('earning_entries', { employee_id: r.employee_id, entry_date: U.todayKey(), entry_type: 'bonus', amount: amt, description: 'Monthly leaderboard #' + (i + 1) + ' reward (' + U.monthLabel(monthKey) + ')', ref: ref, created_by: EOS.me.id });
      await E.notify(r.employee_id, 'Leaderboard reward ' + U.money(amt), 'You finished #' + (i + 1) + ' in ' + U.monthLabel(monthKey) + '.', 'success');
      awarded.push({ name: r.full_name, place: i + 1, amount: amt });
    }
    await E.log(null, 'Monthly rewards processed for ' + monthKey, awarded.length + ' awarded');
    return awarded;
  };

  /* ---------- messaging / announcements / resources ---------- */
  E.sendMessage = async function (employeeId, body, file) {
    var me = EOS.me; body = String(body || '').trim();
    if (!body && !file) throw fail('Type a message or attach a file.');
    if (body.length > 2000) throw fail('Message is too long (2000 max).');
    var att = {};
    if (file) { var up = await db().files.upload('chat', file, employeeId); att = { attachment_path: up.path, attachment_name: up.name, attachment_type: up.type, attachment_size: up.size }; }
    var rows = await db().insert('messages', Object.assign({ employee_id: employeeId, sender_id: me.id, sender_role: me.role === 'admin' ? 'admin' : 'employee', body: body }, att));
    return rows[0];
  };
  E.markRead = function (employeeId) { return db().rpc('mark_read', { p_employee: employeeId }); };
  E.postAnnouncement = async function (title, body, file) {
    title = String(title || '').trim(); body = String(body || '').trim();
    if (!title) throw fail('Add a title.'); if (!body && !file) throw fail('Write the announcement text.');
    var att = {};
    if (file) { var up = await db().files.upload('resources', file, 'announcements'); att = { attachment_path: up.path, attachment_name: up.name, attachment_type: up.type }; }
    var rows = await db().insert('announcements', Object.assign({ title: title.slice(0, 120), body: body.slice(0, 4000), author_id: EOS.me.id }, att));
    var emps = await db().list('profiles', { eq: { role: 'employee', status: 'active' } });
    await E.notifyMany(emps.map(function (e) { return e.id; }), 'Announcement: ' + title, body.slice(0, 140), 'announcement');
    await E.log(null, 'Posted announcement', title);
    return rows[0];
  };
  E.addResource = async function (p) {
    var title = String(p.title || '').trim(); if (!title) throw fail('Add a title.');
    var type = p.type, att = {};
    if (p.file) {
      var up = await db().files.upload('resources', p.file, 'library');
      att = { storage_path: up.path, file_name: up.name, mime_type: up.type, file_size: up.size };
      var k = U.fileKind(up.type, up.name); type = k === 'file' ? 'document' : k;
    } else {
      if (['note', 'instruction'].indexOf(type) < 0) throw fail('Attach a file, or choose Note / Instruction and write the text.');
      if (!String(p.body || '').trim()) throw fail('Write the text for this ' + type + '.');
    }
    var rows = await db().insert('resources', Object.assign({ title: title.slice(0, 120), resource_type: type, description: String(p.description || '').slice(0, 400), body: String(p.body || '').slice(0, 20000) || null, created_by: EOS.me.id }, att));
    await E.log(null, 'Published resource', title);
    return rows[0];
  };
  E.removeResource = async function (r) {
    await db().remove('resources', { eq: { id: r.id } });
    if (r.storage_path) await db().files.remove('resources', r.storage_path);
    await E.log(null, 'Removed resource', r.title);
  };

  /* ---------- employee data bundle ---------- */
  E.loadBundle = async function (empId) {
    var f = { eq: { employee_id: empId } };
    var r = await Promise.all([
      db().list('earning_entries', Object.assign({ order: 'entry_date.desc' }, f)),
      db().list('work_sessions', Object.assign({ order: 'started_at.desc' }, f)),
      db().list('work_requests', Object.assign({ order: 'requested_at.desc' }, f)),
      db().list('points_ledger', Object.assign({ order: 'created_at.desc' }, f)),
      db().list('tier_history', Object.assign({ order: 'created_at.desc' }, f))
    ]);
    return { entries: r[0], sessions: r[1], requests: r[2], ledger: r[3], tiers: r[4] };
  };

  /* ---------- demo seeding (preview mode only; every value goes through the real engine) ---------- */
  E.seedDemo = async function () {
    var names = [['Aarav Sharma', 28000], ['Priya Singh', 25000], ['Kabir Verma', 22000], ['Meera Nair', 24000]];
    var existing = await db().list('profiles', { eq: { role: 'employee' } });
    var n = existing.length, out = [], rules = await E.getRules();
    for (var i = 0; i < names.length; i++) {
      var code = 'EMP' + String(n + i + 1).padStart(3, '0'), pw = U.randomPassword(10);
      var p = await db().admin.createEmployee({ employee_code: code, full_name: names[i][0], password: pw, monthly_base_salary: names[i][1] });
      out.push({ code: code, name: p.full_name, password: pw });
      for (var d = 6; d >= 1; d--) {
        if ((i + d) % 4 === 0) continue; // a day off
        var day = U.addDays(U.todayKey(), -d), hrs = 5 + ((i * 3 + d * 2) % 5);
        var start = U.parseKey(day); start.setHours(9, 30, 0, 0);
        var end = new Date(start.getTime() + hrs * 3600000);
        var s = (await db().insert('work_sessions', { employee_id: p.id, started_at: start.toISOString(), work_date: day }))[0];
        await E.closeSession(s, end.toISOString(), null);
      }
    }
    return out;
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = EOS;
})(typeof window !== 'undefined' ? window : globalThis);

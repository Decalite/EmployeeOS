/* EmployeeOS shared.js - pieces used by both the employee and admin apps (chat rendering, clipboard). */
(function (root) {
  'use strict';
  var EOS = root.EOS = root.EOS || {};
  var U = EOS.util, ui = EOS.ui, html = U.html, icon = ui.icon;
  var C = EOS.shared = {};

  /* Signed/local URLs for inline image + video attachments */
  C.resolveUrls = function (msgs) {
    return Promise.all(msgs.map(function (m) {
      if (m.attachment_path && !m._url && /^(image|video)\//.test(m.attachment_type || '')) {
        return EOS.db.files.url('chat', m.attachment_path).then(function (u) { m._url = u; }, function () { m._url = null; });
      }
      return null;
    }));
  };

  C.attHtml = function (m) {
    if (!m.attachment_path) return '';
    var t = m.attachment_type || '', k = U.fileKind(t, m.attachment_name);
    if (k === 'image' && m._url) return html`<a class="att" href="#" data-act="view-att" data-path="${m.attachment_path}" data-name="${m.attachment_name}" data-type="${t}"><img src="${m._url}" alt="${m.attachment_name}" loading="lazy"></a>`;
    if (k === 'video' && m._url) return html`<span class="att"><video src="${m._url}" controls playsinline preload="metadata"></video></span>`;
    return html`<a class="att file" href="#" data-act="view-att" data-path="${m.attachment_path}" data-name="${m.attachment_name}" data-type="${t}">${icon('file')}<span class="grow" style="overflow:hidden;text-overflow:ellipsis">${m.attachment_name}</span><span class="muted tiny">${U.fmtSize(m.attachment_size)}</span></a>`;
  };

  /* role = the viewer's role: their own messages sit on the right and show Sent/Seen */
  C.msgList = function (msgs, role) {
    var out = [], lastDay = '', lastMine = -1;
    msgs.forEach(function (m, i) { if (m.sender_role === role) lastMine = i; });
    msgs.forEach(function (m, i) {
      var dk = U.dateKey(new Date(m.created_at)), mine = m.sender_role === role;
      if (dk !== lastDay) { out.push(html`<div class="dayline">${dk === U.todayKey() ? 'Today' : U.fmtDate(m.created_at, true)}</div>`); lastDay = dk; }
      var next = msgs[i + 1];
      var showMeta = !next || next.sender_role !== m.sender_role || U.dateKey(new Date(next.created_at)) !== dk || (U.ms(next.created_at) - U.ms(m.created_at)) > 300000;
      out.push(html`<div class="bub ${mine ? 'me' : 'them'}">${m.body ? html`<span>${m.body}</span>` : ''}${C.attHtml(m)}</div>`);
      if (showMeta) out.push(html`<div class="meta ${mine ? 'me' : 'them'}">${U.fmtTime(m.created_at)}${mine && i === lastMine ? (m.read_at ? ' · Seen' : ' · Sent') : ''}</div>`);
    });
    return out.length ? html`${out}` : ui.empty('chat', 'No messages yet.');
  };

  C.copy = function (text) {
    return new Promise(function (resolve) {
      function fallback() {
        var ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;font-size:16px';
        document.body.appendChild(ta); ta.focus(); ta.select(); ta.setSelectionRange(0, text.length);
        var ok = false; try { ok = document.execCommand('copy'); } catch (e) {} ta.remove(); resolve(ok);
      }
      try { if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text).then(function () { resolve(true); }, fallback); } catch (e) {}
      fallback();
    });
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = EOS;
})(typeof window !== 'undefined' ? window : globalThis);

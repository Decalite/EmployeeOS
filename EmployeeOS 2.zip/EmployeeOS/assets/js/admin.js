/* EmployeeOS admin.js - the admin console (admin.html). All authority is enforced server-side (RLS / Edge Function). */
(function () {
  'use strict';
  var EOS = window.EOS, U = EOS.util, ui = EOS.ui, E = EOS.engine, db = EOS.db, C = EOS.shared;
  var html = U.html, raw = U.raw, icon = ui.icon;
  var $ = function (id) { return document.getElementById(id); };

  var S = {
    me: null, rules: null, all: [], emps: [], pending: [], open: [], unread: [], route: [], names: {},
    month: U.monthKey(), lbPeriod: 'weekly', lb: null, search: '', det: null, detTab: 'profile',
    chat: { threads: [], msgs: [], file: null, anns: [] }, attRange: 'week', unsub: null, timers: [], lastRecalc: 0, lastSig: ''
  };
  var TITLES = { overview: 'Overview', requests: 'Requests', employees: 'Employees', payroll: 'Payroll', attendance: 'Attendance', ranks: 'Rankings', resources: 'Resources', messages: 'Messages', settings: 'Settings', more: 'More' };

  /* ======================= boot / auth ======================= */
  async function boot() {
    try {
      var me = await db.auth.init();
      if (me && me.role !== 'admin') { await db.auth.signOut(); me = null; ui.hideBoot(); return showLogin('This portal is for administrators only. Employees sign in at the main app.'); }
      if (me) await start(me); else { ui.hideBoot(); await showLogin(); }
    } catch (e) { ui.fatal(e, boot); }
  }
  async function showLogin(notice) {
    var setup = false;
    try { setup = db.mode === 'local' && await db.auth.needsSetup(); } catch (e) { /* ignore */ }
    var form = setup
      ? html`<form class="card stack" data-form="setup"><h3>Create the preview admin</h3><p class="muted small">First run only. Choose your own credentials — nothing is built into the code.</p><div class="err hidden" data-err></div>
          <label class="lbl">Your name<input class="field" name="name" required autocomplete="name"></label>
          <label class="lbl">Email<input class="field" name="email" type="email" required autocomplete="username" autocapitalize="none"></label>
          <label class="lbl">Password (8+ characters)<input class="field" name="pw" type="password" minlength="8" required autocomplete="new-password"></label>
          <button class="btn block" type="submit">Create admin &amp; continue</button></form>`
      : html`<form class="card stack" data-form="login">${notice ? html`<div class="notice">${notice}</div>` : ''}<div class="err hidden" data-err></div>
          <label class="lbl">Admin email<input class="field" name="id" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" inputmode="email" required></label>
          <label class="lbl">Password<span class="row nowrap"><input class="field grow" id="loginPw" name="pw" type="password" autocomplete="current-password" required><button class="iconbtn" type="button" data-act="togglepw" aria-label="Show password">${icon('eye')}</button></span></label>
          <button class="btn block" type="submit">Sign in</button></form>`;
    $('root').innerHTML = String(html`${db.mode === 'local' ? html`<div class="previewbar">PREVIEW MODE · data is stored only in this browser</div>` : ''}
      <div class="center-screen"><div class="login stack-l"><div class="center"><div class="logo">${icon('shield', 'lg')}</div><h1>Employee<span style="color:var(--lav)">OS</span> Admin</h1><p class="muted" style="margin-top:6px">Secure management console</p></div>${form}
      <p class="muted small center">Employee? <a href="index.html">Go to the employee app</a></p></div></div>`);
    ui.hideBoot();
  }
  async function start(me) {
    S.me = EOS.me = me;
    S.rules = await E.getRules(true);
    await refreshCore();
    ui.hideBoot(); renderShell();
    S.unsub = db.subscribe(['work_requests', 'work_sessions', 'earning_entries', 'points_ledger', 'tier_history', 'messages', 'profiles', 'resources', 'announcements'], schedule);
    S.timers.push(setInterval(tick, 1000)); S.timers.push(setInterval(schedule, 30000));
    window.addEventListener('hashchange', route);
    maybeRecalc();
    route();
  }
  function stop() { S.timers.forEach(clearInterval); S.timers = []; if (S.unsub) S.unsub(); S.unsub = null; window.removeEventListener('hashchange', route); S.me = EOS.me = null; S.det = null; S.lb = null; }
  async function logout(msg) { ui.closeAllModals(); stop(); await db.auth.signOut(); location.hash = ''; await showLogin(msg); }

  async function refreshCore() {
    var r = await Promise.all([
      db.list('profiles', { order: 'full_name.asc' }), db.list('work_requests', { eq: { status: 'pending' }, order: 'requested_at.asc' }),
      db.list('work_sessions', { eq: { ended_at: null } }), db.list('messages', { eq: { sender_role: 'employee', read_at: null } })]);
    S.all = r[0]; S.emps = r[0].filter(function (p) { return p.role === 'employee'; }); S.names = U.byId(r[0]); S.pending = r[1]; S.open = r[2]; S.unread = r[3];
    var me = S.names[S.me.id]; if (!me || me.status !== 'active' || me.role !== 'admin') { await logout('Your admin access is no longer active.'); throw new Error('inactive'); }
    S.me = EOS.me = me;
  }
  async function maybeRecalc(force) {
    if (!force && Date.now() - S.lastRecalc < 600000) return [];
    S.lastRecalc = Date.now();
    try { var ch = await E.recalcAll(); if (ch.length) { await refreshCore(); renderPage(false); } return ch; } catch (e) { console.warn('recalc failed', e); return []; }
  }
  var schedTimer = null;
  function schedule() {
    clearTimeout(schedTimer);
    schedTimer = setTimeout(async function () {
      if (!S.me) return;
      try {
        var prevP = S.pending.length;
        await refreshCore(); updateChrome();
        if (S.pending.length > prevP) ui.toast('New request from an employee');
        if (S.route[0] === 'messages') { await refreshMessages(); return; }
        var a = document.activeElement;
        if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && $('view') && $('view').contains(a)) { S.dirty = true; return; }
        var p = PAGES[S.route[0]]; if (p && p.load) await p.load();
        renderPage(false);
      } catch (e) { if (e && e.message !== 'inactive') console.warn('refresh failed', e); }
    }, 350);
  }
  document.addEventListener('focusout', function () { if (S.dirty && S.me) { S.dirty = false; setTimeout(function () { var a = document.activeElement; if (S.me && !(a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName))) schedule(); }, 150); } });

  /* ======================= helpers ======================= */
  function empName(id) { return (S.names[id] && S.names[id].full_name) || 'Former employee'; }
  function statusOf(e) {
    if (e.status === 'suspended') return ['Suspended', 'red'];
    if (S.open.some(function (s) { return s.employee_id === e.id; })) return ['Working', 'green'];
    if (S.pending.some(function (r) { return r.employee_id === e.id && r.request_type === 'start'; })) return ['Start requested', 'gold'];
    return ['Offline', 'gray'];
  }
  function spill(e) { var s = statusOf(e); return html`<span class="pill ${s[1]}">${s[0]}</span>`; }
  function reqLabel(r) { return { start: 'Start work', leave: 'Leave (end work)', dayoff: 'Day off · ' + (r.request_date || '') }[r.request_type] || r.request_type; }
  function head(title, sub, right) { return html`<div class="page-head"><div><h1>${title}</h1>${sub ? html`<div class="sub">${sub}</div>` : ''}</div><div class="row">${right || ''}</div></div>`; }
  function monthNav(mk) { return html`<div class="row between" style="margin-bottom:12px"><button class="iconbtn" data-act="month-nav" data-n="-1" aria-label="Previous month">${icon('left')}</button><b>${U.monthLabel(mk)}</b><button class="iconbtn" data-act="month-nav" data-n="1" aria-label="Next month" ${mk >= U.monthKey() ? 'disabled' : ''}>${icon('right')}</button></div>`; }
  function monthRange(mk) { return { gte: { entry_date: mk + '-01' }, lt: { entry_date: U.addMonths(mk, 1) + '-01' } }; }
  function genPw() { return U.randomPassword(10); }
  function credsHtml(code, pw, title) {
    return html`<div class="ok"><b>${title}</b><br>Share these with the employee. The password is shown only now.</div>
      <div class="card flat stack-s" style="margin-top:12px"><div class="row between"><span class="muted">Employee ID</span><b id="cId">${code}</b></div><div class="row between"><span class="muted">Password</span><b id="cPw" style="font-family:ui-monospace,Menlo,monospace">${pw}</b></div></div>
      <button class="btn block" style="margin-top:12px" data-act="copy-creds" data-text="ID: ${code}  Password: ${pw}">${icon('clip', 'sm')} Copy login details</button>`;
  }

  /* ======================= shell ======================= */
  var NAV = [['overview', 'Overview', 'dash'], ['requests', 'Requests', 'inbox'], ['employees', 'Employees', 'users'], ['payroll', 'Payroll', 'wallet'], ['attendance', 'Attendance', 'clock'], ['ranks', 'Rankings', 'trophy'], ['resources', 'Resources', 'book'], ['messages', 'Messages', 'chat'], ['settings', 'Settings', 'sliders']];
  var TABS = [['overview', 'Overview', 'dash'], ['requests', 'Requests', 'inbox'], ['employees', 'Staff', 'users'], ['messages', 'Chat', 'chat'], ['more', 'More', 'grid']];
  function badgeFor(k) { return k === 'requests' ? S.pending.length : k === 'messages' ? S.unread.length : 0; }
  function renderShell() {
    $('root').innerHTML = String(html`${db.mode === 'local' ? html`<div class="previewbar">PREVIEW MODE · data is stored only in this browser</div>` : ''}
      <div class="app"><aside class="sidebar" id="sidebar"></aside><div><header class="topbar"><div class="brand"><span class="mark">${icon('shield', 'sm')}</span><span class="wm">Employee<em>OS</em></span></div><div class="row nowrap"><span class="pill">ADMIN</span><a class="iconbtn" href="#/requests" aria-label="Requests">${icon('inbox')}<span class="dot hidden" id="reqDot"></span></a></div></header>
      <main class="main"><div id="view"></div></main></div></div><nav class="tabbar" id="tabbar" aria-label="Main"></nav>`);
    updateChrome();
  }
  function activeTab() { var r = S.route[0] || 'overview'; return TABS.some(function (t) { return t[0] === r; }) ? r : 'more'; }
  function updateChrome() {
    if (!$('tabbar')) return;
    var tab = activeTab(), r = S.route[0] || 'overview';
    $('tabbar').innerHTML = String(html`${TABS.map(function (t) { var n = badgeFor(t[0]); return html`<a href="#/${t[0]}" class="${t[0] === tab ? 'on' : ''}">${icon(t[2])}<span>${t[1]}</span>${n ? html`<span class="dot">${n}</span>` : ''}</a>`; })}`);
    $('sidebar').innerHTML = String(html`<div class="brand"><span class="mark">${icon('shield', 'sm')}</span><span class="wm">Employee<em>OS</em></span></div>
      ${NAV.map(function (t) { var n = badgeFor(t[0]); return html`<a href="#/${t[0]}" class="${t[0] === r ? 'on' : ''}">${icon(t[2])}<span>${t[1]}</span>${n ? html`<span class="dot">${n}</span>` : ''}</a>`; })}
      <div class="sp"></div><div class="row nowrap" style="padding:10px">${ui.avatar(S.me.full_name, true)}<div class="grow"><div class="bold small">${S.me.full_name}</div><div class="muted tiny">Administrator</div></div></div>
      <a href="#/overview" data-act="logout">${icon('logout')}<span>Sign out</span></a>`);
    var d = $('reqDot'); if (d) { d.textContent = S.pending.length; d.classList.toggle('hidden', !S.pending.length); }
  }

  /* ======================= router ======================= */
  var PAGES = {
    overview: { load: loadOverview, render: pageOverview }, requests: { load: loadRequests, render: pageRequests },
    employees: { load: loadEmployee, render: pageEmployees }, payroll: { load: loadPayroll, render: pagePayroll },
    attendance: { load: loadAttendance, render: pageAttendance }, ranks: { load: loadRanks, render: pageRanks },
    resources: { load: loadRes, render: pageResources }, messages: { load: loadMessages, render: pageMessages, after: afterMessages },
    settings: { render: pageSettings }, more: { render: pageMore }
  };
  var seq = 0;
  async function route() {
    if (!S.me) return;
    S.route = ui.parseHash(); if (!S.route.length || !PAGES[S.route[0]]) S.route = ['overview'];
    var my = ++seq, p = PAGES[S.route[0]]; document.title = (TITLES[S.route[0]] || 'Admin') + ' · EmployeeOS Admin'; updateChrome();
    if (p.load) { $('view').innerHTML = String(ui.skeleton(3)); try { await p.load(); } catch (e) { ui.fail(e); } }
    if (my !== seq) return; renderPage(true); window.scrollTo(0, 0);
  }
  function renderPage(animate) {
    var v = $('view'); if (!v || !S.me) return; var p = PAGES[S.route[0]] || PAGES.overview, h;
    try { h = p.render(); } catch (e) { console.error(e); h = html`<div class="card err">This page failed to render: ${e.message}</div>`; }
    v.innerHTML = '<div class="' + (animate ? 'page' : '') + '">' + h + '</div>'; if (p.after) p.after(); tick(); updateChrome();
  }
  function tick() { document.querySelectorAll('[data-since]').forEach(function (el) { el.textContent = U.clock(Date.now() - U.ms(el.getAttribute('data-since'))); }); }

  /* ======================= OVERVIEW ======================= */
  var OV = { entries: [], logs: [] };
  async function loadOverview() {
    var r = await Promise.all([db.list('earning_entries', monthRange(U.monthKey())), db.list('activity_log', { order: 'created_at.desc', limit: 15 }), db.list('work_sessions', { gte: { work_date: U.monthKey() + '-01' }, notnull: ['ended_at'] })]);
    OV.entries = r[0]; OV.logs = r[1]; OV.sessions = r[2];
  }
  function reqCard(r, withNote) {
    var e = S.names[r.employee_id] || {};
    return html`<div class="card flat tight" style="margin-bottom:10px"><div class="row nowrap">${ui.avatar(e.full_name || '?', true)}<div class="grow"><div class="bold">${e.full_name || 'Former employee'}</div><div class="muted small">${reqLabel(r)} · ${U.fmtTime(r.requested_at)} · ${U.ago(r.requested_at)}</div>${r.reason ? html`<div class="small" style="margin-top:4px">“${r.reason}”</div>` : ''}</div></div>
      ${withNote ? html`<input class="field" style="margin-top:10px" id="note-${r.id}" placeholder="Optional note to employee" maxlength="200">` : ''}
      <div class="row" style="margin-top:10px"><button class="btn good sm grow" data-act="decide" data-id="${r.id}" data-d="approved">${icon('check', 'sm')} Approve</button><button class="btn danger sm grow" data-act="decide" data-id="${r.id}" data-d="rejected">${icon('x', 'sm')} Reject</button></div></div>`;
  }
  function pageOverview() {
    var active = S.emps.filter(function (e) { return e.status === 'active'; });
    var bk = E.bucket(OV.entries), hrs = U.round2(U.sum(OV.sessions || [], function (s) { return s.hours; }));
    return html`${head('Overview', 'Your workforce at a glance', html`<button class="btn ghost sm" data-act="add-emp">${icon('plus', 'sm')} Add employee</button>`)}
      <div class="tiles four"><div class="tile"><div class="k">Active employees</div><div class="v">${active.length}</div><div class="muted tiny">${S.emps.length - active.length} suspended</div></div>
        <div class="tile accent"><div class="k">Working now</div><div class="v">${S.open.length}</div></div>
        <div class="tile"><div class="k">Pending requests</div><div class="v ${S.pending.length ? 'warn' : ''}">${S.pending.length}</div></div>
        <div class="tile"><div class="k">Unread messages</div><div class="v">${S.unread.length}</div></div></div>
      <div class="tiles three" style="margin-top:12px"><div class="tile"><div class="k">Net payroll</div><div class="v">${U.money(bk.net)}</div><div class="muted tiny">${U.monthLabel(U.monthKey())}</div></div>
        <div class="tile"><div class="k">Bonuses</div><div class="v good">${U.money(bk.bonus + bk.extra)}</div></div><div class="tile"><div class="k">Hours worked</div><div class="v">${U.fmtHours(hrs)}</div></div></div>
      <div class="cols2" style="margin-top:14px"><div class="card"><div class="row between"><h3>Pending requests</h3><a class="small" href="#/requests">View all</a></div>${S.pending.length ? S.pending.slice(0, 4).map(function (r) { return reqCard(r, false); }) : ui.empty('inbox', 'No pending requests.')}</div>
        <div class="card"><h3>Working now</h3>${S.open.length ? html`<div class="list">${S.open.map(function (s) { return html`<div class="item">${ui.avatar(empName(s.employee_id), true)}<div class="grow"><div class="bold">${empName(s.employee_id)}</div><div class="muted small">Since ${U.fmtTime(s.started_at)}</div></div><b data-since="${s.started_at}">00:00:00</b><button class="btn ghost sm" data-act="end-session" data-id="${s.id}">End</button></div>`; })}</div>` : ui.empty('coffee', 'Nobody is working right now.')}</div></div>
      <div class="card" style="margin-top:14px"><h3>Recent activity</h3>${OV.logs.length ? html`<div class="list">${OV.logs.map(function (l) { return html`<div class="item"><div class="grow"><div class="title">${l.action}</div><div class="muted small">${l.employee_id ? empName(l.employee_id) + ' · ' : ''}${l.details || ''}</div></div><div class="muted tiny">${U.ago(l.created_at)}</div></div>`; })}</div>` : ui.empty('activity', 'Activity will appear here.')}</div>`;
  }

  /* ======================= REQUESTS ======================= */
  var RQ = { hist: [] };
  async function loadRequests() { RQ.hist = (await db.list('work_requests', { order: 'requested_at.desc', limit: 80 })).filter(function (r) { return r.status !== 'pending'; }); }
  function pageRequests() {
    return html`${head('Requests', 'Approve or reject start, leave and day-off requests')}
      <div class="card"><h3>Pending (${S.pending.length})</h3>${S.pending.length ? S.pending.map(function (r) { return reqCard(r, true); }) : ui.empty('check', 'All caught up — no pending requests.')}</div>
      <div class="card" style="margin-top:14px"><h3>History</h3>${RQ.hist.length ? html`<div class="list">${RQ.hist.map(function (r) { return html`<div class="item"><div class="grow"><div class="title">${empName(r.employee_id)} · ${reqLabel(r)}</div><div class="muted small">${U.fmtDateTime(r.requested_at)}${r.reviewed_by ? ' · by ' + empName(r.reviewed_by) : ''}${r.review_note ? ' · “' + r.review_note + '”' : ''}</div></div><span class="pill ${r.status === 'approved' ? 'green' : 'red'}">${r.status}</span></div>`; })}</div>` : ui.empty('inbox', 'No decisions yet.')}</div>`;
  }

  /* ======================= EMPLOYEES ======================= */
  function pageEmployees() {
    if (S.route[1]) return pageDetail();
    var q = S.search.toLowerCase(), list = S.emps.filter(function (e) { return !q || (e.full_name + ' ' + (e.employee_code || '')).toLowerCase().indexOf(q) >= 0; });
    return html`${head('Employees', S.emps.length + ' total', html`<button class="btn sm" data-act="add-emp">${icon('plus', 'sm')} Add employee</button>`)}
      <input class="field" id="empSearch" data-change="emp-search" placeholder="Search name or ID…" value="${S.search}" autocomplete="off" style="margin-bottom:12px">
      <div class="card" id="empList">${empListHtml(list)}</div>`;
  }
  function empListHtml(list) {
    return list.length ? html`<div class="list">${list.map(function (e) { return html`<a class="item click" href="#/employees/${e.id}" style="text-decoration:none;color:inherit">${ui.badge(e.tier, 40)}<div class="grow"><div class="bold">${e.full_name}</div><div class="muted small">${e.employee_code} · ${U.money(e.monthly_base_salary)}/mo</div></div>${spill(e)}${icon('right', 'sm')}</a>`; })}</div>` : ui.empty('users', S.emps.length ? 'No match.' : 'No employees yet. Tap “Add employee” to create the first account.');
  }
  async function loadEmployee() {
    if (!S.route[1]) { S.det = null; return; }
    var id = S.route[1], emp = S.names[id]; if (!emp) { S.det = null; return; }
    var r = await Promise.all([E.loadBundle(id), db.list('activity_log', { eq: { employee_id: id }, order: 'created_at.desc', limit: 40 })]);
    S.det = { emp: emp, b: r[0], logs: r[1] }; S.detTab = S.route[2] || 'profile';
  }
  function pageDetail() {
    var d = S.det; if (!d) return html`<a class="back" href="#/employees">${icon('left', 'sm')} Employees</a>${ui.empty('users', 'Employee not found.')}`;
    var e = S.names[d.emp.id] || d.emp; d.emp = e;
    var tabs = [['profile', 'Profile'], ['pay', 'Pay'], ['attendance', 'Attendance'], ['rank', 'Rank'], ['activity', 'Activity']], t = S.detTab;
    var body = { profile: tabProfile, pay: tabPay, attendance: tabAttendance, rank: tabRank, activity: tabActivity }[t] || tabProfile;
    return html`<a class="back" href="#/employees">${icon('left', 'sm')} Employees</a>
      <div class="card"><div class="tierrow">${ui.badge(e.tier, 68)}<div class="grow"><h2>${e.full_name}</h2><div class="muted small">${e.employee_code} · ${e.tier} tier ${e.tier_override ? '(manual)' : ''}</div><div style="margin-top:6px">${spill(e)}</div></div><a class="iconbtn" href="#/messages/${e.id}" aria-label="Message">${icon('chat')}</a></div></div>
      <div class="seg" style="margin:14px 0">${tabs.map(function (x) { return html`<a class="${x[0] === t ? 'on' : ''}" href="#/employees/${e.id}/${x[0]}">${x[1]}</a>`; })}</div>
      ${body(d, e)}`;
  }
  function tabProfile(d, e) {
    var sm = E.summarize(d.b.entries, d.b.sessions, U.monthKey(), U.todayKey());
    return html`<div class="tiles three"><div class="tile"><div class="k">Net this month</div><div class="v">${U.money(sm.month.net)}</div></div><div class="tile"><div class="k">Hours</div><div class="v">${U.fmtHours(sm.month.hours)}</div></div><div class="tile"><div class="k">Total net</div><div class="v">${U.money(sm.total.net)}</div></div></div>
      <form class="card stack" style="margin-top:14px" data-form="edit-emp" data-id="${e.id}"><h3>Edit details</h3><div class="err hidden" data-err></div>
        <div class="form"><label class="lbl">Full name<input class="field" name="full_name" value="${e.full_name}" required></label><label class="lbl">Employee ID<input class="field" name="employee_code" value="${e.employee_code}" required autocapitalize="characters"></label>
        <label class="lbl">Phone<input class="field" name="phone" value="${e.phone || ''}" type="tel"></label><label class="lbl">Email (optional)<input class="field" name="email" value="${e.email || ''}" type="email"></label>
        <label class="lbl full">Monthly base salary (${EOS.config.currency})<input class="field" name="monthly_base_salary" type="number" min="0" step="0.01" value="${e.monthly_base_salary}" required></label></div>
        <button class="btn" type="submit">Save changes</button></form>
      <div class="card stack" style="margin-top:14px"><h3>Account</h3>
        <div class="row"><button class="btn ghost" data-act="reset-pw" data-id="${e.id}">${icon('lock', 'sm')} Reset password</button>
        ${e.status === 'active' ? html`<button class="btn ghost" data-act="suspend" data-id="${e.id}">Suspend</button>` : html`<button class="btn good" data-act="reactivate" data-id="${e.id}">Reactivate</button>`}
        <button class="btn danger" data-act="remove-emp" data-id="${e.id}">${icon('trash', 'sm')} Remove</button></div>
        <p class="muted small">Suspended employees cannot sign in. Removing permanently deletes their account and records.</p></div>`;
  }
  function tabPay(d, e) {
    var rules = S.rules, sm = E.summarize(d.b.entries, d.b.sessions, U.monthKey(), U.todayKey()), manual = d.b.entries.filter(function (x) { return x.entry_type !== 'daily'; }).slice(0, 50);
    return html`<div class="tiles three"><div class="tile"><div class="k">Daily rate</div><div class="v">${U.money(E.dailyRate(e.monthly_base_salary, rules))}</div><div class="muted tiny">${U.money(e.monthly_base_salary)} ÷ ${rules.pay.working_days}</div></div><div class="tile"><div class="k">Work pay (month)</div><div class="v">${U.money(sm.month.daily)}</div></div><div class="tile"><div class="k">Net (month)</div><div class="v">${U.money(sm.month.net)}</div></div></div>
      <form class="card stack" style="margin-top:14px" data-form="set-salary" data-id="${e.id}"><h3>Monthly salary</h3><div class="err hidden" data-err></div><div class="row nowrap"><input class="field grow" name="salary" type="number" min="0" step="0.01" value="${e.monthly_base_salary}" required><button class="btn" type="submit">Update</button></div><p class="muted small">Applies to future work days. Past days keep the rate they were paid at.</p></form>
      <form class="card stack" style="margin-top:14px" data-form="add-entry" data-id="${e.id}"><h3>Add bonus, extra earning or deduction</h3><div class="err hidden" data-err></div>
        <div class="form"><label class="lbl">Type<select class="field" name="type"><option value="bonus">Bonus / incentive</option><option value="extra">Extra earning</option><option value="deduction">Salary deduction</option></select></label><label class="lbl">Amount (${EOS.config.currency})<input class="field" name="amount" type="number" min="0.01" step="0.01" required></label>
        <label class="lbl">Reason<input class="field" name="description" maxlength="200" required></label><label class="lbl">Date<input class="field" name="date" type="date" value="${U.todayKey()}" required></label></div><button class="btn" type="submit">Add entry</button></form>
      <div class="card" style="margin-top:14px"><h3>Bonuses, extras &amp; deductions</h3>${manual.length ? html`<div class="list">${manual.map(function (x) { var neg = x.entry_type === 'deduction'; return html`<div class="item"><div class="grow"><div class="title">${{ extra: 'Extra earning', bonus: 'Bonus', deduction: 'Deduction' }[x.entry_type]}</div><div class="muted small">${U.fmtDate(x.entry_date)} · ${x.description || ''}</div></div><b class="${neg ? 'bad' : 'good'}">${neg ? '-' : '+'}${U.money(x.amount)}</b><button class="iconbtn" style="width:36px;height:36px" data-act="del-entry" data-id="${x.id}" aria-label="Delete entry">${icon('trash', 'sm')}</button></div>`; })}</div>` : ui.empty('wallet', 'No manual entries yet.')}</div>`;
  }
  function tabAttendance(d, e) {
    var sm = E.summarize(d.b.entries, d.b.sessions, U.monthKey(), U.todayKey()).month, open = d.b.sessions.filter(function (s) { return !s.ended_at; })[0];
    return html`<div class="tiles three"><div class="tile"><div class="k">Days (month)</div><div class="v">${sm.days}</div></div><div class="tile"><div class="k">Hours (month)</div><div class="v">${U.fmtHours(sm.hours)}</div></div><div class="tile"><div class="k">Status</div><div class="v" style="font-size:16px">${statusOf(e)[0]}</div></div></div>
      ${open ? html`<div class="notice row between" style="margin-top:12px"><span>Working since ${U.fmtTime(open.started_at)} · <b data-since="${open.started_at}">00:00:00</b></span><button class="btn ghost sm" data-act="end-session" data-id="${open.id}">End session</button></div>` : ''}
      <div class="card" style="margin-top:14px"><h3>Sessions</h3>${d.b.sessions.length ? html`<div class="list">${d.b.sessions.slice(0, 60).map(function (s) { return html`<div class="item"><div class="grow"><div class="title">${U.fmtDate(s.work_date, true)}</div><div class="muted small">${U.fmtTime(s.started_at)} → ${s.ended_at ? U.fmtTime(s.ended_at) : 'in progress'}</div></div><b>${s.ended_at ? U.fmtHours(s.hours) : 'Live'}</b></div>`; })}</div>` : ui.empty('clock', 'No sessions yet.')}</div>
      <div class="card" style="margin-top:14px"><h3>Leave &amp; day-off requests</h3>${d.b.requests.filter(function (r) { return r.request_type !== 'start'; }).length ? html`<div class="list">${d.b.requests.filter(function (r) { return r.request_type !== 'start'; }).slice(0, 30).map(function (r) { return html`<div class="item"><div class="grow"><div class="title">${reqLabel(r)}</div><div class="muted small">${U.fmtDateTime(r.requested_at)}${r.reason ? ' · ' + r.reason : ''}</div></div><span class="pill ${{ pending: 'gold', approved: 'green', rejected: 'red' }[r.status]}">${r.status}</span></div>`; })}</div>` : ui.empty('calendar', 'None.')}</div>`;
  }
  function tabRank(d, e) {
    var since = Date.now() - S.rules.tiers.window_days * 86400000, win = U.sum(d.b.ledger.filter(function (l) { return U.ms(l.created_at) >= since; }), function (l) { return l.points; }), all = U.sum(d.b.ledger, function (l) { return l.points; }), lv = E.level(all), tp = E.tierProgress(win, e.tier, S.rules);
    return html`<div class="tiles three"><div class="tile"><div class="k">Points (${S.rules.tiers.window_days}d)</div><div class="v">${U.num(win)}</div></div><div class="tile"><div class="k">XP</div><div class="v">${U.num(all)}</div><div class="muted tiny">Level ${lv.level}</div></div><div class="tile"><div class="k">Next tier</div><div class="v" style="font-size:16px">${tp.next ? tp.next + ' (' + U.num(tp.remaining) + ' to go)' : 'Max'}</div></div></div>
      <form class="card stack" style="margin-top:14px" data-form="set-tier" data-id="${e.id}"><h3>Change tier</h3><div class="err hidden" data-err></div>
        <div class="form"><label class="lbl">Tier<select class="field" name="tier"><option value="auto" ${e.tier_override ? '' : 'selected'}>Automatic (by points)</option>${E.TIERS.map(function (t) { return html`<option value="${t}" ${e.tier_override === t ? 'selected' : ''}>${t} (manual)</option>`; })}</select></label><label class="lbl">Reason<input class="field" name="reason" maxlength="200" placeholder="Shown in ranking history"></label></div><button class="btn" type="submit">Apply tier</button></form>
      <form class="card stack" style="margin-top:14px" data-form="adj-points" data-id="${e.id}"><h3>Adjust points</h3><div class="err hidden" data-err></div>
        <div class="form"><label class="lbl">Points (+ or −)<input class="field" name="delta" type="number" step="1" required placeholder="e.g. 50 or -30"></label><label class="lbl">Reason<input class="field" name="reason" maxlength="200" required></label></div><button class="btn" type="submit">Apply</button></form>
      <div class="cols2" style="margin-top:14px"><div class="card"><h3>Points ledger</h3>${d.b.ledger.length ? html`<div class="list">${d.b.ledger.slice(0, 25).map(function (l) { return html`<div class="item"><div class="grow"><div class="title ${l.points < 0 ? 'bad' : ''}">${l.points > 0 ? '+' : ''}${l.points}</div><div class="muted small">${l.reason} · ${l.source}</div></div><span class="muted tiny">${U.fmtDate(l.created_at)}</span></div>`; })}</div>` : ui.empty('star', 'No points yet.')}</div>
        <div class="card"><h3>Ranking history</h3>${d.b.tiers.length ? html`<div class="list">${d.b.tiers.map(function (t) { return html`<div class="item"><div class="grow"><div class="title">${t.old_tier || '—'} → ${t.new_tier}</div><div class="muted small">${t.manual ? 'Manual · ' : ''}${t.reason}${Number(t.bonus) > 0 ? ' · bonus ' + U.money(t.bonus) : ''}</div></div><span class="muted tiny">${U.fmtDate(t.created_at)}</span></div>`; })}</div>` : ui.empty('trophy', 'No tier changes yet.')}</div></div>`;
  }
  function tabActivity(d) {
    var tl = E.buildTimeline(Object.assign({}, d.b, { logs: d.logs }), Object.keys(S.names).reduce(function (o, k) { o[k] = S.names[k].full_name; return o; }, {})).slice(0, 80);
    return html`<div class="card"><h3>Activity timeline</h3>${tl.length ? html`<div class="list">${tl.map(function (x) { return html`<div class="item"><div class="grow small">${x.text}</div><div class="muted tiny" style="white-space:nowrap">${U.fmtDateTime(x.at)}</div></div>`; })}</div>` : ui.empty('activity', 'No activity yet.')}</div>`;
  }
  async function reloadDetail() { await refreshCore(); await loadEmployee(); renderPage(false); }

  /* ======================= PAYROLL ======================= */
  var PR = { entries: [], sessions: [] };
  async function loadPayroll() { PR.entries = await db.list('earning_entries', monthRange(S.month)); }
  function payrollRows() {
    return S.emps.map(function (e) { var b = E.bucket(PR.entries.filter(function (x) { return x.employee_id === e.id; })); return { e: e, b: b }; });
  }
  function pagePayroll() {
    var rows = payrollRows(), tot = E.bucket(PR.entries);
    return html`${head('Payroll', 'Salary, bonuses and deductions by month', html`<button class="btn ghost sm" data-act="export-pay">${icon('download', 'sm')} CSV</button><button class="btn sm" data-act="add-entry-modal">${icon('plus', 'sm')} Add entry</button>`)}${monthNav(S.month)}
      <div class="tiles four"><div class="tile accent"><div class="k">Net payroll</div><div class="v">${U.money(tot.net)}</div></div><div class="tile"><div class="k">Work pay</div><div class="v">${U.money(tot.daily)}</div></div><div class="tile"><div class="k">Extra + bonus</div><div class="v good">${U.money(tot.extra + tot.bonus)}</div></div><div class="tile"><div class="k">Deductions</div><div class="v bad">${U.money(tot.deduction)}</div></div></div>
      <div class="card" style="margin-top:14px"><div class="tablewrap"><table class="t"><thead><tr><th>Employee</th><th class="num">Base</th><th class="num">Work pay</th><th class="num">Extra</th><th class="num">Bonus</th><th class="num">Deduct.</th><th class="num">Net</th></tr></thead><tbody>
        ${rows.length ? rows.map(function (r) { return html`<tr class="click" data-act="go-emp-pay" data-id="${r.e.id}"><td><b>${r.e.full_name}</b><div class="muted tiny">${r.e.employee_code}</div></td><td class="num">${U.money(r.e.monthly_base_salary)}</td><td class="num">${U.money(r.b.daily)}</td><td class="num">${U.money(r.b.extra)}</td><td class="num good">${U.money(r.b.bonus)}</td><td class="num bad">${U.money(r.b.deduction)}</td><td class="num"><b>${U.money(r.b.net)}</b></td></tr>`; }) : html`<tr><td colspan="7">${ui.empty('wallet', 'No employees yet.')}</td></tr>`}</tbody></table></div></div>
      <p class="muted small" style="margin-top:10px">Work pay = base ÷ ${S.rules.pay.working_days} working days × (hours ÷ ${S.rules.pay.standard_hours}h, max 1) for each completed day. Change these in Settings.</p>`;
  }

  /* ======================= ATTENDANCE ======================= */
  var AT = { sessions: [], off: [] };
  function attBounds() {
    var t = U.todayKey();
    if (S.attRange === 'today') return [t, t];
    if (S.attRange === 'week') return [U.dateKey(U.startOfWeek()), t];
    return [U.monthKey() + '-01', t];
  }
  async function loadAttendance() {
    var b = attBounds();
    var r = await Promise.all([db.list('work_sessions', { gte: { work_date: b[0] }, lte: { work_date: b[1] }, order: 'started_at.desc', limit: 500 }), db.list('work_requests', { eq: { request_type: 'dayoff', status: 'approved' }, gte: { request_date: b[0] }, lte: { request_date: b[1] } })]);
    AT.sessions = r[0]; AT.off = r[1];
  }
  function pageAttendance() {
    var by = U.groupBy(AT.sessions.filter(function (s) { return s.ended_at; }), function (s) { return s.employee_id; });
    return html`${head('Attendance', 'Working hours and leave')}
      <div class="seg"><button class="${S.attRange === 'today' ? 'on' : ''}" data-act="att-range" data-r="today">Today</button><button class="${S.attRange === 'week' ? 'on' : ''}" data-act="att-range" data-r="week">This week</button><button class="${S.attRange === 'month' ? 'on' : ''}" data-act="att-range" data-r="month">This month</button></div>
      <div class="card" style="margin-top:14px"><h3>Hours by employee</h3>${S.emps.length ? html`<div class="list">${S.emps.map(function (e) { var ss = by[e.id] || []; var days = Object.keys(U.groupBy(ss, function (s) { return s.work_date; })).length; return html`<div class="item click" data-act="go-emp-att" data-id="${e.id}">${ui.avatar(e.full_name, true)}<div class="grow"><div class="bold">${e.full_name}</div><div class="muted small">${days} day(s) worked · ${AT.off.filter(function (o) { return o.employee_id === e.id; }).length} leave day(s)</div></div><b>${U.fmtHours(U.sum(ss, function (s) { return s.hours; }))}</b></div>`; })}</div>` : ui.empty('users', 'No employees.')}</div>
      <div class="card" style="margin-top:14px"><h3>All sessions</h3>${AT.sessions.length ? html`<div class="tablewrap"><table class="t"><thead><tr><th>Employee</th><th>Date</th><th>Start</th><th>End</th><th class="num">Hours</th></tr></thead><tbody>${AT.sessions.map(function (s) { return html`<tr><td>${empName(s.employee_id)}</td><td>${U.fmtDate(s.work_date)}</td><td>${U.fmtTime(s.started_at)}</td><td>${s.ended_at ? U.fmtTime(s.ended_at) : html`<span class="pill green">live</span>`}</td><td class="num">${s.ended_at ? U.fmtHours(s.hours) : '—'}</td></tr>`; })}</tbody></table></div>` : ui.empty('clock', 'No sessions in this range.')}</div>`;
  }

  /* ======================= RANKINGS ======================= */
  var RK = { hist: [] };
  async function loadRanks() {
    var r = await Promise.all([E.leaderboard(S.lbPeriod), db.list('tier_history', { order: 'created_at.desc', limit: 40 })]);
    S.lb = r[0]; RK.hist = r[1];
  }
  function pageRanks() {
    var rows = S.lb || [], prevMonth = U.addMonths(U.monthKey(), -1);
    return html`${head('Rankings', 'Leaderboards, tiers and rewards')}
      <div class="seg">${['daily', 'weekly', 'monthly', 'all'].map(function (k) { return html`<button class="${k === S.lbPeriod ? 'on' : ''}" data-act="lb-period" data-p="${k}">${{ daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', all: 'All-time' }[k]}</button>`; })}</div>
      <div class="card" style="margin-top:14px">${rows.length ? rows.map(function (r) { var e = S.names[r.employee_id] || {}; return html`<a class="lb r${r.rank}" href="#/employees/${r.employee_id}/rank" style="text-decoration:none;color:inherit"><div class="rk">${r.rank}</div>${ui.badge(r.tier, 36)}<div class="grow"><div class="bold">${r.full_name}</div><div class="muted tiny">${r.employee_code} · ${r.tier}${e.tier_override ? ' (manual)' : ''}</div></div><div class="pts">${U.num(r.points)}</div></a>`; }) : ui.empty('trophy', 'No employees to rank yet.')}</div>
      <div class="card stack" style="margin-top:14px"><h3>Tier &amp; reward actions</h3>
        <div class="row"><button class="btn" data-act="recalc">${icon('refresh', 'sm')} Recalculate tiers now</button></div>
        <div class="row nowrap"><input class="field grow" type="month" id="rewardMonth" value="${prevMonth}" max="${U.monthKey()}"><button class="btn ghost" data-act="award-month">Award monthly rewards</button></div>
        <p class="muted small">Top ${S.rules.rewards.monthly_top.length} of the chosen month receive ${S.rules.rewards.monthly_top.map(function (x) { return U.money(x); }).join(' / ')} as a bonus. Each place is paid once per month. Tiers are recalculated automatically after every approved session and whenever you open this console.</p></div>
      <div class="card" style="margin-top:14px"><h3>Ranking history</h3>${RK.hist.length ? html`<div class="list">${RK.hist.map(function (t) { return html`<div class="item"><div class="grow"><div class="title">${empName(t.employee_id)}: ${t.old_tier || '—'} → ${t.new_tier}</div><div class="muted small">${t.manual ? 'Manual · ' : ''}${t.reason}${Number(t.bonus) > 0 ? ' · bonus ' + U.money(t.bonus) : ''}</div></div><span class="muted tiny">${U.fmtDate(t.created_at)}</span></div>`; })}</div>` : ui.empty('trophy', 'No tier changes yet.')}</div>`;
  }

  /* ======================= RESOURCES ======================= */
  var RS = { list: [] };
  async function loadRes() { RS.list = await db.list('resources', { order: 'created_at.desc' }); }
  function pageResources() {
    return html`${head('Resources', 'Share videos, images, PDFs, documents and instructions')}
      <form class="card stack" data-form="add-res"><h3>Publish a resource</h3><div class="err hidden" data-err></div>
        <div class="form"><label class="lbl">Title<input class="field" name="title" maxlength="120" required></label><label class="lbl">Type<select class="field" name="type"><option value="file">Upload a file (video / image / PDF / document)</option><option value="note">Text note</option><option value="instruction">Work instruction (text)</option></select></label>
        <label class="lbl full">Description<input class="field" name="description" maxlength="400" placeholder="Short summary employees will see"></label>
        <label class="lbl full">Text (for notes &amp; instructions)<textarea class="field" name="body" maxlength="20000"></textarea></label>
        <label class="lbl full">File (max ${U.fmtSize(db.files.max)})<input class="field" name="file" type="file" accept="video/*,image/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv"></label></div>
        <button class="btn" type="submit">${icon('plus', 'sm')} Publish</button></form>
      <div class="card" style="margin-top:14px"><h3>Published (${RS.list.length})</h3>${RS.list.length ? RS.list.map(function (r) { return html`<div class="res"><div class="rico">${icon(ui.fileIcon(r.resource_type))}</div><div class="grow"><div class="bold">${r.title}</div><div class="muted small">${r.resource_type.toUpperCase()} · ${U.fmtDate(r.created_at)}${r.file_name ? ' · ' + r.file_name : ''}</div></div><button class="iconbtn" data-act="view-res" data-id="${r.id}" aria-label="View">${icon('eye')}</button><button class="iconbtn" data-act="del-res" data-id="${r.id}" aria-label="Delete">${icon('trash')}</button></div>`; }) : ui.empty('book', 'Nothing published yet.')}</div>`;
  }

  /* ======================= MESSAGES ======================= */
  async function loadMessages() {
    var id = S.route[1], all = await db.list('messages', { order: 'created_at.desc', limit: 800 }), th = {};
    all.forEach(function (m) { var t = th[m.employee_id] || (th[m.employee_id] = { last: m, unread: 0 }); if (m.sender_role === 'employee' && !m.read_at) t.unread++; });
    S.chat.threads = th;
    if (id === 'announcements') S.chat.anns = await db.list('announcements', { order: 'created_at.desc', limit: 30 });
    else if (id && S.names[id]) {
      S.chat.msgs = all.filter(function (m) { return m.employee_id === id; }).reverse();
      await C.resolveUrls(S.chat.msgs);
      if (S.chat.msgs.some(function (m) { return m.sender_role === 'employee' && !m.read_at; })) { await E.markRead(id); S.chat.msgs.forEach(function (m) { if (m.sender_role === 'employee') m.read_at = m.read_at || new Date().toISOString(); }); th[id].unread = 0; await refreshCore(); }
    }
    S.chat.file = null;
  }
  function convoList() {
    var id = S.route[1], th = S.chat.threads;
    var list = S.emps.slice().sort(function (a, b) { var x = th[a.id], y = th[b.id]; return (y ? U.ms(y.last.created_at) : 0) - (x ? U.ms(x.last.created_at) : 0) || a.full_name.localeCompare(b.full_name); });
    return html`<a class="convo ${id === 'announcements' ? 'on' : ''}" href="#/messages/announcements" style="text-decoration:none"><div class="avatar" style="background:linear-gradient(145deg,#f6c96b,#b77a24)">${icon('mega')}</div><div class="grow"><div class="bold">Team announcements</div><div class="last">Broadcast to all employees</div></div></a>
      ${list.map(function (e) { var t = th[e.id], last = t ? (t.last.body || (t.last.attachment_name ? '📎 ' + t.last.attachment_name : '')) : 'No messages yet'; return html`<a class="convo ${id === e.id ? 'on' : ''}" href="#/messages/${e.id}" style="text-decoration:none">${ui.avatar(e.full_name)}<div class="grow"><div class="bold">${e.full_name}</div><div class="last">${t && t.last.sender_role === 'admin' ? 'You: ' : ''}${last}</div></div>${t && t.unread ? html`<span class="unread"></span>` : ''}</a>`; })}`;
  }
  function pageMessages() {
    var id = S.route[1], emp = id && S.names[id];
    var pane;
    if (id === 'announcements') {
      pane = html`<div class="stack"><a class="back" href="#/messages" style="display:inline-flex">${icon('left', 'sm')} Conversations</a>
        <form class="card stack" data-form="post-ann"><h3>${icon('mega', 'sm')} New announcement</h3><div class="err hidden" data-err></div><label class="lbl">Title<input class="field" name="title" maxlength="120" required></label><label class="lbl">Message<textarea class="field" name="body" maxlength="4000" required></textarea></label><label class="lbl">Attachment (optional)<input class="field" name="file" type="file"></label><button class="btn" type="submit">Send to all employees</button></form>
        ${S.chat.anns.map(function (a) { return html`<div class="card"><div class="row between"><h3>${a.title}</h3><span class="muted tiny">${U.fmtDateTime(a.created_at)}</span></div><p class="muted" style="white-space:pre-wrap">${a.body}</p><div class="row" style="margin-top:8px">${a.attachment_path ? html`<button class="btn ghost sm" data-act="view-ann" data-path="${a.attachment_path}" data-name="${a.attachment_name}" data-type="${a.attachment_type || ''}">${icon('clip', 'sm')} ${a.attachment_name}</button>` : ''}<button class="btn danger sm" data-act="del-ann" data-id="${a.id}">Delete</button></div></div>`; })}</div>`;
    } else if (emp) {
      pane = html`<div class="chat card flat tight"><div class="row nowrap" style="padding:4px 4px 10px;border-bottom:1px solid var(--line2)"><a class="iconbtn" href="#/messages" aria-label="Back" style="width:36px;height:36px">${icon('left', 'sm')}</a>${ui.avatar(emp.full_name, true)}<a class="grow bold" href="#/employees/${emp.id}" style="color:inherit;text-decoration:none">${emp.full_name}</a></div>
        <div class="msgs" id="msgs">${C.msgList(S.chat.msgs, 'admin')}</div><div id="pendingFile">${pendingHtml()}</div>
        <form class="composer" data-form="chat-send" autocomplete="off"><label class="iconbtn" style="cursor:pointer" aria-label="Attach">${icon('clip')}<input type="file" id="chatFile" data-change="chat-file" class="hidden" accept="image/*,video/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv"></label><textarea class="field grow" id="chatInput" name="body" rows="1" maxlength="2000" placeholder="Message ${emp.full_name.split(' ')[0]}…" enterkeyhint="send"></textarea><button class="btn round" type="submit" aria-label="Send">${icon('send')}</button></form></div>`;
    } else pane = html`<div class="card hide-d">${ui.empty('chat', 'Select a conversation')}</div>`;
    var showPane = id && (id === 'announcements' || emp);
    return html`${head('Messages', 'Chat with employees and send announcements')}<div class="admin-chat"><div class="side ${showPane ? 'hide-m' : ''}"><div class="card tight" id="convos" style="padding:6px">${convoList()}</div></div><div class="pane ${showPane ? '' : 'hide-m'}">${pane}</div></div>`;
  }
  function pendingHtml() { var f = S.chat.file; return f ? html`<div class="pending-file">${icon('clip', 'sm')}<span class="grow" style="overflow:hidden;text-overflow:ellipsis">${f.name} · ${U.fmtSize(f.size)}</span><button type="button" class="iconbtn" style="width:32px;height:32px" data-act="chat-clear-file" aria-label="Remove">${icon('x', 'sm')}</button></div>` : ''; }
  function afterMessages() { var m = $('msgs'); if (m) m.scrollTop = m.scrollHeight; }
  async function refreshMessages() {
    var id = S.route[1]; await loadMessagesQuiet();
    var c = $('convos'); if (c) c.innerHTML = String(convoList());
    var box = $('msgs'); if (box && id && S.names[id]) {
      var sig = S.chat.msgs.length + ':' + S.chat.msgs.map(function (m) { return m.read_at ? 1 : 0; }).join('');
      if (sig !== S.lastSig) { S.lastSig = sig; var near = box.scrollHeight - box.scrollTop - box.clientHeight < 140; box.innerHTML = String(C.msgList(S.chat.msgs, 'admin')); if (near) box.scrollTop = box.scrollHeight; }
    }
    updateChrome();
  }
  async function loadMessagesQuiet() { var f = S.chat.file; await loadMessages(); S.chat.file = f; }
  document.addEventListener('keydown', function (e) {
    if (e.target && e.target.id === 'chatInput' && e.key === 'Enter' && !e.shiftKey && !/iPhone|iPad|Android/i.test(navigator.userAgent)) { e.preventDefault(); var f = e.target.form; if (f.requestSubmit) f.requestSubmit(); else f.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true })); }
  });
  document.addEventListener('input', function (e) { if (e.target && e.target.id === 'chatInput') { e.target.style.height = 'auto'; e.target.style.height = Math.min(120, e.target.scrollHeight) + 'px'; } });

  /* ======================= SETTINGS / MORE ======================= */
  function pageMore() {
    var rows = NAV.filter(function (n) { return ['overview', 'requests', 'employees', 'messages'].indexOf(n[0]) < 0; });
    return html`${head('More')}<div class="card"><div class="list">${rows.map(function (r) { return html`<a class="item click" href="#/${r[0]}" style="text-decoration:none;color:inherit"><div class="rico res" style="width:46px;height:46px;padding:0;border:0;background:transparent"><div class="rico">${icon(r[2])}</div></div><div class="grow title">${r[1]}</div>${icon('right', 'sm')}</a>`; })}<div class="item click" data-act="logout"><div class="rico res" style="width:46px;height:46px;padding:0;border:0;background:transparent"><div class="rico" style="color:var(--red)">${icon('logout')}</div></div><div class="grow title">Sign out</div></div></div></div>`;
  }
  function num(name, label, v, step, min) { return html`<label class="lbl">${label}<input class="field" name="${name}" type="number" step="${step || 1}" min="${min == null ? 0 : min}" value="${v}" required></label>`; }
  function pageSettings() {
    var r = S.rules, t = r.tiers.thresholds, b = r.rewards.promotion_bonus, m = r.rewards.monthly_top;
    return html`${head('Settings', 'Pay, points, tiers and rewards — fully configurable')}
      <form class="card stack" data-form="rules"><h3>Pay rules</h3><div class="err hidden" data-err></div>
        <div class="form">${num('working_days', 'Working days per month', r.pay.working_days)}${num('standard_hours', 'Standard hours per day', r.pay.standard_hours, 0.5, 1)}</div>
        <h3 style="margin-top:6px">Points</h3><div class="form">${num('per_hour', 'Points per hour worked', r.points.per_hour, 0.5)}${num('attendance_day', 'Attendance points per day', r.points.attendance_day)}${num('min_hours', 'Min hours for attendance day', r.points.min_hours_for_attendance, 0.5)}</div>
        <h3 style="margin-top:6px">Tiers (promotion &amp; demotion)</h3><p class="muted small">An employee's tier is the highest tier whose threshold is at or below the points earned in the rolling window below.</p>
        <div class="form">${num('window_days', 'Rolling window (days)', r.tiers.window_days, 1, 1)}<span></span>${num('t_Silver', 'Silver at (points)', t.Silver, 1, 1)}${num('t_Gold', 'Gold at', t.Gold, 1, 1)}${num('t_Platinum', 'Platinum at', t.Platinum, 1, 1)}${num('t_Diamond', 'Diamond at', t.Diamond, 1, 1)}</div>
        <h3 style="margin-top:6px">Rewards</h3><p class="muted small">Promotion bonus is paid once per tier per employee. Monthly rewards go to the top 3 by points.</p>
        <div class="form">${num('b_Silver', 'Silver promotion bonus', b.Silver, 0.01)}${num('b_Gold', 'Gold promotion bonus', b.Gold, 0.01)}${num('b_Platinum', 'Platinum promotion bonus', b.Platinum, 0.01)}${num('b_Diamond', 'Diamond promotion bonus', b.Diamond, 0.01)}${num('m1', 'Monthly #1 reward', m[0] || 0, 0.01)}${num('m2', 'Monthly #2 reward', m[1] || 0, 0.01)}${num('m3', 'Monthly #3 reward', m[2] || 0, 0.01)}</div>
        <button class="btn" type="submit">Save rules</button></form>
      <form class="card stack" style="margin-top:14px" data-form="admin-pw"><h3>Change my password</h3><div class="err hidden" data-err></div><label class="lbl">New password<input class="field" name="pw1" type="password" minlength="8" autocomplete="new-password" required></label><label class="lbl">Confirm<input class="field" name="pw2" type="password" minlength="8" autocomplete="new-password" required></label><button class="btn" type="submit">Update password</button></form>
      ${db.mode === 'local' ? html`<div class="card stack" style="margin-top:14px"><h3>Preview tools</h3><p class="muted small">Preview mode only. Sample data is created through the real pay/points engine, with random passwords shown once.</p><div class="row"><button class="btn ghost" data-act="seed">Load 4 sample employees</button><button class="btn danger" data-act="reset-preview">Erase all preview data</button></div></div>` : html`<div class="card" style="margin-top:14px"><h3>Backend</h3><p class="muted small">Connected to Supabase · ${EOS.config.supabaseUrl}</p></div>`}
      <button class="btn danger block" style="margin-top:14px" data-act="logout">${icon('logout')} Sign out</button>`;
  }
  function rulesFrom(v) {
    var n = function (k) { return Number(v[k]); };
    return { pay: { working_days: n('working_days'), standard_hours: n('standard_hours') }, points: { per_hour: n('per_hour'), attendance_day: n('attendance_day'), min_hours_for_attendance: n('min_hours') },
      tiers: { window_days: n('window_days'), thresholds: { Bronze: 0, Silver: n('t_Silver'), Gold: n('t_Gold'), Platinum: n('t_Platinum'), Diamond: n('t_Diamond') } },
      rewards: { promotion_bonus: { Silver: n('b_Silver'), Gold: n('b_Gold'), Platinum: n('b_Platinum'), Diamond: n('b_Diamond') }, monthly_top: [n('m1'), n('m2'), n('m3')] } };
  }

  /* ======================= actions ======================= */
  function addEmpModal() {
    var next = 'EMP' + String(S.emps.length + 1).padStart(3, '0');
    ui.modal({ title: 'Add employee', body: html`<form class="stack" data-form="add-emp"><div class="err hidden" data-err></div>
      <div class="form"><label class="lbl">Full name<input class="field" name="full_name" required autocomplete="off"></label><label class="lbl">Employee ID<input class="field" name="employee_code" value="${next}" required autocapitalize="characters" autocomplete="off"></label>
      <label class="lbl full">Password<span class="row nowrap"><input class="field grow" id="newPw" name="password" value="${genPw()}" required minlength="8" autocomplete="off"><button type="button" class="btn ghost" data-act="gen-pw">Generate</button></span></label>
      <label class="lbl">Monthly salary (${EOS.config.currency})<input class="field" name="monthly_base_salary" type="number" min="0" step="0.01" value="0" required></label><label class="lbl">Phone<input class="field" name="phone" type="tel"></label>
      <label class="lbl full">Email (optional)<input class="field" name="email" type="email"></label></div><button class="btn block" type="submit">Create account</button></form>` });
  }
  function findReq(id) { return S.pending.filter(function (r) { return r.id === id; })[0]; }
  ui.register({
    togglepw: function () { var i = $('loginPw'); i.type = i.type === 'password' ? 'text' : 'password'; },
    logout: async function () { await logout(); },
    'add-emp': addEmpModal,
    'gen-pw': function () { $('newPw').value = genPw(); },
    'copy-creds': async function (el) { var ok = await C.copy(el.getAttribute('data-text')); ui.toast(ok ? 'Copied ✓' : 'Copy failed — select the text manually', ok ? 'ok' : 'err'); },
    decide: async function (el) {
      var r = findReq(el.getAttribute('data-id')); if (!r) { await refreshCore(); renderPage(false); throw new Error('This request was already handled.'); }
      var note = ($('note-' + r.id) || {}).value;
      await E.decideRequest(r, el.getAttribute('data-d'), note); ui.ok('Request ' + el.getAttribute('data-d') + ' ✓'); await refreshCore(); if (PAGES[S.route[0]].load) await PAGES[S.route[0]].load(); renderPage(false);
    },
    'end-session': async function (el) {
      var s = S.open.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; if (!s) return;
      var ok = await ui.confirm({ title: 'End work session?', body: empName(s.employee_id) + '’s session will end now and pay & points will be calculated.', ok: 'End session' }); if (!ok) return;
      await E.endSessionNow(s); ui.ok('Session ended ✓'); await refreshCore(); if (S.route[0] === 'employees' && S.route[1]) await loadEmployee(); else if (PAGES[S.route[0]].load) await PAGES[S.route[0]].load(); renderPage(false);
    },
    'month-nav': async function (el) { S.month = U.addMonths(S.month, Number(el.getAttribute('data-n'))); await loadPayroll(); renderPage(false); },
    'go-emp-pay': function (el) { ui.go('employees/' + el.getAttribute('data-id') + '/pay'); },
    'go-emp-att': function (el) { ui.go('employees/' + el.getAttribute('data-id') + '/attendance'); },
    'att-range': async function (el) { S.attRange = el.getAttribute('data-r'); await loadAttendance(); renderPage(false); },
    'lb-period': async function (el) { S.lbPeriod = el.getAttribute('data-p'); await loadRanks(); renderPage(false); },
    recalc: async function () { var ch = await maybeRecalc(true); await loadRanks(); renderPage(false); ui.ok(ch.length ? ch.length + ' tier change(s): ' + ch.map(function (c) { return c.name + ' → ' + c.to; }).join(', ') : 'All tiers are up to date ✓'); },
    'award-month': async function () {
      var mk = $('rewardMonth').value || U.addMonths(U.monthKey(), -1);
      var ok = await ui.confirm({ title: 'Award rewards for ' + U.monthLabel(mk) + '?', body: 'Bonus entries are added to the top performers. Each place can only be paid once per month.', ok: 'Award' }); if (!ok) return;
      var a = await E.awardMonthlyRewards(mk); await loadRanks(); renderPage(false);
      ui.ok(a.length ? 'Awarded: ' + a.map(function (x) { return '#' + x.place + ' ' + x.name + ' ' + U.money(x.amount); }).join(', ') : 'Nothing to award (already paid, or no points that month).');
    },
    'export-pay': function () {
      var rows = [['Employee ID', 'Name', 'Base salary', 'Work pay', 'Extra', 'Bonus', 'Deductions', 'Net']].concat(payrollRows().map(function (r) { return [r.e.employee_code, r.e.full_name, r.e.monthly_base_salary, r.b.daily, r.b.extra, r.b.bonus, r.b.deduction, r.b.net]; }));
      U.download('payroll-' + S.month + '.csv', U.csv(rows));
    },
    'add-entry-modal': function () {
      ui.modal({ title: 'Add pay entry', body: html`<form class="stack" data-form="add-entry-any"><div class="err hidden" data-err></div><div class="form"><label class="lbl full">Employee<select class="field" name="emp" required>${S.emps.map(function (e) { return html`<option value="${e.id}">${e.full_name} (${e.employee_code})</option>`; })}</select></label>
        <label class="lbl">Type<select class="field" name="type"><option value="bonus">Bonus / incentive</option><option value="extra">Extra earning</option><option value="deduction">Salary deduction</option></select></label><label class="lbl">Amount<input class="field" name="amount" type="number" min="0.01" step="0.01" required></label>
        <label class="lbl">Reason<input class="field" name="description" maxlength="200" required></label><label class="lbl">Date<input class="field" name="date" type="date" value="${U.todayKey()}" required></label></div><button class="btn block" type="submit">Add entry</button></form>` });
    },
    'del-entry': async function (el) {
      var x = S.det.b.entries.filter(function (e) { return e.id === el.getAttribute('data-id'); })[0]; if (!x) return;
      if (!(await ui.confirm({ title: 'Delete this entry?', body: x.entry_type + ' ' + U.money(x.amount) + ' — ' + (x.description || ''), ok: 'Delete', danger: true }))) return;
      await E.deleteEntry(x); ui.ok('Entry removed'); await reloadDetail();
    },
    'reset-pw': function (el) {
      var id = el.getAttribute('data-id');
      ui.modal({ title: 'Reset password', body: html`<form class="stack" data-form="reset-pw" data-id="${id}"><div class="err hidden" data-err></div><label class="lbl">New password<span class="row nowrap"><input class="field grow" id="newPw" name="password" value="${genPw()}" minlength="8" required autocomplete="off"><button type="button" class="btn ghost" data-act="gen-pw">Generate</button></span></label><button class="btn block" type="submit">Set password</button></form>` });
    },
    suspend: async function (el) {
      var id = el.getAttribute('data-id'), e = S.names[id];
      if (!(await ui.confirm({ title: 'Suspend ' + e.full_name + '?', body: 'They will be signed out and unable to log in. Any active session is ended now.', ok: 'Suspend', danger: true }))) return;
      var open = S.open.filter(function (s) { return s.employee_id === id; })[0]; if (open) await E.endSessionNow(open);
      await db.admin.updateEmployee(id, { status: 'suspended' }); await E.log(id, 'Account suspended', ''); ui.ok('Suspended'); await reloadDetail();
    },
    reactivate: async function (el) { var id = el.getAttribute('data-id'); await db.admin.updateEmployee(id, { status: 'active' }); await E.log(id, 'Account reactivated', ''); ui.ok('Reactivated ✓'); await reloadDetail(); },
    'remove-emp': async function (el) {
      var id = el.getAttribute('data-id'), e = S.names[id];
      if (!(await ui.confirm({ title: 'Remove ' + e.full_name + '?', body: 'This permanently deletes the account and all earnings, attendance, points and chat history. This cannot be undone. Consider Suspend instead.', ok: 'Delete permanently', danger: true }))) return;
      await db.admin.deleteEmployee(id); await refreshCore(); ui.ok('Employee removed'); ui.go('employees');
    },
    'view-res': async function (el) { var r = RS.list.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; if (!r) return; if (r.storage_path) return ui.viewFile('resources', r.storage_path, r.file_name, r.mime_type, r.title); ui.modal({ title: r.title, wide: true, body: html`<div class="viewer"><pre>${r.body || ''}</pre></div>` }); },
    'del-res': async function (el) { var r = RS.list.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; if (!r) return; if (!(await ui.confirm({ title: 'Delete “' + r.title + '”?', body: 'Employees will no longer see it.', ok: 'Delete', danger: true }))) return; await E.removeResource(r); await loadRes(); renderPage(false); ui.ok('Deleted'); },
    'view-att': async function (el) { await ui.viewFile('chat', el.getAttribute('data-path'), el.getAttribute('data-name'), el.getAttribute('data-type')); },
    'view-ann': async function (el) { await ui.viewFile('resources', el.getAttribute('data-path'), el.getAttribute('data-name'), el.getAttribute('data-type')); },
    'del-ann': async function (el) { if (!(await ui.confirm({ title: 'Delete announcement?', body: 'It disappears for everyone.', ok: 'Delete', danger: true }))) return; await db.remove('announcements', { eq: { id: el.getAttribute('data-id') } }); await loadMessages(); renderPage(false); },
    'chat-clear-file': function () { S.chat.file = null; $('pendingFile').innerHTML = ''; $('chatFile').value = ''; },
    seed: async function () {
      if (!(await ui.confirm({ title: 'Load sample employees?', body: 'Creates 4 employees with 6 days of work history, computed by the real engine.', ok: 'Load' }))) return;
      var out = await E.seedDemo(); await refreshCore(); await maybeRecalc(true);
      ui.modal({ title: 'Sample employees created', body: html`<div class="ok">Preview-only logins (shown once):</div><div class="list" style="margin-top:10px">${out.map(function (o) { return html`<div class="item"><div class="grow"><b>${o.name}</b></div><code>${o.code}</code><code>${o.password}</code></div>`; })}</div>` });
    },
    'reset-preview': async function () { if (!(await ui.confirm({ title: 'Erase all preview data?', body: 'Employees, pay, chat — everything stored in this browser.', ok: 'Erase', danger: true }))) return; ui.closeAllModals(); stop(); db.resetPreview(); await showLogin(); }
  }, {
    login: async function (f, v) {
      var me = await db.auth.signIn(v.id, v.pw);
      if (me.role !== 'admin') { await db.auth.signOut(); throw new Error('This portal is for administrators only.'); }
      $('root').innerHTML = String(html`<div class="center-screen"><div class="spinner"></div></div>`);
      try { await start(me); } catch (e) { if (e && e.message === 'inactive') return; await db.auth.signOut(); stop(); await showLogin(); throw e; }
    },
    setup: async function (f, v) { var me = await db.auth.setupAdmin({ name: v.name, email: v.email, password: v.pw }); $('root').innerHTML = String(html`<div class="center-screen"><div class="spinner"></div></div>`); await start(me); ui.ok('Preview admin created ✓'); },
    'add-emp': async function (f, v) {
      var p = await db.admin.createEmployee({ employee_code: v.employee_code.trim(), full_name: v.full_name, password: v.password, monthly_base_salary: Number(v.monthly_base_salary), phone: v.phone, email: (v.email || '').trim() });
      await E.notify(p.id, 'Welcome to EmployeeOS', 'Your account is ready. Tap START WORK when your shift begins.', 'info'); await E.log(p.id, 'Employee account created', '');
      await refreshCore(); var m = ui.topModal(); if (m) { m.set(credsHtml(v.employee_code.trim(), v.password, v.full_name + ' was added')); }
      renderPage(false);
    },
    'edit-emp': async function (f, v) {
      var id = f.getAttribute('data-id'), old = S.names[id], patch = { full_name: v.full_name, employee_code: v.employee_code.trim(), phone: v.phone, email: (v.email || '').trim(), monthly_base_salary: Number(v.monthly_base_salary) };
      await db.admin.updateEmployee(id, patch);
      if (Number(old.monthly_base_salary) !== patch.monthly_base_salary) { await E.notify(id, 'Your monthly salary was updated', 'New base salary: ' + U.money(patch.monthly_base_salary), 'info'); await E.log(id, 'Base salary set to ' + U.money(patch.monthly_base_salary), ''); }
      await E.log(id, 'Profile edited', ''); ui.ok('Saved ✓'); await reloadDetail();
    },
    'reset-pw': async function (f, v) { var id = f.getAttribute('data-id'); await db.admin.updateEmployee(id, {}, v.password); await E.log(id, 'Password reset', ''); var m = ui.topModal(); if (m) m.set(credsHtml(S.names[id].employee_code, v.password, 'Password updated')); },
    'set-salary': async function (f, v) { await E.setSalary(f.getAttribute('data-id'), v.salary); ui.ok('Salary updated ✓'); await reloadDetail(); },
    'add-entry': async function (f, v) { await E.addEntry(f.getAttribute('data-id'), v.type, v.amount, v.description, v.date); ui.ok('Entry added ✓'); await reloadDetail(); },
    'add-entry-any': async function (f, v) { await E.addEntry(v.emp, v.type, v.amount, v.description, v.date); ui.closeAllModals(); ui.ok('Entry added ✓'); await loadPayroll(); renderPage(false); },
    'set-tier': async function (f, v) { await E.setTierManual(f.getAttribute('data-id'), v.tier, v.reason); ui.ok('Tier updated ✓'); await reloadDetail(); },
    'adj-points': async function (f, v) { await E.adjustPoints(f.getAttribute('data-id'), v.delta, v.reason); ui.ok('Points updated ✓'); await reloadDetail(); },
    'add-res': async function (f, v) {
      var file = v.file && v.file.size ? v.file : null;
      await E.addResource({ title: v.title, type: v.type, description: v.description, body: v.body, file: file }); f.reset(); await loadRes(); renderPage(false); ui.ok('Published ✓');
    },
    'post-ann': async function (f, v) { var file = v.file && v.file.size ? v.file : null; await E.postAnnouncement(v.title, v.body, file); ui.ok('Announcement sent ✓'); await loadMessages(); renderPage(false); },
    'chat-send': async function (f, v) {
      var id = S.route[1], body = (v.body || '').trim(), file = S.chat.file; if (!body && !file) return;
      await E.sendMessage(id, body, file); S.chat.file = null; f.reset(); $('pendingFile').innerHTML = ''; $('chatInput').style.height = 'auto'; S.lastSig = ''; await refreshMessages(); afterMessages();
    },
    rules: async function (f, v) { await E.saveRules(rulesFrom(v)); S.rules = await E.getRules(true); ui.ok('Rules saved ✓'); await maybeRecalc(true); },
    'admin-pw': async function (f, v) { if (v.pw1 !== v.pw2) throw new Error('Passwords do not match.'); await db.auth.changePassword(v.pw1); f.reset(); ui.ok('Password updated ✓'); }
  }, {
    'emp-search': function (el) { S.search = el.value; $('empList').innerHTML = String(empListHtml(S.emps.filter(function (e) { var q = S.search.toLowerCase(); return !q || (e.full_name + ' ' + e.employee_code).toLowerCase().indexOf(q) >= 0; }))); },
    'chat-file': function (el) {
      var f = el.files && el.files[0]; if (!f) return; if (f.size > db.files.max) { el.value = ''; throw new Error('File is too large (max ' + U.fmtSize(db.files.max) + ').'); }
      S.chat.file = f; $('pendingFile').innerHTML = String(pendingHtml());
    }
  });
  /* live search as you type (change fires only on blur) */
  document.addEventListener('input', function (e) { if (e.target && e.target.id === 'empSearch') { S.search = e.target.value; var q = S.search.toLowerCase(); $('empList').innerHTML = String(empListHtml(S.emps.filter(function (x) { return !q || (x.full_name + ' ' + x.employee_code).toLowerCase().indexOf(q) >= 0; }))); } });

  boot();
})();

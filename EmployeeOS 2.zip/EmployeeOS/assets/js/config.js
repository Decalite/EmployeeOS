/*
 * EmployeeOS runtime configuration.
 *
 * LEAVE supabaseUrl / supabaseAnonKey EMPTY to run in PREVIEW MODE
 * (data stored only in this browser, clearly labelled in the UI).
 *
 * To connect the real backend, paste your Supabase project values below.
 * The anon key is a PUBLIC key by design: all access is enforced by the
 * Row Level Security policies in supabase/schema.sql.
 * NEVER put the service_role key here, and never put admin passwords here.
 */
window.EOS_CONFIG = {
  supabaseUrl: '',        // e.g. 'https://abcdxyz.supabase.co'
  supabaseAnonKey: '',    // Project Settings -> API -> anon public key
  employeeEmailDomain: 'employees.employeeos.app', // must match the edge function secret EMPLOYEE_EMAIL_DOMAIN
  currency: '₹',
  locale: 'en-IN'
};

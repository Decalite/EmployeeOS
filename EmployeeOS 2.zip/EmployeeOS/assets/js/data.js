/*
 * EmployeeOS data.js - one data-layer API, two interchangeable backends:
 *
 *   SUPABASE  (real)    - Auth, Postgres+RLS, Storage, Realtime, Edge Function for user admin.
 *   LOCAL     (preview) - browser-only emulation of the same API, used ONLY when no Supabase
 *                         credentials are configured. It enforces the same role rules as the
 *                         RLS policies so permissions can be exercised in the hosted preview,
 *                         but its data lives in this browser only.
 *
 * App code talks only to EOS.db and never knows which backend is active (except db.mode for labels).
 */
(function (root) {
  'use strict';
  var EOS = root.EOS = root.EOS || {};
  var U = EOS.util;
  var cfg = EOS.config = Object.assign({
    supabaseUrl: '', supabaseAnonKey: '', employeeEmailDomain: 'employees.employeeos.app', currency: '₹', locale: 'en-IN'
  }, root.EOS_CONFIG || {});
  var APP = root.EOS_APP || 'employee';
  var MODE = (cfg.supabaseUrl && cfg.supabaseAnonKey) ? 'supabase' : 'local';
  var TABLES = ['profiles', 'work_requests', 'work_sessions', 'earning_entries', 'points_ledger', 'tier_history',
    'resources', 'messages', 'announcements', 'notifications', 'settings', 'activity_log'];
  var MAX_UPLOAD = MODE === 'supabase' ? 50 * 1048576 : 20 * 1048576;

  /* ---------- errors ---------- */
  function friendly(e) {
    var m = (e && (e.message || e.error_description || e.msg)) || String(e || 'Something went wrong');
    if (/invalid login credentials/i.test(m)) return 'Incorrect ID/email or password.';
    if (/row-level security|permission denied|not authorized|not allowed/i.test(m)) return 'You do not have permission to do that.';
    if (/failed to fetch|networkerror|load failed|network request failed/i.test(m)) return 'Network problem. Check your connection and try again.';
    if (/duplicate key|already (been )?registered|already exists/i.test(m)) return 'That value already exists (duplicate).';
    if (/jwt expired/i.test(m)) return 'Your session expired. Please sign in again.';
    return m;
  }
  EOS.friendly = friendly;
  function fail(msg) { var e = new Error(msg); e.friendly = true; return e; }

  function parseOrder(o) {
    if (!o) return [];
    return (Array.isArray(o) ? o : [o]).map(function (s) { var a = String(s).split('.'); return [a[0], a[1] !== 'desc']; });
  }
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src; s.async = true;
      s.onload = res; s.onerror = function () { rej(new Error('script failed: ' + src)); };
      document.head.appendChild(s);
    });
  }

  /* validation shared by both backends */
  var V = {
    employee: function (p, creating) {
      if (creating || p.employee_code !== undefined) if (!/^[A-Za-z0-9_-]{3,20}$/.test(String(p.employee_code || ''))) throw fail('Employee ID must be 3-20 letters, numbers, - or _.');
      if (creating || p.full_name !== undefined) if (String(p.full_name || '').trim().length < 2) throw fail('Enter the employee name.');
      if (creating || p.password) if (String(p.password || '').length < 8) throw fail('Password must be at least 8 characters.');
      if (p.monthly_base_salary !== undefined && !(Number(p.monthly_base_salary) >= 0)) throw fail('Salary must be zero or more.');
      if (p.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.email)) throw fail('Enter a valid email or leave it blank.');
    }
  };

  /* =====================================================================
   *  LOCAL (preview) backend
   * ===================================================================== */
  function LocalDB() {
    var KEY = 'eos_preview_v1', SKEY = 'eos_session_' + APP;
    var mem = null, memSession = null, useMem = false, subs = [], me = null;
    var memFiles = {}, urlCache = {};

    function blank() { var t = {}; TABLES.forEach(function (n) { t[n] = []; }); return { v: 1, t: t, users: [] }; }
    function load() {
      if (useMem) return mem;
      var s = null;
      try { s = root.localStorage.getItem(KEY); } catch (e) { useMem = true; mem = mem || blank(); return mem; }
      if (!s) return blank();
      try { return JSON.parse(s); } catch (e) { return blank(); }
    }
    function save(st) {
      if (useMem) { mem = st; return; }
      try { root.localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) { useMem = true; mem = st; }
    }
    function getSession() {
      if (useMem) return memSession;
      try { return root.localStorage.getItem(SKEY); } catch (e) { return memSession; }
    }
    function setSession(id) {
      memSession = id;
      try { if (id) root.localStorage.setItem(SKEY, id); else root.localStorage.removeItem(SKEY); } catch (e) { /* memory only */ }
    }
    function notify(table) { subs.slice().forEach(function (s) { if (!table || table === '*' || s.tables.indexOf(table) >= 0) { try { s.cb(table || '*'); } catch (e) { console.error(e); } } }); }
    root.addEventListener && root.addEventListener('storage', function (e) { if (e.key === KEY) notify('*'); });

    /* ----- hashing (preview only: PBKDF2 when WebCrypto exists, weak fallback otherwise) ----- */
    function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
    function weak(str) { var h = 5381; for (var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0; return (h >>> 0).toString(16); }
    function hashPw(pw, salt) {
      try {
        if (root.crypto && root.crypto.subtle && root.TextEncoder) {
          var enc = new TextEncoder();
          return root.crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']).then(function (k) {
            return root.crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 60000, hash: 'SHA-256' }, k, 256);
          }).then(function (bits) { return 'p1:' + hex(bits); }, function () { return 'f1:' + weak(salt + ':' + pw); });
        }
      } catch (e) { /* fall through */ }
      return Promise.resolve('f1:' + weak(salt + ':' + pw));
    }

    /* ----- policies mirroring supabase/schema.sql ----- */
    function isAdmin(u) { return !!u && u.role === 'admin' && u.status === 'active'; }
    function active(u) { return !!u && u.status === 'active'; }
    function own(u, r) { return active(u) && (isAdmin(u) || r.employee_id === u.id); }
    function adminOnly(u) { return isAdmin(u); }
    var POL = {
      profiles: { r: function (u, r) { return active(u) && (isAdmin(u) || r.id === u.id); }, w: adminOnly },
      work_requests: { r: own, w: function (u, op, r) { return isAdmin(u) || (op === 'insert' && active(u) && r.employee_id === u.id && r.status === 'pending'); } },
      work_sessions: { r: own, w: adminOnly },
      earning_entries: { r: own, w: adminOnly },
      points_ledger: { r: own, w: adminOnly },
      tier_history: { r: own, w: adminOnly },
      resources: { r: function (u) { return active(u); }, w: adminOnly },
      messages: { r: own, w: function (u, op, r) { return isAdmin(u) || (op === 'insert' && active(u) && r.employee_id === u.id && r.sender_role === 'employee' && r.sender_id === u.id); } },
      announcements: { r: function (u) { return active(u); }, w: adminOnly },
      notifications: { r: function (u, r) { return active(u) && (isAdmin(u) || r.user_id === u.id); },
        w: function (u, op, r, patch) { if (isAdmin(u)) return true; return op === 'update' && active(u) && r.user_id === u.id && Object.keys(patch || {}).every(function (k) { return k === 'read_at'; }); } },
      settings: { r: function (u) { return active(u); }, w: adminOnly },
      activity_log: { r: function (u) { return isAdmin(u); }, w: function (u, op, r) { return isAdmin(u) || (op === 'insert' && active(u) && r.actor_id === u.id); } }
    };
    var DEFAULTS = {
      work_requests: function () { return { status: 'pending', requested_at: new Date().toISOString() }; },
      messages: function () { return { read_at: null }; },
      notifications: function () { return { read_at: null }; },
      profiles: function () { return { status: 'active', role: 'employee', monthly_base_salary: 0, tier: 'Bronze', tier_override: null }; }
    };

    function curUser(st) {
      var id = getSession(); if (!id) return null;
      var p = st.t.profiles.filter(function (x) { return x.id === id; })[0];
      return p || null;
    }
    function requireUser(st) { var u = curUser(st); if (!u) throw fail('You are not signed in.'); if (u.status !== 'active') throw fail('This account is suspended.'); return u; }

    function matcher(o) {
      o = o || {};
      return function (r) {
        var k, v;
        for (k in (o.eq || {})) { v = o.eq[k]; if (v === null) { if (r[k] != null) return false; } else if (r[k] !== v) return false; }
        for (k in (o.neq || {})) { if (r[k] === o.neq[k]) return false; }
        for (k in (o.gte || {})) { if (r[k] == null || !(r[k] >= o.gte[k])) return false; }
        for (k in (o.gt || {})) { if (r[k] == null || !(r[k] > o.gt[k])) return false; }
        for (k in (o.lte || {})) { if (r[k] == null || !(r[k] <= o.lte[k])) return false; }
        for (k in (o.lt || {})) { if (r[k] == null || !(r[k] < o.lt[k])) return false; }
        for (k in (o.in || {})) { if (o.in[k].indexOf(r[k]) < 0) return false; }
        if (o.notnull) for (var i = 0; i < o.notnull.length; i++) if (r[o.notnull[i]] == null) return false;
        return true;
      };
    }
    function sortRows(rows, order) {
      var ord = parseOrder(order); if (!ord.length) return rows;
      return rows.slice().sort(function (a, b) {
        for (var i = 0; i < ord.length; i++) {
          var c = ord[i][0], asc = ord[i][1], x = a[c], y = b[c];
          if (x === y) continue; if (x == null) return 1; if (y == null) return -1;
          return (x < y ? -1 : 1) * (asc ? 1 : -1);
        }
        return 0;
      });
    }

    var api = {
      mode: 'local',
      list: function (table, o) {
        return Promise.resolve().then(function () {
          var st = load(), u = requireUser(st), pol = POL[table]; if (!pol) throw fail('Unknown table ' + table);
          var rows = st.t[table].filter(matcher(o)).filter(function (r) { return pol.r(u, r); });
          rows = sortRows(rows, o && o.order); if (o && o.limit) rows = rows.slice(0, o.limit);
          return U.clone(rows);
        });
      },
      insert: function (table, rows) {
        return Promise.resolve().then(function () {
          var st = load(), u = requireUser(st), pol = POL[table]; if (!pol) throw fail('Unknown table ' + table);
          var arr = Array.isArray(rows) ? rows : [rows], out = [];
          arr.forEach(function (r) {
            var row = Object.assign({ id: U.uid(), created_at: new Date().toISOString() }, DEFAULTS[table] ? DEFAULTS[table]() : {}, U.clone(r));
            if (table === 'settings') row = Object.assign({}, U.clone(r), { updated_at: new Date().toISOString() });
            if (!pol.w(u, 'insert', row)) throw fail('new row violates row-level security policy for table "' + table + '"');
            if (table === 'profiles' && row.employee_code && st.t.profiles.some(function (p) { return p.employee_code && p.employee_code.toLowerCase() === row.employee_code.toLowerCase(); })) throw fail('duplicate key: employee ID already exists');
            if (table === 'settings' && st.t.settings.some(function (s) { return s.key === row.key; })) throw fail('duplicate key: setting exists');
            st.t[table].push(row); out.push(row);
          });
          save(st); notify(table); return U.clone(out);
        });
      },
      update: function (table, o, patch) {
        return Promise.resolve().then(function () {
          var st = load(), u = requireUser(st), pol = POL[table], m = matcher(o), out = [];
          st.t[table].forEach(function (r) {
            if (m(r) && pol.r(u, r) && pol.w(u, 'update', r, patch)) { Object.assign(r, U.clone(patch)); if (table === 'settings') r.updated_at = new Date().toISOString(); out.push(r); }
          });
          if (out.length) { save(st); notify(table); }
          return U.clone(out);
        });
      },
      remove: function (table, o) {
        return Promise.resolve().then(function () {
          var st = load(), u = requireUser(st), pol = POL[table], m = matcher(o), out = [];
          st.t[table] = st.t[table].filter(function (r) {
            if (m(r) && pol.r(u, r) && pol.w(u, 'delete', r)) { out.push(r); return false; } return true;
          });
          if (out.length) { save(st); notify(table); }
          return U.clone(out);
        });
      },
      rpc: function (name, args) {
        args = args || {};
        return Promise.resolve().then(function () {
          var st = load(), u = requireUser(st);
          if (name === 'leaderboard') {
            var since = args.p_since ? new Date(args.p_since).getTime() : null;
            return st.t.profiles.filter(function (p) { return p.role === 'employee' && p.status === 'active'; }).map(function (p) {
              var pts = st.t.points_ledger.filter(function (l) { return l.employee_id === p.id && (since == null || new Date(l.created_at).getTime() >= since); })
                .reduce(function (a, l) { return a + Number(l.points); }, 0);
              return { employee_id: p.id, employee_code: p.employee_code, full_name: p.full_name, tier: p.tier, points: pts };
            }).sort(function (a, b) { return b.points - a.points || (a.full_name < b.full_name ? -1 : 1); });
          }
          if (name === 'mark_read') {
            var emp = args.p_employee, changed = false;
            if (!isAdmin(u) && u.id !== emp) throw fail('not allowed');
            var from = isAdmin(u) ? 'employee' : 'admin';
            st.t.messages.forEach(function (m) { if (m.employee_id === emp && m.sender_role === from && !m.read_at) { m.read_at = new Date().toISOString(); changed = true; } });
            if (changed) { save(st); notify('messages'); }
            return null;
          }
          if (name === 'update_my_profile') {
            var p = st.t.profiles.filter(function (x) { return x.id === u.id; })[0];
            var phone = String(args.p_phone == null ? '' : args.p_phone).trim().slice(0, 30);
            p.phone = phone; save(st); notify('profiles'); return null;
          }
          throw fail('Unknown function ' + name);
        });
      },
      subscribe: function (tables, cb) {
        var s = { tables: tables, cb: cb }; subs.push(s);
        return function () { subs = subs.filter(function (x) { return x !== s; }); };
      },

      /* ----- auth ----- */
      auth: {
        init: function () {
          return Promise.resolve().then(function () {
            var st = load(), u = curUser(st);
            if (u && u.status !== 'active') { setSession(null); return null; }
            me = u; return U.clone(u);
          });
        },
        needsSetup: function () { return Promise.resolve(!load().t.profiles.some(function (p) { return p.role === 'admin'; })); },
        setupAdmin: function (p) {
          return Promise.resolve().then(function () {
            var st = load();
            if (st.t.profiles.some(function (x) { return x.role === 'admin'; })) throw fail('An admin already exists.');
            if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.email || '')) throw fail('Enter a valid email.');
            if (String(p.name || '').trim().length < 2) throw fail('Enter your name.');
            if (String(p.password || '').length < 8) throw fail('Password must be at least 8 characters.');
            var salt = U.uid(), id = U.uid();
            return hashPw(p.password, salt).then(function (h) {
              st = load();
              st.users.push({ id: id, login: p.email.trim().toLowerCase(), salt: salt, hash: h });
              st.t.profiles.push({ id: id, employee_code: null, full_name: p.name.trim(), email: p.email.trim(), phone: '', role: 'admin', status: 'active', monthly_base_salary: 0, tier: 'Bronze', tier_override: null, created_at: new Date().toISOString() });
              save(st); setSession(id); me = curUser(st); notify('*'); return U.clone(me);
            });
          });
        },
        signIn: function (identifier, password) {
          var st = load(), login = String(identifier || '').trim().toLowerCase();
          var user = st.users.filter(function (x) { return x.login === login; })[0];
          if (!user) return hashPw(password || '', 'x').then(function () { throw fail('Incorrect ID/email or password.'); });
          return hashPw(password || '', user.salt).then(function (h) {
            if (h !== user.hash) throw fail('Incorrect ID/email or password.');
            var p = load().t.profiles.filter(function (x) { return x.id === user.id; })[0];
            if (!p) throw fail('Account not provisioned.');
            if (p.status !== 'active') throw fail('This account is suspended. Contact your admin.');
            setSession(user.id); me = p; return U.clone(p);
          });
        },
        signOut: function () { setSession(null); me = null; return Promise.resolve(); },
        changePassword: function (pw) {
          return Promise.resolve().then(function () {
            if (String(pw || '').length < 8) throw fail('Password must be at least 8 characters.');
            var st = load(), u = requireUser(st), salt = U.uid();
            return hashPw(pw, salt).then(function (h) {
              st = load(); var usr = st.users.filter(function (x) { return x.id === u.id; })[0];
              usr.salt = salt; usr.hash = h; save(st);
            });
          });
        }
      },

      /* ----- admin user management (Supabase: Edge Function; here: local) ----- */
      admin: {
        createEmployee: function (p) {
          return Promise.resolve().then(function () {
            var st = load(), u = requireUser(st); if (!isAdmin(u)) throw fail('Admins only.');
            V.employee(p, true);
            var login = p.employee_code.toLowerCase();
            if (st.users.some(function (x) { return x.login === login; })) throw fail('duplicate key: that Employee ID already exists');
            var salt = U.uid(), id = U.uid();
            return hashPw(p.password, salt).then(function (h) {
              st = load();
              st.users.push({ id: id, login: login, salt: salt, hash: h });
              var prof = Object.assign({ id: id, created_at: new Date().toISOString(), email: p.email || '', phone: p.phone || '' }, DEFAULTS.profiles(),
                { employee_code: p.employee_code, full_name: p.full_name.trim(), monthly_base_salary: Number(p.monthly_base_salary) || 0 });
              st.t.profiles.push(prof); save(st); notify('profiles'); return U.clone(prof);
            });
          });
        },
        updateEmployee: function (id, patch, password) {
          return Promise.resolve().then(function () {
            var st = load(), u = requireUser(st); if (!isAdmin(u)) throw fail('Admins only.');
            var prof = st.t.profiles.filter(function (x) { return x.id === id && x.role === 'employee'; })[0]; if (!prof) throw fail('Employee not found.');
            V.employee(Object.assign({}, patch, password ? { password: password } : {}), false);
            if (patch.status && ['active', 'suspended'].indexOf(patch.status) < 0) throw fail('Invalid status.');
            var usr = st.users.filter(function (x) { return x.id === id; })[0];
            if (patch.employee_code && patch.employee_code.toLowerCase() !== (prof.employee_code || '').toLowerCase()) {
              if (st.users.some(function (x) { return x.login === patch.employee_code.toLowerCase(); })) throw fail('duplicate key: that Employee ID already exists');
              usr.login = patch.employee_code.toLowerCase();
            }
            var allowed = U.pick(patch, ['employee_code', 'full_name', 'phone', 'email', 'monthly_base_salary', 'status']);
            if (allowed.monthly_base_salary !== undefined) allowed.monthly_base_salary = Number(allowed.monthly_base_salary);
            Object.assign(prof, allowed);
            var done = function () { save(st); notify('profiles'); return U.clone(prof); };
            if (password) { var salt = U.uid(); return hashPw(password, salt).then(function (h) { usr.salt = salt; usr.hash = h; return done(); }); }
            return done();
          });
        },
        deleteEmployee: function (id) {
          return Promise.resolve().then(function () {
            var st = load(), u = requireUser(st); if (!isAdmin(u)) throw fail('Admins only.');
            var prof = st.t.profiles.filter(function (x) { return x.id === id && x.role === 'employee'; })[0]; if (!prof) throw fail('Employee not found.');
            st.t.profiles = st.t.profiles.filter(function (x) { return x.id !== id; });
            st.users = st.users.filter(function (x) { return x.id !== id; });
            ['work_requests', 'work_sessions', 'earning_entries', 'points_ledger', 'tier_history', 'messages'].forEach(function (t) { st.t[t] = st.t[t].filter(function (r) { return r.employee_id !== id; }); });
            st.t.notifications = st.t.notifications.filter(function (r) { return r.user_id !== id; });
            st.t.activity_log = st.t.activity_log.filter(function (r) { return r.employee_id !== id; });
            save(st); notify('*'); return true;
          });
        }
      },

      /* ----- files (IndexedDB, memory fallback) ----- */
      files: {
        max: MAX_UPLOAD,
        upload: function (bucket, file, folder) {
          return Promise.resolve().then(function () {
            requireUser(load());
            if (file.size > MAX_UPLOAD) throw fail('File is too large (max ' + U.fmtSize(MAX_UPLOAD) + ').');
            var safe = String(file.name || 'file').replace(/[^A-Za-z0-9._-]+/g, '_').slice(-80);
            var path = (folder ? folder + '/' : '') + U.uid().slice(0, 8) + '-' + safe;
            var rec = { blob: file, type: file.type || 'application/octet-stream' };
            return idbPut(bucket + '/' + path, rec).then(function () { return { path: path, name: file.name, type: rec.type, size: file.size }; });
          });
        },
        url: function (bucket, path) {
          var k = bucket + '/' + path;
          if (urlCache[k]) return Promise.resolve(urlCache[k]);
          return idbGet(k).then(function (rec) {
            if (!rec) throw fail('File not found in this browser.');
            var blob = rec.blob instanceof Blob ? rec.blob : new Blob([rec.blob], { type: rec.type });
            return (urlCache[k] = URL.createObjectURL(blob));
          });
        },
        remove: function (bucket, path) { return idbDel(bucket + '/' + path).catch(function () {}); }
      },
      /* preview-only utilities */
      resetPreview: function () { try { root.localStorage.removeItem(KEY); root.localStorage.removeItem('eos_session_admin'); root.localStorage.removeItem('eos_session_employee'); } catch (e) {} mem = null; useMem = false; setSession(null); notify('*'); }
    };

    function idb() {
      return new Promise(function (res, rej) {
        if (!root.indexedDB) return rej(new Error('noidb'));
        var r; try { r = root.indexedDB.open('eos_files', 1); } catch (e) { return rej(e); }
        r.onupgradeneeded = function () { r.result.createObjectStore('f'); };
        r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); };
      });
    }
    function idbPut(k, v) {
      return idb().then(function (d) { return new Promise(function (res, rej) { var t = d.transaction('f', 'readwrite'); t.objectStore('f').put(v, k); t.oncomplete = function () { res(); }; t.onerror = function () { rej(t.error); }; }); })
        .catch(function () { memFiles[k] = v; });
    }
    function idbGet(k) {
      if (memFiles[k]) return Promise.resolve(memFiles[k]);
      return idb().then(function (d) { return new Promise(function (res, rej) { var q = d.transaction('f').objectStore('f').get(k); q.onsuccess = function () { res(q.result); }; q.onerror = function () { rej(q.error); }; }); }).catch(function () { return memFiles[k]; });
    }
    function idbDel(k) {
      delete memFiles[k];
      return idb().then(function (d) { return new Promise(function (res) { var t = d.transaction('f', 'readwrite'); t.objectStore('f').delete(k); t.oncomplete = res; t.onerror = res; }); });
    }
    return api;
  }

  /* =====================================================================
   *  SUPABASE backend
   * ===================================================================== */
  function SupabaseDB() {
    var sb = null, me = null, signedCache = {};
    var LIB_URLS = ['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js',
      'https://unpkg.com/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js'];

    function ensure() {
      if (sb) return Promise.resolve(sb);
      var p = root.supabase && root.supabase.createClient ? Promise.resolve() :
        loadScript(LIB_URLS[0]).catch(function () { return loadScript(LIB_URLS[1]); });
      return p.then(function () {
        if (!root.supabase || !root.supabase.createClient) throw fail('Could not load the backend library. Check your connection and reload.');
        sb = root.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
          auth: { storageKey: 'eos-' + APP + '-auth', persistSession: true, autoRefreshToken: true, detectSessionInUrl: false }
        });
        return sb;
      }, function () { throw fail('Could not load the backend library. Check your connection and reload.'); });
    }
    function check(r) { if (r.error) { var e = new Error(friendly(r.error)); e.friendly = true; e.raw = r.error; throw e; } return r.data; }
    function filters(q, o) {
      o = o || {}; var k;
      for (k in (o.eq || {})) q = o.eq[k] === null ? q.is(k, null) : q.eq(k, o.eq[k]);
      for (k in (o.neq || {})) q = q.neq(k, o.neq[k]);
      for (k in (o.gte || {})) q = q.gte(k, o.gte[k]);
      for (k in (o.gt || {})) q = q.gt(k, o.gt[k]);
      for (k in (o.lte || {})) q = q.lte(k, o.lte[k]);
      for (k in (o.lt || {})) q = q.lt(k, o.lt[k]);
      for (k in (o.in || {})) q = q.in(k, o.in[k]);
      (o.notnull || []).forEach(function (c) { q = q.not(c, 'is', null); });
      return q;
    }
    function fn(body) {
      return ensure().then(function () { return sb.functions.invoke('admin-users', { body: body }); }).then(function (r) {
        if (r.error) {
          var m = r.error.message;
          if (r.error.context && r.error.context.json) return r.error.context.json().then(function (j) { throw fail((j && j.error) || m); }, function () { throw fail(m); });
          throw fail(m);
        }
        if (r.data && r.data.error) throw fail(r.data.error);
        return r.data;
      });
    }
    function profileFor(id) {
      return sb.from('profiles').select('*').eq('id', id).maybeSingle().then(function (r) { return check(r); });
    }

    var api = {
      mode: 'supabase',
      list: function (table, o) {
        return ensure().then(function () {
          var q = filters(sb.from(table).select('*'), o);
          parseOrder(o && o.order).forEach(function (x) { q = q.order(x[0], { ascending: x[1] }); });
          if (o && o.limit) q = q.limit(o.limit);
          return q;
        }).then(check);
      },
      insert: function (table, rows, opts) {
        return ensure().then(function () { var q = sb.from(table).insert(rows); return (opts && opts.quiet) ? q : q.select(); }).then(check);
      },
      update: function (table, o, patch) { return ensure().then(function () { return filters(sb.from(table).update(patch), o).select(); }).then(check); },
      remove: function (table, o) { return ensure().then(function () { return filters(sb.from(table).delete(), o).select(); }).then(check); },
      rpc: function (name, args) { return ensure().then(function () { return sb.rpc(name, args || {}); }).then(check); },
      subscribe: function (tables, cb) {
        var ch = null, dead = false;
        ensure().then(function () {
          if (dead) return;
          ch = sb.channel('eos-' + U.uid());
          tables.forEach(function (t) { ch.on('postgres_changes', { event: '*', schema: 'public', table: t }, function () { cb(t); }); });
          ch.subscribe();
        }).catch(function () { /* polling fallback in app */ });
        return function () { dead = true; try { if (ch) sb.removeChannel(ch); } catch (e) {} };
      },
      auth: {
        init: function () {
          return ensure().then(function () { return sb.auth.getSession(); }).then(function (r) {
            var s = r.data && r.data.session; if (!s) return null;
            return profileFor(s.user.id).then(function (p) {
              if (!p || p.status !== 'active') { return sb.auth.signOut().then(function () { return null; }); }
              me = p; return p;
            });
          }).catch(function (e) { if (e && e.friendly) throw e; return null; });
        },
        needsSetup: function () { return Promise.resolve(false); },
        setupAdmin: function () { return Promise.reject(fail('Create the first admin in Supabase (see README).')); },
        signIn: function (identifier, password) {
          var id = String(identifier || '').trim(); if (!id || !password) return Promise.reject(fail('Enter your ID/email and password.'));
          var email = id.indexOf('@') >= 0 ? id : id.toLowerCase() + '@' + cfg.employeeEmailDomain;
          return ensure().then(function () { return sb.auth.signInWithPassword({ email: email, password: password }); }).then(check).then(function (d) {
            return profileFor(d.user.id).then(function (p) {
              if (!p) return sb.auth.signOut().then(function () { throw fail('Your account is not set up yet. Contact your admin.'); });
              if (p.status !== 'active') return sb.auth.signOut().then(function () { throw fail('This account is suspended. Contact your admin.'); });
              me = p; return p;
            });
          });
        },
        signOut: function () { me = null; return ensure().then(function () { return sb.auth.signOut(); }).then(function () {}, function () {}); },
        changePassword: function (pw) {
          if (String(pw || '').length < 8) return Promise.reject(fail('Password must be at least 8 characters.'));
          return ensure().then(function () { return sb.auth.updateUser({ password: pw }); }).then(check).then(function () {});
        }
      },
      admin: {
        createEmployee: function (p) { V.employee(p, true); return fn({ action: 'create', employee: p }).then(function (d) { return d.profile; }); },
        updateEmployee: function (id, patch, password) { V.employee(Object.assign({}, patch, password ? { password: password } : {}), false); return fn({ action: 'update', id: id, patch: patch, password: password || null }).then(function (d) { return d.profile; }); },
        deleteEmployee: function (id) { return fn({ action: 'delete', id: id }).then(function () { return true; }); }
      },
      files: {
        max: MAX_UPLOAD,
        upload: function (bucket, file, folder) {
          if (file.size > MAX_UPLOAD) return Promise.reject(fail('File is too large (max ' + U.fmtSize(MAX_UPLOAD) + ').'));
          var safe = String(file.name || 'file').replace(/[^A-Za-z0-9._-]+/g, '_').slice(-80);
          var path = (folder ? folder + '/' : '') + U.uid().slice(0, 8) + '-' + safe;
          return ensure().then(function () { return sb.storage.from(bucket).upload(path, file, { contentType: file.type || 'application/octet-stream', upsert: false }); })
            .then(check).then(function () { return { path: path, name: file.name, type: file.type || 'application/octet-stream', size: file.size }; });
        },
        url: function (bucket, path) {
          var k = bucket + '/' + path, c = signedCache[k];
          if (c && c.exp > Date.now()) return Promise.resolve(c.url);
          return ensure().then(function () { return sb.storage.from(bucket).createSignedUrl(path, 3600); }).then(check).then(function (d) {
            signedCache[k] = { url: d.signedUrl, exp: Date.now() + 50 * 60000 }; return d.signedUrl;
          });
        },
        remove: function (bucket, path) { return ensure().then(function () { return sb.storage.from(bucket).remove([path]); }).then(function () {}, function () {}); }
      }
    };
    return api;
  }

  var impl = MODE === 'supabase' ? SupabaseDB() : LocalDB();
  EOS.db = impl;
  EOS.db.cfg = cfg;
  EOS.db.app = APP;
  EOS.db.TABLES = TABLES;
  EOS.db.validate = V;
  if (typeof module !== 'undefined' && module.exports) module.exports = EOS;
})(typeof window !== 'undefined' ? window : globalThis);

# EmployeeOS

Employee + admin workforce app: START WORK approvals, earnings, attendance, tiers & leaderboards, resources, chat.
Static front-end (no build step) + **Supabase** backend (Auth, Postgres with Row Level Security, Storage, Realtime, one Edge Function).

```
index.html            employee app          admin.html            admin console (separate, role-checked)
assets/styles.css     design system         assets/js/*.js        util · ui · data · engine · shared · employee · admin
supabase/schema.sql   tables + RLS + RPCs   supabase/storage.sql  private buckets + policies
supabase/functions/admin-users/index.ts     server-side user management (service-role key stays on the server)
tests/                unit, e2e, RLS tests  scripts/write-config.js  env → config.js
```

## Why the old preview was blank (and the fix)
The original `index.html` drew everything below the header with JavaScript. **iOS Files "Quick Look" does not run JavaScript**, so only the static header appeared. There was no JS error: the page simply never ran. Fixes: (1) open the app from a hosted `https://` link in Safari, never from Files; (2) the page now shows a visible loading state, a "still loading?" hint, and a `<noscript>` message that explains this; (3) boot and runtime errors show a readable error screen with Retry. Also fixed: month navigation and "today" used `toISOString()` (UTC), which is off by a day in IST.

## Two modes
| Mode | When | Data |
|---|---|---|
| **Preview** | `assets/js/config.js` has empty `supabaseUrl`/`supabaseAnonKey` | Stored **only in that browser** (labelled "PREVIEW MODE" on every screen). Same API and the same role rules, so every flow can be tried. Not shared between devices. |
| **Live (Supabase)** | both values set | Shared database, real auth, cloud storage, realtime. |

## 1. Database setup (Supabase)
1. Create a project at supabase.com.
2. **SQL Editor** → run `supabase/schema.sql`, then `supabase/storage.sql`.
3. **Authentication → Providers → Email**: keep Email enabled, **turn OFF "Allow new users to sign up"** (accounts are created only by admins), set minimum password length 8+.
4. **Project Settings → API**: copy the *Project URL* and the *anon public* key.

## 2. Admin login setup
No admin credentials exist in code. Create the first admin yourself:
1. Dashboard → **Authentication → Users → Add user** → your email + strong password, tick **Auto Confirm**.
2. SQL Editor (replace email/name):
   ```sql
   insert into public.profiles (id, full_name, email, role)
   select id, 'Your Name', email, 'admin' from auth.users where email = 'you@company.com';
   ```
3. Open `admin.html`, sign in with that email + password. More admins: repeat steps 1–2.

## 3. Employee login setup
Admin → **Employees → Add employee**: enter name, **Employee ID** (e.g. `EMP001`), password (Generate button), salary. The credentials are shown once with a Copy button. The employee signs in at `index.html` with **ID + password**. Admin can reset a password, suspend (signed out immediately, cannot log in), reactivate or remove an employee at any time.
Behind the scenes the Edge Function creates a Supabase Auth user with the internal email `emp001@employees.employeeos.app` (never emailed).

## 4. Deploy the Edge Function (user management)
```bash
npm i -g supabase            # or: brew install supabase/tap/supabase
supabase login
supabase link --project-ref YOUR-PROJECT-REF
supabase functions deploy admin-users
# optional, only if you change the internal email domain (must match config.js):
supabase secrets set EMPLOYEE_EMAIL_DOMAIN=employees.employeeos.app
```
`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are injected by Supabase; they never appear in the front-end.

## 5. Environment variables
| Variable | Where | Value |
|---|---|---|
| `SUPABASE_URL` | build env → `config.js` | Project URL |
| `SUPABASE_ANON_KEY` | build env → `config.js` | **anon public** key (safe in browsers; RLS protects data) |
| `EMPLOYEE_EMAIL_DOMAIN` | build env + Edge secret | default `employees.employeeos.app` |
| `SUPABASE_SERVICE_ROLE_KEY` | Edge Function only (auto) | **never** in front-end/git — `write-config.js` refuses it |

Locally: paste the two values into `assets/js/config.js`, or run `SUPABASE_URL=… SUPABASE_ANON_KEY=… node scripts/write-config.js`.

## 6. Deploy the front-end (any static host, HTTPS required)
* **Netlify / Vercel / Cloudflare Pages**: connect the repo, set the env vars above, build command `node scripts/write-config.js`, publish directory `.` (`netlify.toml` / `vercel.json` included).
* **Or** any static host (GitHub Pages, S3…): run `write-config.js` once, upload the folder.
Share `https://your-domain/` (employees) and `https://your-domain/admin.html` (admins). On iPhone: Safari → Share → *Add to Home Screen* for a full-screen app.

## How the rules work (all configurable in Admin → Settings)
* **Daily pay** = base salary ÷ working days × min(hours ÷ standard hours, 1). Start time = admin approval; end time = the moment the employee requested leave.
* **Points** = hours × points/hour + attendance points for days over the minimum hours; admin can add/remove points with a reason (ledger = ranking history).
* **Tier** = highest tier whose threshold ≤ points in the rolling window (default 30 days) → automatic promotion **and demotion**. Admin can pin a tier manually, or return it to Automatic. Promotion bonus paid once per tier; monthly top-3 rewards are paid once per place per month.
* **Leaderboards** (daily/weekly/monthly/all-time) show names, tiers, points only; never pay.

## Tests (what was actually run)
```bash
node tests/engine.test.js          # 10 unit tests: pay, tiers, ranking ties, summaries, dates, money, XSS escaping
node tests/e2e.js                  # 72 browser checks, desktop + iPhone-14 viewport, admin + employee tabs
# RLS: schema.sql + storage.sql applied to PostgreSQL 16 with an emulated auth schema, then ~45 attack/permission assertions
```
Covered: employee/admin login, wrong passwords, role separation, START WORK request→approve/reject, LEAVE request→approve/reject, hours/pay/points maths, salary change, bonus/extra/deduction, CSV export, 4 leaderboards, auto promotion/demotion, manual tier, rewards, resource upload + viewing, chat with attachments + unread/seen, announcements, day-off, profile/password, suspend/reactivate/remove, persistence after refresh, no-JS message, 390px layout without horizontal scroll on all 19 pages, zero console errors.

## Honest status
**Done and tested:** everything listed above in Preview mode; database schema + RLS + storage policies on a real PostgreSQL 16.
**Written but NOT run against a live Supabase project** (no credentials were available): the Supabase JS wiring in `data.js` (auth, realtime, signed URLs), the Edge Function, and the storage bucket creation. Treat the first connection as a test: create admin → add employee → login → start/approve → send chat file. Report any error text and it can be fixed quickly.
**iPhone:** verified with Chromium's iPhone 14 emulation (viewport, touch, safe-area CSS). Real Safari was not available here; code avoids APIs newer than iOS 14.5 and has fallbacks (IndexedDB→memory, BroadcastChannel not used, clipboard fallback, polling every 30 s if realtime is down).
**Pending / not built:** payout "paid" status & PDF payslips; push notifications (in-app only); tier *decay* is recalculated when an admin opens the console, after each approved session, and on "Recalculate" (add a `pg_cron` job if you want it fully unattended); pagination beyond 1,000 rows per query; password-reset by email (admin reset only); login rate-limiting beyond Supabase's built-in limits; large-video transcoding; per-employee leaderboard privacy toggle.

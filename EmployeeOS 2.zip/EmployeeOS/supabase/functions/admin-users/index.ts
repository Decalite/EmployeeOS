// EmployeeOS Edge Function: admin-users
// Creating users, setting passwords, suspending and deleting accounts needs the SERVICE ROLE key,
// which must never reach the browser. This function holds it server-side and only acts for a
// signed-in, active ADMIN (verified from the caller's JWT against public.profiles).
//
// Deploy:  supabase functions deploy admin-users
// Secrets: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are injected automatically by Supabase.
//          Optional: supabase secrets set EMPLOYEE_EMAIL_DOMAIN=employees.employeeos.app
//          (must equal employeeEmailDomain in assets/js/config.js)
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

const CODE_RE = /^[A-Za-z0-9_-]{3,20}$/;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const domain = Deno.env.get('EMPLOYEE_EMAIL_DOMAIN') ?? 'employees.employeeos.app';
    const sb = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

    // 1. who is calling, and are they an active admin?
    const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '');
    const { data: auth, error: authErr } = await sb.auth.getUser(token);
    if (authErr || !auth?.user) return json({ error: 'Not signed in.' }, 401);
    const { data: me } = await sb.from('profiles').select('role,status').eq('id', auth.user.id).maybeSingle();
    if (!me || me.role !== 'admin' || me.status !== 'active') return json({ error: 'Admins only.' }, 403);

    const body = await req.json().catch(() => ({}));
    const action = body?.action;

    // 2. actions
    if (action === 'create') {
      const p = body.employee ?? {};
      const code = String(p.employee_code ?? '').trim();
      const name = String(p.full_name ?? '').trim();
      const password = String(p.password ?? '');
      const salary = Number(p.monthly_base_salary ?? 0);
      if (!CODE_RE.test(code)) return json({ error: 'Employee ID must be 3-20 letters, numbers, - or _.' }, 400);
      if (name.length < 2 || name.length > 80) return json({ error: 'Enter the employee name.' }, 400);
      if (password.length < 8) return json({ error: 'Password must be at least 8 characters.' }, 400);
      if (!(salary >= 0)) return json({ error: 'Salary must be zero or more.' }, 400);
      const contactEmail = String(p.email ?? '').trim();
      if (contactEmail && !EMAIL_RE.test(contactEmail)) return json({ error: 'Enter a valid email or leave it blank.' }, 400);

      const { data: dup } = await sb.from('profiles').select('id').ilike('employee_code', code).maybeSingle();
      if (dup) return json({ error: 'That Employee ID already exists.' }, 409);

      const { data: created, error: cErr } = await sb.auth.admin.createUser({
        email: `${code.toLowerCase()}@${domain}`, password, email_confirm: true,
      });
      if (cErr || !created?.user) return json({ error: cErr?.message ?? 'Could not create the login.' }, 400);
      const { data: profile, error: pErr } = await sb.from('profiles').insert({
        id: created.user.id, employee_code: code, full_name: name, email: contactEmail,
        phone: String(p.phone ?? '').slice(0, 30), role: 'employee', monthly_base_salary: salary,
      }).select().single();
      if (pErr) {
        await sb.auth.admin.deleteUser(created.user.id); // roll back
        return json({ error: pErr.message }, 400);
      }
      return json({ profile });
    }

    if (action === 'update' || action === 'delete') {
      const id = String(body.id ?? '');
      const { data: target } = await sb.from('profiles').select('*').eq('id', id).maybeSingle();
      if (!target || target.role !== 'employee') return json({ error: 'Employee not found.' }, 404);

      if (action === 'delete') {
        const { error } = await sb.auth.admin.deleteUser(id); // profile + records cascade
        if (error) return json({ error: error.message }, 400);
        return json({ ok: true });
      }

      const patch = body.patch ?? {};
      const upd: Record<string, unknown> = {};
      if (patch.full_name !== undefined) {
        const n = String(patch.full_name).trim();
        if (n.length < 2 || n.length > 80) return json({ error: 'Enter the employee name.' }, 400);
        upd.full_name = n;
      }
      if (patch.phone !== undefined) upd.phone = String(patch.phone).slice(0, 30);
      if (patch.email !== undefined) {
        const e = String(patch.email).trim();
        if (e && !EMAIL_RE.test(e)) return json({ error: 'Enter a valid email or leave it blank.' }, 400);
        upd.email = e;
      }
      if (patch.monthly_base_salary !== undefined) {
        const s = Number(patch.monthly_base_salary);
        if (!(s >= 0)) return json({ error: 'Salary must be zero or more.' }, 400);
        upd.monthly_base_salary = s;
      }
      if (patch.status !== undefined) {
        if (!['active', 'suspended'].includes(patch.status)) return json({ error: 'Invalid status.' }, 400);
        upd.status = patch.status;
      }
      const authUpd: Record<string, unknown> = {};
      if (patch.employee_code !== undefined && String(patch.employee_code).toLowerCase() !== String(target.employee_code).toLowerCase()) {
        const code = String(patch.employee_code).trim();
        if (!CODE_RE.test(code)) return json({ error: 'Employee ID must be 3-20 letters, numbers, - or _.' }, 400);
        const { data: dup } = await sb.from('profiles').select('id').ilike('employee_code', code).neq('id', id).maybeSingle();
        if (dup) return json({ error: 'That Employee ID already exists.' }, 409);
        upd.employee_code = code;
        authUpd.email = `${code.toLowerCase()}@${domain}`;
        authUpd.email_confirm = true;
      } else if (patch.employee_code !== undefined) {
        upd.employee_code = String(patch.employee_code).trim();
      }
      if (body.password) {
        if (String(body.password).length < 8) return json({ error: 'Password must be at least 8 characters.' }, 400);
        authUpd.password = String(body.password);
      }
      if (upd.status === 'suspended') authUpd.ban_duration = '876000h';
      if (upd.status === 'active') authUpd.ban_duration = 'none';

      if (Object.keys(authUpd).length) {
        const { error } = await sb.auth.admin.updateUserById(id, authUpd);
        if (error) return json({ error: error.message }, 400);
      }
      let profile = target;
      if (Object.keys(upd).length) {
        const { data, error } = await sb.from('profiles').update(upd).eq('id', id).select().single();
        if (error) return json({ error: error.message }, 400);
        profile = data;
      }
      return json({ profile });
    }

    return json({ error: 'Unknown action.' }, 400);
  } catch (e) {
    return json({ error: (e as Error).message ?? 'Server error' }, 500);
  }
});

-- EmployeeOS storage: two PRIVATE buckets. Run after schema.sql.
--   resources : admin uploads (videos, images, PDFs, docs, announcement files); every active user can read.
--   chat      : chat attachments stored under <employee_id>/...; only that employee and admins can read/write.
insert into storage.buckets (id, name, public, file_size_limit)
values ('resources', 'resources', false, 52428800), ('chat', 'chat', false, 52428800)
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit;

create policy "resources read" on storage.objects for select to authenticated
  using (bucket_id = 'resources' and public.is_active());
create policy "resources admin insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'resources' and public.is_admin());
create policy "resources admin update" on storage.objects for update to authenticated
  using (bucket_id = 'resources' and public.is_admin());
create policy "resources admin delete" on storage.objects for delete to authenticated
  using (bucket_id = 'resources' and public.is_admin());

create policy "chat read" on storage.objects for select to authenticated
  using (bucket_id = 'chat' and public.is_active() and (public.is_admin() or (storage.foldername(name))[1] = auth.uid()::text));
create policy "chat insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'chat' and public.is_active() and (public.is_admin() or (storage.foldername(name))[1] = auth.uid()::text));
create policy "chat admin delete" on storage.objects for delete to authenticated
  using (bucket_id = 'chat' and public.is_admin());

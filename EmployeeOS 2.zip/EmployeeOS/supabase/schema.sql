-- =====================================================================
-- EmployeeOS database schema for Supabase (PostgreSQL 15+)
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run.
-- Then run storage.sql. Safe to run on an empty project.
-- Extends the original MVP schema (profiles, work_requests, work_sessions,
-- earning_entries, resources, messages) and adds ranking, announcements,
-- notifications, settings and activity logging.
-- =====================================================================

create type public.app_role as enum ('admin','employee');
create type public.work_request_type as enum ('start','leave','dayoff');
create type public.work_request_status as enum ('pending','approved','rejected');

-- ---------- tables ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  employee_code text,
  full_name text not null check (char_length(full_name) between 2 and 80),
  email text default '',
  phone text default '',
  role public.app_role not null default 'employee',
  status text not null default 'active' check (status in ('active','suspended')),
  monthly_base_salary numeric(12,2) not null default 0 check (monthly_base_salary >= 0),
  tier text not null default 'Bronze' check (tier in ('Bronze','Silver','Gold','Platinum','Diamond')),
  tier_override text check (tier_override in ('Bronze','Silver','Gold','Platinum','Diamond')),
  created_at timestamptz not null default now()
);
create unique index profiles_code_key on public.profiles (lower(employee_code)) where employee_code is not null;

create table public.work_requests (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id) on delete cascade,
  request_type public.work_request_type not null,
  status public.work_request_status not null default 'pending',
  request_date date not null default current_date,
  session_id uuid,
  reason text check (char_length(reason) <= 300),
  review_note text,
  requested_at timestamptz not null default now(),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz
);
create index on public.work_requests (employee_id, status);

create table public.work_sessions (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id) on delete cascade,
  started_at timestamptz not null,
  ended_at timestamptz,
  work_date date not null,
  hours numeric(6,2),
  start_request_id uuid references public.work_requests(id) on delete set null,
  end_request_id uuid references public.work_requests(id) on delete set null
);
create index on public.work_sessions (employee_id, work_date);
-- at most one open session per employee
create unique index one_open_session on public.work_sessions (employee_id) where ended_at is null;

create table public.earning_entries (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id) on delete cascade,
  entry_date date not null default current_date,
  entry_type text not null check (entry_type in ('daily','extra','bonus','deduction')),
  amount numeric(12,2) not null check (amount >= 0),
  description text,
  ref text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index on public.earning_entries (employee_id, entry_date);
create unique index one_daily_entry on public.earning_entries (employee_id, entry_date) where entry_type = 'daily';
create unique index entry_ref_once on public.earning_entries (ref) where ref is not null and ref like 'reward:%';

create table public.points_ledger (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id) on delete cascade,
  points integer not null,
  reason text not null,
  source text not null check (source in ('work','attendance','manual','reward')),
  ref text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index on public.points_ledger (employee_id, created_at);
create index on public.points_ledger (created_at);

create table public.tier_history (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id) on delete cascade,
  old_tier text, new_tier text not null,
  reason text, points_snapshot integer,
  manual boolean not null default false,
  bonus numeric(12,2) not null default 0,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index on public.tier_history (employee_id, created_at);

create table public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  resource_type text not null check (resource_type in ('video','image','pdf','document','note','instruction')),
  description text,
  body text,
  storage_path text, file_name text, mime_type text, file_size bigint,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id) on delete cascade, -- the conversation owner
  sender_id uuid not null references public.profiles(id) on delete cascade,
  sender_role text not null check (sender_role in ('admin','employee')),
  body text not null default '' check (char_length(body) <= 2000),
  attachment_path text, attachment_name text, attachment_type text, attachment_size bigint,
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check (body <> '' or attachment_path is not null)
);
create index on public.messages (employee_id, created_at);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null, body text not null default '',
  author_id uuid references public.profiles(id) on delete set null,
  attachment_path text, attachment_name text, attachment_type text,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, body text default '', kind text not null default 'info',
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index on public.notifications (user_id, created_at);

create table public.settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table public.activity_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  employee_id uuid references public.profiles(id) on delete cascade,
  action text not null, details text default '',
  created_at timestamptz not null default now()
);
create index on public.activity_log (employee_id, created_at);

-- ---------- helper functions (SECURITY DEFINER so RLS policies can call them without recursion) ----------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and status = 'active')
$$;
create or replace function public.is_active() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and status = 'active')
$$;
revoke all on function public.is_admin(), public.is_active() from public;
grant execute on function public.is_admin(), public.is_active() to authenticated;

-- ---------- Row Level Security ----------
alter table public.profiles enable row level security;
alter table public.work_requests enable row level security;
alter table public.work_sessions enable row level security;
alter table public.earning_entries enable row level security;
alter table public.points_ledger enable row level security;
alter table public.tier_history enable row level security;
alter table public.resources enable row level security;
alter table public.messages enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.settings enable row level security;
alter table public.activity_log enable row level security;

-- profiles: own row (read) or admin (all). Employees can never write their own profile directly (see update_my_profile()).
create policy profiles_select on public.profiles for select to authenticated using (public.is_admin() or (id = auth.uid() and public.is_active()));
create policy profiles_admin_write on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());
-- A suspended user must still be able to read their own row so the app can tell them why they were signed out.
create policy profiles_self_read_any_status on public.profiles for select to authenticated using (id = auth.uid());

-- work_requests: employee reads own, may only INSERT a pending request for themselves; admin decides.
create policy wr_select on public.work_requests for select to authenticated using (public.is_admin() or (employee_id = auth.uid() and public.is_active()));
create policy wr_insert_own on public.work_requests for insert to authenticated
  with check (employee_id = auth.uid() and public.is_active() and status = 'pending' and reviewed_by is null and reviewed_at is null);
create policy wr_admin_update on public.work_requests for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy wr_admin_delete on public.work_requests for delete to authenticated using (public.is_admin());

-- sessions / earnings / points / tier history: employee reads own; only admin writes.
create policy ws_select on public.work_sessions for select to authenticated using (public.is_admin() or (employee_id = auth.uid() and public.is_active()));
create policy ws_admin on public.work_sessions for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy ee_select on public.earning_entries for select to authenticated using (public.is_admin() or (employee_id = auth.uid() and public.is_active()));
create policy ee_admin on public.earning_entries for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy pl_select on public.points_ledger for select to authenticated using (public.is_admin() or (employee_id = auth.uid() and public.is_active()));
create policy pl_admin on public.points_ledger for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy th_select on public.tier_history for select to authenticated using (public.is_admin() or (employee_id = auth.uid() and public.is_active()));
create policy th_admin on public.tier_history for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- resources / announcements / settings: every active user reads; admin writes.
create policy res_select on public.resources for select to authenticated using (public.is_active());
create policy res_admin on public.resources for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy ann_select on public.announcements for select to authenticated using (public.is_active());
create policy ann_admin on public.announcements for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy set_select on public.settings for select to authenticated using (public.is_active());
create policy set_admin on public.settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- messages: a conversation belongs to an employee; that employee and any admin can read it.
create policy msg_select on public.messages for select to authenticated using (public.is_admin() or (employee_id = auth.uid() and public.is_active()));
create policy msg_insert_employee on public.messages for insert to authenticated
  with check (employee_id = auth.uid() and sender_id = auth.uid() and sender_role = 'employee' and public.is_active() and read_at is null);
create policy msg_insert_admin on public.messages for insert to authenticated
  with check (public.is_admin() and sender_id = auth.uid() and sender_role = 'admin');
create policy msg_admin_delete on public.messages for delete to authenticated using (public.is_admin());
-- read receipts are written only through mark_read() below; no direct UPDATE policy exists.

-- notifications: user reads own (admin reads all so INSERT ... RETURNING works); only read_at is updatable by the user.
create policy ntf_select on public.notifications for select to authenticated using (public.is_admin() or (user_id = auth.uid() and public.is_active()));
create policy ntf_admin_insert on public.notifications for insert to authenticated with check (public.is_admin());
create policy ntf_update_own on public.notifications for update to authenticated using (user_id = auth.uid() and public.is_active()) with check (user_id = auth.uid());
revoke update on public.notifications from authenticated;
grant update (read_at) on public.notifications to authenticated;

-- activity log: admins read; any active user may append a row about themselves.
create policy log_select on public.activity_log for select to authenticated using (public.is_admin());
create policy log_insert on public.activity_log for insert to authenticated with check (public.is_admin() or (actor_id = auth.uid() and public.is_active()));

-- Never expose tables to anonymous visitors.
revoke all on all tables in schema public from anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
revoke update on public.notifications from authenticated;
grant update (read_at) on public.notifications to authenticated;

-- ---------- RPCs ----------
-- Leaderboard: names, tiers and points only (never salary). p_since = NULL means all-time. Caller must be active.
create or replace function public.leaderboard(p_since timestamptz default null)
returns table (employee_id uuid, employee_code text, full_name text, tier text, points bigint)
language sql stable security definer set search_path = public as $$
  select p.id, p.employee_code, p.full_name, p.tier,
         coalesce(sum(l.points) filter (where p_since is null or l.created_at >= p_since), 0)::bigint
  from public.profiles p
  left join public.points_ledger l on l.employee_id = p.id
  where p.role = 'employee' and p.status = 'active' and public.is_active()
  group by p.id
  order by 5 desc, p.full_name
$$;

-- Mark the other side's messages in a conversation as read.
create or replace function public.mark_read(p_employee uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if public.is_admin() then
    update public.messages set read_at = now() where employee_id = p_employee and sender_role = 'employee' and read_at is null;
  elsif auth.uid() = p_employee then
    update public.messages set read_at = now() where employee_id = p_employee and sender_role = 'admin' and read_at is null;
  else
    raise exception 'not allowed';
  end if;
end $$;

-- Employees may edit only their own phone number.
create or replace function public.update_my_profile(p_phone text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  update public.profiles set phone = left(coalesce(p_phone, ''), 30) where id = auth.uid();
end $$;

revoke all on function public.leaderboard(timestamptz), public.mark_read(uuid), public.update_my_profile(text) from public, anon;
grant execute on function public.leaderboard(timestamptz), public.mark_read(uuid), public.update_my_profile(text) to authenticated;

-- ---------- realtime (chat, requests, notifications update live) ----------
do $$
declare t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['work_requests','work_sessions','earning_entries','points_ledger','tier_history','notifications','messages','announcements','resources','profiles'] loop
      begin execute format('alter publication supabase_realtime add table public.%I', t);
      exception when duplicate_object then null; end;
    end loop;
  end if;
end $$;

-- =====================================================================
-- FIRST ADMIN (do this once, after creating the user in Authentication -> Users):
--   1. Dashboard -> Authentication -> Users -> Add user -> email + password (tick "Auto Confirm").
--   2. Run (replace the email and name):
--
--   insert into public.profiles (id, full_name, email, role)
--   select id, 'Your Name', email, 'admin' from auth.users where email = 'you@company.com';
--
-- No admin credentials exist anywhere in the code.
-- =====================================================================
